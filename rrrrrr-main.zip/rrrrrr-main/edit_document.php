<?php

require_once "config.php";


/* =========================================================
   ตรวจสอบ Login
========================================================= */

if (!isset($_SESSION["user_id"])) {

    header("Location: login.php");

    exit;

}


/* =========================================================
   รับ ID เอกสาร
========================================================= */

$id = intval($_GET["id"] ?? 0);


if ($id <= 0) {

    die("ไม่พบรหัสเอกสาร");

}


/* =========================================================
   ดึงข้อมูลเอกสาร
========================================================= */

$stmt = $pdo->prepare("
    SELECT
        d.*,
        u.full_name AS created_by_name
    FROM documents d

    LEFT JOIN users u
        ON d.created_by = u.id

    WHERE d.id = ?

    LIMIT 1
");

$stmt->execute([$id]);

$document = $stmt->fetch();


if (!$document) {

    die("ไม่พบข้อมูลเอกสาร");

}


/* =========================================================
   สถานะ
========================================================= */

$statuses = [

    "ลงรับแล้ว",

    "กำลังดำเนินการ",

    "เสนอหัวหน้าสำนักปลัด",

    "เสนอผู้บริหาร",

    "ส่งให้ผู้ที่ได้รับมอบ",

    "เสร็จสมบูรณ์"

];


/* =========================================================
   ความเร่งด่วน
========================================================= */

$priorities = [

    "ปกติ",

    "ด่วน",

    "ด่วนมาก",

    "ด่วนที่สุด"

];


/* =========================================================
   แปลงวันที่
========================================================= */

$document_date = "";

if (!empty($document["document_date"])) {

    $document_date = date(
        "Y-m-d",
        strtotime($document["document_date"])
    );

}


$received_date = "";

if (!empty($document["received_date"])) {

    $received_date = date(
        "Y-m-d\TH:i",
        strtotime($document["received_date"])
    );

}


$due_date = "";

if (!empty($document["due_date"])) {

    $due_date = date(
        "Y-m-d",
        strtotime($document["due_date"])
    );

}


/* =========================================================
   ดึงไฟล์แนบเดิม
========================================================= */

$files = [];

try {

    $file_stmt = $pdo->prepare("
        SELECT
            df.*,
            u.full_name AS uploaded_by_name

        FROM document_files df

        LEFT JOIN users u
            ON df.uploaded_by = u.id

        WHERE df.document_id = ?

        ORDER BY df.id DESC
    ");

    $file_stmt->execute([$id]);

    $files = $file_stmt->fetchAll();

} catch (PDOException $e) {

    $files = [];

}

?>

<!DOCTYPE html>

<html lang="th">

<head>

<meta charset="UTF-8">

<meta
    name="viewport"
    content="width=device-width, initial-scale=1.0"
>

<title>
    แก้ไขเอกสาร | ระบบติดตามเอกสาร
</title>


<style>

/* =========================================================
   Reset
========================================================= */

* {

    box-sizing: border-box;

}


body {

    margin: 0;

    font-family:
        Tahoma,
        "Noto Sans Thai",
        sans-serif;

    background: #f4f7fb;

    color: #263238;

}


/* =========================================================
   Sidebar
========================================================= */

.sidebar {

    position: fixed;

    left: 0;

    top: 0;

    width: 250px;

    height: 100vh;

    background:
        linear-gradient(
            180deg,
            #0d47a1,
            #1565c0
        );

    color: white;

    padding: 25px 15px;

}


/* =========================================================
   Logo
========================================================= */

.logo-area {

    text-align: center;

    padding-bottom: 25px;

    border-bottom:
        1px solid
        rgba(255,255,255,.2);

}


.logo-area h2 {

    font-size: 19px;

    margin: 0;

}


.logo-area p {

    font-size: 12px;

    opacity: .8;

}


/* =========================================================
   Menu
========================================================= */

.menu {

    margin-top: 25px;

}


.menu a {

    display: block;

    color: white;

    text-decoration: none;

    padding: 13px 15px;

    margin-bottom: 7px;

    border-radius: 10px;

    font-size: 15px;

}


.menu a:hover,
.menu a.active {

    background:
        rgba(255,255,255,.18);

}


.menu .logout {

    margin-top: 25px;

    background:
        rgba(198,40,40,.8);

}


/* =========================================================
   Main
========================================================= */

.main {

    margin-left: 250px;

    min-height: 100vh;

}


/* =========================================================
   Topbar
========================================================= */

.topbar {

    height: 75px;

    background: white;

    display: flex;

    align-items: center;

    justify-content: space-between;

    padding: 0 30px;

    box-shadow:
        0 2px 10px
        rgba(0,0,0,.06);

}


.topbar h1 {

    margin: 0;

    color: #0d47a1;

    font-size: 22px;

}


.user-info {

    text-align: right;

}


.user-name {

    color: #1565c0;

    font-weight: bold;

}


.user-department {

    color: #78909c;

    font-size: 12px;

    margin-top: 3px;

}


/* =========================================================
   Content
========================================================= */

.content {

    padding: 30px;

}


/* =========================================================
   Form Card
========================================================= */

.form-card {

    background: white;

    border-radius: 18px;

    padding: 30px;

    box-shadow:
        0 4px 18px
        rgba(0,0,0,.06);

    max-width: 1100px;

    margin: auto;

}


.form-title {

    margin: 0 0 25px;

    color: #0d47a1;

    font-size: 21px;

    padding-bottom: 15px;

    border-bottom:
        1px solid
        #e0e0e0;

}


.form-section-title {

    color: #1565c0;

    font-size: 17px;

    margin: 25px 0 18px;

    padding-left: 10px;

    border-left:
        4px solid
        #42a5f5;

}


.form-grid {

    display: grid;

    grid-template-columns:
        repeat(2, 1fr);

    gap: 18px;

}


.form-group {

    margin-bottom: 3px;

}


.form-group.full {

    grid-column: 1 / -1;

}


.form-group label {

    display: block;

    margin-bottom: 7px;

    font-weight: bold;

    color: #455a64;

    font-size: 14px;

}


.required {

    color: #e53935;

}


.form-group input,
.form-group select,
.form-group textarea {

    width: 100%;

    border:
        1px solid
        #cfd8dc;

    border-radius: 9px;

    padding: 10px 12px;

    font-family: inherit;

    font-size: 14px;

    outline: none;

    background: white;

}


.form-group input,
.form-group select {

    height: 45px;

}


.form-group textarea {

    min-height: 110px;

    resize: vertical;

}


.form-group input:focus,
.form-group select:focus,
.form-group textarea:focus {

    border-color: #1976d2;

    box-shadow:
        0 0 0 3px
        rgba(25,118,210,.10);

}


/* =========================================================
   Help
========================================================= */

.help {

    font-size: 12px;

    color: #90a4ae;

    margin-top: 5px;

}


/* =========================================================
   File Upload
========================================================= */

.file-upload-box {

    border:
        2px dashed
        #90caf9;

    background:
        #f8fbff;

    border-radius: 12px;

    padding: 20px;

    transition: .2s;

}


.file-upload-box:hover {

    border-color:
        #1976d2;

    background:
        #f1f8ff;

}


.file-upload-box input[type="file"] {

    width: 100%;

    height: auto;

    border: none;

    padding: 5px;

    background: transparent;

    cursor: pointer;

}


.file-upload-title {

    color: #1565c0;

    font-size: 15px;

    font-weight: bold;

    margin-bottom: 8px;

}


.file-upload-help {

    color: #78909c;

    font-size: 12px;

    line-height: 1.7;

    margin-top: 8px;

}


/* =========================================================
   Existing Files
========================================================= */

.existing-files-title {

    color: #1565c0;

    font-size: 14px;

    font-weight: bold;

    margin-top: 20px;

    margin-bottom: 10px;

}


.existing-file {

    display: flex;

    align-items: center;

    justify-content: space-between;

    gap: 15px;

    padding: 12px 14px;

    background: white;

    border:
        1px solid
        #e3f2fd;

    border-radius: 9px;

    margin-bottom: 8px;

}


.existing-file-name {

    color: #455a64;

    font-size: 13px;

    word-break: break-all;

}


.existing-file-info {

    color: #90a4ae;

    font-size: 11px;

    margin-top: 3px;

}


.open-file {

    flex-shrink: 0;

    color: white;

    background:
        #1976d2;

    text-decoration: none;

    padding:
        7px
        12px;

    border-radius: 7px;

    font-size: 12px;

}


.open-file:hover {

    background:
        #0d47a1;

}


/* =========================================================
   Buttons
========================================================= */

.form-actions {

    display: flex;

    justify-content: flex-end;

    gap: 10px;

    margin-top: 30px;

    padding-top: 20px;

    border-top:
        1px solid
        #eeeeee;

}


.btn {

    border: none;

    border-radius: 9px;

    padding: 12px 24px;

    font-size: 14px;

    font-weight: bold;

    cursor: pointer;

    text-decoration: none;

}


.btn-save {

    color: white;

    background:
        linear-gradient(
            135deg,
            #1565c0,
            #1e88e5
        );

}


.btn-save:hover {

    background: #0d47a1;

}


.btn-cancel {

    color: #455a64;

    background: #eceff1;

}


.btn-cancel:hover {

    background: #cfd8dc;

}


/* =========================================================
   Responsive
========================================================= */

@media (max-width: 800px) {

    .sidebar {

        position: relative;

        width: 100%;

        height: auto;

    }


    .main {

        margin-left: 0;

    }


    .form-grid {

        grid-template-columns: 1fr;

    }


    .form-group.full {

        grid-column: auto;

    }


    .topbar {

        height: auto;

        padding: 18px;

    }


    .content {

        padding: 18px;

    }


    .form-card {

        padding: 20px;

    }


    .existing-file {

        flex-direction: column;

        align-items: flex-start;

    }


    .open-file {

        width: 100%;

        text-align: center;

    }

}

</style>

</head>


<body>


<!-- =========================================================
     Sidebar
========================================================= -->

<div class="sidebar">


    <div class="logo-area">


        <img
            src="oo.image/S__29155335.jpg"
            alt="โลโก้เทศบาล"

            style="
                width:95px;
                height:95px;
                border-radius:50%;
                object-fit:cover;
                display:block;
                margin:0 auto 15px;
                border:4px solid #fff;
                box-shadow:
                    0 4px 15px
                    rgba(0,0,0,.15);
            "
        >


        <h2>

            ระบบติดตามเอกสาร

        </h2>


        <p>

            Document Tracking System

        </p>


    </div>


    <div class="menu">


        <a href="dashboard.php">

            🏠 หน้าหลัก

        </a>


        <a href="search.php">

            🔎 ค้นหางาน

        </a>


        <a href="add_document.php">

            ➕ เพิ่มเอกสาร

        </a>


        <a
            href="documents.php"
            class="active"
        >

            📋 เอกสารทั้งหมด

        </a>


        <?php if (
            ($_SESSION["role"] ?? "") === "admin"
        ): ?>


            <a href="users.php">

                👥 จัดการผู้ใช้งาน

            </a>


        <?php endif; ?>


        <a
            href="logout.php"
            class="logout"
        >

            🚪 ออกจากระบบ

        </a>


    </div>


</div>


<!-- =========================================================
     Main
========================================================= -->

<div class="main">


    <!-- =====================================================
         Topbar
    ====================================================== -->

    <div class="topbar">


        <h1>

            ✏️ แก้ไขเอกสาร

        </h1>


        <div class="user-info">


            <div class="user-name">

                <?= htmlspecialchars(
                    $_SESSION["full_name"] ?? ""
                ) ?>

            </div>


            <div class="user-department">

                <?= htmlspecialchars(
                    $_SESSION["department"] ?? ""
                ) ?>

            </div>


        </div>


    </div>


    <!-- =====================================================
         Content
    ====================================================== -->

    <div class="content">


        <div class="form-card">


            <h2 class="form-title">

                ✏️ แก้ไขข้อมูลเอกสาร

            </h2>


            <!-- =================================================
                 Form
            ================================================== -->

            <form
                action="update_document.php"
                method="POST"
                enctype="multipart/form-data"
            >


                <input
                    type="hidden"
                    name="id"
                    value="<?= $id ?>"
                >


                <!-- =================================================
                     ข้อมูลหนังสือ
                ================================================== -->

                <div class="form-section-title">

                    📄 ข้อมูลหนังสือ

                </div>


                <div class="form-grid">


                    <!-- เลขที่หนังสือ -->

                    <div class="form-group">


                        <label>

                            เลขที่หนังสือ

                            <span class="required">
                                *
                            </span>

                        </label>


                        <input
                            type="text"
                            name="document_no"
                            value="<?= htmlspecialchars(
                                $document["document_no"] ?? ""
                            ) ?>"
                            placeholder="เช่น ลป 123/2569"
                            required
                        >


                    </div>


                    <!-- วันที่หนังสือ -->

                    <div class="form-group">


                        <label>

                            วันที่หนังสือ

                        </label>


                        <input
                            type="date"
                            name="document_date"
                            value="<?= htmlspecialchars(
                                $document_date
                            ) ?>"
                        >


                    </div>


                    <!-- เรื่อง -->

                    <div class="form-group full">


                        <label>

                            เรื่อง

                            <span class="required">
                                *
                            </span>

                        </label>


                        <input
                            type="text"
                            name="subject"
                            value="<?= htmlspecialchars(
                                $document["subject"] ?? ""
                            ) ?>"
                            placeholder="กรอกชื่อเรื่อง"
                            required
                        >


                    </div>


                    <!-- ผู้ส่ง -->

                    <div class="form-group">


                        <label>

                            จาก / ผู้ส่ง

                        </label>


                        <input
                            type="text"
                            name="sender"
                            value="<?= htmlspecialchars(
                                $document["sender"] ?? ""
                            ) ?>"
                            placeholder="หน่วยงานหรือบุคคลผู้ส่ง"
                        >


                    </div>


                    <!-- ผู้รับ -->

                    <div class="form-group">


                        <label>

                            ถึง / ผู้รับ

                        </label>


                        <input
                            type="text"
                            name="receiver"
                            value="<?= htmlspecialchars(
                                $document["receiver"] ?? ""
                            ) ?>"
                            placeholder="หน่วยงานหรือบุคคลผู้รับ"
                        >


                    </div>


                </div>


                <!-- =================================================
                     การดำเนินงาน
                ================================================== -->

                <div class="form-section-title">

                    👤 ข้อมูลการดำเนินงาน

                </div>


                <div class="form-grid">


                    <!-- หน่วยงาน -->

                    <div class="form-group">


                        <label>

                            หน่วยงาน

                        </label>


                        <input
                            type="text"
                            name="department"
                            value="<?= htmlspecialchars(
                                $document["department"] ?? ""
                            ) ?>"
                            placeholder="เช่น สำนักปลัด / กองคลัง / กองช่าง"
                        >


                    </div>


                    <!-- ผู้รับผิดชอบ -->

                    <div class="form-group">


                        <label>

                            ผู้รับผิดชอบ

                        </label>


                        <input
                            type="text"
                            name="responsible_person"
                            value="<?= htmlspecialchars(
                                $document["responsible_person"] ?? ""
                            ) ?>"
                            placeholder="ชื่อผู้รับผิดชอบ"
                        >


                    </div>


                    <!-- วันที่รับ -->

                    <div class="form-group">


                        <label>

                            วันที่รับเอกสาร

                        </label>


                        <input
                            type="datetime-local"
                            name="received_date"
                            value="<?= htmlspecialchars(
                                $received_date
                            ) ?>"
                        >


                        <div class="help">

                            หากไม่ระบุ
                            ระบบจะใช้วันและเวลาปัจจุบัน

                        </div>


                    </div>


                    <!-- กำหนดเสร็จ -->

                    <div class="form-group">


                        <label>

                            กำหนดเสร็จ

                        </label>


                        <input
                            type="date"
                            name="due_date"
                            value="<?= htmlspecialchars(
                                $due_date
                            ) ?>"
                        >


                    </div>


                    <!-- สถานะ -->

                    <div class="form-group">


                        <label>

                            สถานะ

                        </label>


                        <select name="status">


                            <?php foreach (
                                $statuses
                                as $status
                            ): ?>


                                <option
                                    value="<?= htmlspecialchars(
                                        $status
                                    ) ?>"

                                    <?= (
                                        ($document["status"] ?? "")
                                        === $status
                                    )
                                    ? "selected"
                                    : ""
                                    ?>
                                >

                                    <?= htmlspecialchars(
                                        $status
                                    ) ?>

                                </option>


                            <?php endforeach; ?>


                        </select>


                    </div>


                    <!-- ความเร่งด่วน -->

                    <div class="form-group">


                        <label>

                            ความเร่งด่วน

                        </label>


                        <select name="priority">


                            <?php foreach (
                                $priorities
                                as $priority
                            ): ?>


                                <option
                                    value="<?= htmlspecialchars(
                                        $priority
                                    ) ?>"

                                    <?= (
                                        ($document["priority"] ?? "")
                                        === $priority
                                    )
                                    ? "selected"
                                    : ""
                                    ?>
                                >

                                    <?= htmlspecialchars(
                                        $priority
                                    ) ?>

                                </option>


                            <?php endforeach; ?>


                        </select>


                    </div>


                </div>


                <!-- =================================================
                     รายละเอียด
                ================================================== -->

                <div class="form-section-title">

                    📋 รายละเอียดเพิ่มเติม

                </div>


                <div class="form-grid">


                    <!-- รายละเอียด -->

                    <div class="form-group full">


                        <label>

                            รายละเอียด / การดำเนินการ

                        </label>


                        <textarea
                            name="detail"
                            placeholder="บันทึกรายละเอียดของเอกสาร หรือรายละเอียดการดำเนินงาน"
                        ><?= htmlspecialchars(
                            $document["detail"] ?? ""
                        ) ?></textarea>


                    </div>


                    <!-- ผลการดำเนินงาน -->

                    <div class="form-group full">


                        <label>

                            ผลการดำเนินงาน

                        </label>


                        <textarea
                            name="result"
                            placeholder="บันทึกผลการดำเนินงาน (ถ้ามี)"
                        ><?= htmlspecialchars(
                            $document["result"] ?? ""
                        ) ?></textarea>


                    </div>


                </div>


                <!-- =================================================
                     เอกสารแนบ
                ================================================== -->

                <div class="form-section-title">

                    📎 เอกสารแนบ

                </div>


                <div class="form-grid">


                    <div class="form-group full">


                        <div class="file-upload-box">


                            <div class="file-upload-title">

                                📎 เพิ่มเอกสารแนบ

                            </div>


                            <input
                                type="file"
                                name="attachments[]"
                                multiple
                                accept="
                                    .pdf,
                                    .doc,
                                    .docx,
                                    .xls,
                                    .xlsx,
                                    .jpg,
                                    .jpeg,
                                    .png
                                "
                            >


                            <div class="file-upload-help">

                                สามารถเลือกได้หลายไฟล์พร้อมกัน

                                <br>

                                รองรับไฟล์:

                                PDF,
                                Word,
                                Excel,
                                JPG,
                                JPEG,
                                PNG

                                <br>

                                ขนาดไม่เกิน
                                <strong>
                                    10 MB ต่อไฟล์
                                </strong>

                            </div>


                            <!-- =================================================
                                 ไฟล์เดิม
                            ================================================== -->

                            <?php if (
                                count($files) > 0
                            ): ?>


                                <div class="existing-files-title">

                                    📂 ไฟล์ที่แนบไว้แล้ว

                                </div>


                                <?php foreach (
                                    $files
                                    as $file
                                ): ?>


                                    <div
                                        class="existing-file"
                                    >


                                        <div>


                                            <div
                                                class="existing-file-name"
                                            >

                                                📎

                                                <?= htmlspecialchars(
                                                    $file["file_name"]
                                                ) ?>

                                            </div>


                                            <div
                                                class="existing-file-info"
                                            >

                                                อัปโหลดโดย:

                                                <?= htmlspecialchars(
                                                    $file["uploaded_by_name"]
                                                    ?: "-"
                                                ) ?>

                                                <?php if (
                                                    !empty(
                                                        $file["uploaded_at"]
                                                    )
                                                ): ?>

                                                    |

                                                    <?= date(
                                                        "d/m/Y H:i",
                                                        strtotime(
                                                            $file["uploaded_at"]
                                                        )
                                                    ) ?>

                                                <?php endif; ?>


                                            </div>


                                        </div>


                                        <a
                                            href="<?= htmlspecialchars(
                                                $file["file_path"]
                                            ) ?>"
                                            target="_blank"
                                            class="open-file"
                                        >

                                            📂 เปิดไฟล์

                                        </a>


                                    </div>


                                <?php endforeach; ?>


                            <?php else: ?>


                                <div
                                    style="
                                        margin-top:15px;
                                        color:#90a4ae;
                                        font-size:12px;
                                    "
                                >

                                    ยังไม่มีไฟล์แนบสำหรับเอกสารนี้

                                </div>


                            <?php endif; ?>


                        </div>


                    </div>


                </div>


                <!-- =================================================
                     ปุ่ม
                ================================================== -->

                <div class="form-actions">


                    <a
                        href="document.php?id=<?= $id ?>"
                        class="btn btn-cancel"
                    >

                        ยกเลิก

                    </a>


                    <button
                        type="submit"
                        class="btn btn-save"
                    >

                        💾 บันทึกการแก้ไข

                    </button>


                </div>


            </form>


        </div>


    </div>


</div>


</body>

</html>