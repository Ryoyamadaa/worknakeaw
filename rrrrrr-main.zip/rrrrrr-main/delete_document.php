<?php

error_reporting(E_ALL);
ini_set('display_errors', 1);

require_once "config.php";

/*
|--------------------------------------------------------------------------
| ตรวจสอบการเข้าสู่ระบบ
|--------------------------------------------------------------------------
*/

if (!isset($_SESSION["user_id"])) {
    header("Location: login.php");
    exit;
}

/*
|--------------------------------------------------------------------------
| ตรวจสอบสิทธิ์ Admin
|--------------------------------------------------------------------------
*/

if ($_SESSION["role"] !== "admin") {
    die("
        <div style='
            font-family:Tahoma,Arial,sans-serif;
            max-width:700px;
            margin:80px auto;
            padding:35px;
            background:white;
            border-radius:18px;
            box-shadow:0 5px 25px rgba(0,0,0,.08);
            text-align:center;
        '>

            <div style='font-size:55px;margin-bottom:15px;'>🔒</div>

            <h2 style='color:#dc2626;'>
                ไม่มีสิทธิ์ลบเอกสาร
            </h2>

            <p style='color:#64748b;'>
                เฉพาะผู้ดูแลระบบเท่านั้นที่สามารถลบเอกสารได้
            </p>

            <a href='documents.php'
                style='
                    display:inline-block;
                    margin-top:15px;
                    padding:11px 20px;
                    background:#1565c0;
                    color:white;
                    text-decoration:none;
                    border-radius:10px;
                '>
                ← กลับหน้าเอกสารทั้งหมด
            </a>

        </div>
    ");
    exit;
}

/*
|--------------------------------------------------------------------------
| ตรวจสอบ ID เอกสาร
|--------------------------------------------------------------------------
*/

$document_id = (int)($_GET["id"] ?? 0);

if ($document_id <= 0) {
    die("
        <div style='
            font-family:Tahoma,Arial,sans-serif;
            max-width:700px;
            margin:80px auto;
            padding:35px;
            background:white;
            border-radius:18px;
            box-shadow:0 5px 25px rgba(0,0,0,.08);
            text-align:center;
        '>

            <div style='font-size:55px;margin-bottom:15px;'>⚠️</div>

            <h2 style='color:#dc2626;'>
                ไม่พบรหัสเอกสาร
            </h2>

            <p style='color:#64748b;'>
                กรุณาตรวจสอบลิงก์อีกครั้ง
            </p>

            <a href='documents.php'
                style='
                    display:inline-block;
                    margin-top:15px;
                    padding:11px 20px;
                    background:#1565c0;
                    color:white;
                    text-decoration:none;
                    border-radius:10px;
                '>
                ← กลับหน้าเอกสารทั้งหมด
            </a>

        </div>
    ");
    exit;
}

/*
|--------------------------------------------------------------------------
| ดึงข้อมูลเอกสารก่อนลบ
|--------------------------------------------------------------------------
*/

try {

    $stmt = $pdo->prepare("
        SELECT
            id,
            document_no,
            subject,
            department,
            responsible_person
        FROM documents
        WHERE id = ?
        LIMIT 1
    ");

    $stmt->execute([$document_id]);

    $document = $stmt->fetch();

    if (!$document) {
        die("
            <div style='
                font-family:Tahoma,Arial,sans-serif;
                max-width:700px;
                margin:80px auto;
                padding:35px;
                background:white;
                border-radius:18px;
                box-shadow:0 5px 25px rgba(0,0,0,.08);
                text-align:center;
            '>

                <div style='font-size:55px;margin-bottom:15px;'>📄</div>

                <h2 style='color:#dc2626;'>
                    ไม่พบเอกสาร
                </h2>

                <p style='color:#64748b;'>
                    เอกสารนี้อาจถูกลบไปแล้ว
                </p>

                <a href='documents.php'
                    style='
                        display:inline-block;
                        margin-top:15px;
                        padding:11px 20px;
                        background:#1565c0;
                        color:white;
                        text-decoration:none;
                        border-radius:10px;
                    '>
                    ← กลับหน้าเอกสารทั้งหมด
                </a>

            </div>
        ");
        exit;
    }

    /*
    |--------------------------------------------------------------------------
    | เริ่ม Transaction
    |--------------------------------------------------------------------------
    */

    $pdo->beginTransaction();

    /*
    |--------------------------------------------------------------------------
    | ลบประวัติการติดตามเอกสาร
    |--------------------------------------------------------------------------
    |
    | document_history มี Foreign Key ON DELETE CASCADE
    | ดังนั้นจริง ๆ แล้วไม่จำเป็นต้องลบเอง
    | แต่ปล่อยให้ฐานข้อมูลจัดการเมื่อ documents ถูกลบ
    |
    */

    /*
    |--------------------------------------------------------------------------
    | ลบเอกสาร
    |--------------------------------------------------------------------------
    */

    $delete = $pdo->prepare("
        DELETE FROM documents
        WHERE id = ?
    ");

    $delete->execute([$document_id]);

    /*
    |--------------------------------------------------------------------------
    | ตรวจสอบว่าลบสำเร็จหรือไม่
    |--------------------------------------------------------------------------
    */

    if ($delete->rowCount() <= 0) {

        $pdo->rollBack();

        die("
            <div style='
                font-family:Tahoma,Arial,sans-serif;
                max-width:700px;
                margin:80px auto;
                padding:35px;
                background:white;
                border-radius:18px;
                box-shadow:0 5px 25px rgba(0,0,0,.08);
                text-align:center;
            '>

                <div style='font-size:55px;margin-bottom:15px;'>❌</div>

                <h2 style='color:#dc2626;'>
                    ไม่สามารถลบเอกสารได้
                </h2>

                <p style='color:#64748b;'>
                    กรุณาลองใหม่อีกครั้ง
                </p>

                <a href='documents.php'
                    style='
                        display:inline-block;
                        margin-top:15px;
                        padding:11px 20px;
                        background:#1565c0;
                        color:white;
                        text-decoration:none;
                        border-radius:10px;
                    '>
                    ← กลับหน้าเอกสารทั้งหมด
                </a>

            </div>
        ");

        exit;
    }

    /*
    |--------------------------------------------------------------------------
    | ยืนยัน Transaction
    |--------------------------------------------------------------------------
    */

    $pdo->commit();

    /*
    |--------------------------------------------------------------------------
    | กลับหน้าเอกสารทั้งหมด
    |--------------------------------------------------------------------------
    */

    header("Location: documents.php?deleted=1");
    exit;

} catch (PDOException $e) {

    /*
    |--------------------------------------------------------------------------
    | Rollback หากเกิดข้อผิดพลาด
    |--------------------------------------------------------------------------
    */

    if ($pdo->inTransaction()) {
        $pdo->rollBack();
    }

    echo "
        <!DOCTYPE html>
        <html lang='th'>
        <head>
            <meta charset='UTF-8'>
            <meta name='viewport' content='width=device-width, initial-scale=1.0'>
            <title>เกิดข้อผิดพลาด</title>

            <style>

                *{
                    box-sizing:border-box;
                }

                body{
                    margin:0;
                    font-family:Tahoma,'Noto Sans Thai',sans-serif;
                    background:#f4f7fb;
                    color:#263238;
                }

                .error-box{
                    max-width:800px;
                    margin:80px auto;
                    background:white;
                    padding:35px;
                    border-radius:18px;
                    box-shadow:0 5px 25px rgba(0,0,0,.08);
                }

                .icon{
                    font-size:55px;
                    text-align:center;
                    margin-bottom:15px;
                }

                h2{
                    text-align:center;
                    color:#dc2626;
                    margin-bottom:10px;
                }

                .message{
                    text-align:center;
                    color:#64748b;
                    margin-bottom:25px;
                }

                .error-detail{
                    background:#fef2f2;
                    color:#991b1b;
                    padding:15px;
                    border-radius:10px;
                    word-break:break-word;
                    font-size:13px;
                }

                .btn{
                    display:inline-block;
                    margin-top:20px;
                    padding:11px 20px;
                    background:#1565c0;
                    color:white;
                    text-decoration:none;
                    border-radius:10px;
                }

                .center{
                    text-align:center;
                }

            </style>
        </head>

        <body>

            <div class='error-box'>

                <div class='icon'>❌</div>

                <h2>
                    เกิดข้อผิดพลาดในการลบเอกสาร
                </h2>

                <div class='message'>
                    ระบบไม่สามารถลบเอกสารได้
                </div>

                <div class='error-detail'>
                    " . htmlspecialchars($e->getMessage()) . "
                </div>

                <div class='center'>
                    <a href='documents.php' class='btn'>
                        ← กลับหน้าเอกสารทั้งหมด
                    </a>
                </div>

            </div>

        </body>
        </html>
    ";

    exit;
}
?>