<?php

error_reporting(E_ALL);
ini_set('display_errors', 1);

require_once "config.php";


/* =========================
   ตรวจสอบ Login
========================= */

if (!isset($_SESSION["user_id"])) {

    header("Location: login.php");
    exit;

}


/* =========================
   ตรวจสอบสิทธิ์ Admin
========================= */

if ($_SESSION["role"] !== "admin") {

    die("
        <div style='
            font-family:Tahoma,Arial,sans-serif;
            max-width:700px;
            margin:80px auto;
            padding:35px;
            background:white;
            border-radius:18px;
            box-shadow:0 5px 25px rgba(0,0,0,.08);
            text-align:center;
        '>

            <div style='
                font-size:55px;
                margin-bottom:15px;
            '>
                🔒
            </div>

            <h2 style='color:#dc2626;'>
                ไม่มีสิทธิ์เข้าถึงหน้านี้
            </h2>

            <p style='color:#64748b;'>
                หน้านี้สำหรับผู้ดูแลระบบเท่านั้น
            </p>

            <a
                href='dashboard.php'
                style='
                    display:inline-block;
                    margin-top:15px;
                    padding:11px 20px;
                    background:#1565c0;
                    color:white;
                    text-decoration:none;
                    border-radius:10px;
                '
            >
                ← กลับหน้าหลัก
            </a>

        </div>
    ");

    exit;

}


/* =========================
   ค้นหา
========================= */

$keyword = trim(
    $_GET["keyword"] ?? ""
);


/* =========================
   ดึงข้อมูลผู้ใช้งาน
========================= */

$sql = "
    SELECT
        id,
        username,
        full_name,
        department,
        role,
        created_at
    FROM users
    WHERE 1=1
";

$params = [];


if ($keyword !== "") {

    $sql .= "
        AND (
            username LIKE ?
            OR full_name LIKE ?
            OR department LIKE ?
        )
    ";

    $search =
        "%" . $keyword . "%";

    $params[] = $search;
    $params[] = $search;
    $params[] = $search;
}


$sql .= "
    ORDER BY id DESC
";


try {

    $stmt = $pdo->prepare($sql);

    $stmt->execute($params);

    $users = $stmt->fetchAll();

} catch (PDOException $e) {

    die("
        <div style='
            font-family:Tahoma,Arial,sans-serif;
            max-width:800px;
            margin:60px auto;
            padding:30px;
            background:white;
            border-radius:15px;
            box-shadow:0 5px 20px rgba(0,0,0,.08);
        '>

            <h2 style='color:#dc2626;'>
                ❌ เกิดข้อผิดพลาด
            </h2>

            <p style='color:#555;'>
                ไม่สามารถโหลดข้อมูลผู้ใช้งานได้
            </p>

            <div style='
                background:#fef2f2;
                color:#991b1b;
                padding:15px;
                border-radius:10px;
                word-break:break-word;
            '>
                "
                . htmlspecialchars(
                    $e->getMessage()
                )
                . "
            </div>

        </div>
    ");

}

?>

<!DOCTYPE html>
<html lang="th">

<head>

<meta charset="UTF-8">

<meta
    name="viewport"
    content="width=device-width, initial-scale=1.0"
>

<title>
    จัดการผู้ใช้งาน | ระบบติดตามเอกสาร
</title>


<style>

/* =========================
   RESET
========================= */

* {
    box-sizing: border-box;
}


/* =========================
   BODY
========================= */

body {

    margin: 0;

    font-family:
        Tahoma,
        "Noto Sans Thai",
        sans-serif;

    background: #f4f7fb;

    color: #263238;

}


/* =========================
   SIDEBAR
========================= */

.sidebar {

    position: fixed;

    left: 0;
    top: 0;

    width: 250px;

    height: 100vh;

    background:
        linear-gradient(
            180deg,
            #0d47a1,
            #1565c0
        );

    color: white;

    padding: 25px 15px;

    overflow-y: auto;

}


.logo-area {

    text-align: center;

    padding-bottom: 25px;

    border-bottom:
        1px solid
        rgba(255,255,255,.2);

}


.logo-icon {

    width: 65px;
    height: 65px;

    margin: auto;

    border-radius: 50%;

    background: white;

    color: #1565c0;

    display: flex;

    align-items: center;

    justify-content: center;

    font-size: 28px;

    margin-bottom: 12px;

}


.logo-area h2 {

    font-size: 19px;

    margin: 0;

}


.logo-area p {

    font-size: 12px;

    margin-top: 6px;

    opacity: .8;

}


/* =========================
   MENU
========================= */

.menu {

    margin-top: 25px;

}


.menu a {

    display: block;

    color: white;

    text-decoration: none;

    padding: 13px 15px;

    margin-bottom: 7px;

    border-radius: 10px;

    transition: .2s;

    font-size: 15px;

}


.menu a:hover,
.menu a.active {

    background:
        rgba(255,255,255,.18);

}


.menu .logout {

    margin-top: 25px;

    background:
        rgba(198,40,40,.8);

}


.menu .logout:hover {

    background:
        rgba(183,28,28,.95);

}


/* =========================
   MAIN
========================= */

.main {

    margin-left: 250px;

    min-height: 100vh;

}


/* =========================
   TOPBAR
========================= */

.topbar {

    height: 75px;

    background: white;

    display: flex;

    align-items: center;

    justify-content: space-between;

    padding: 0 30px;

    box-shadow:
        0 2px 12px
        rgba(0,0,0,.05);

}


.topbar h1 {

    margin: 0;

    color: #0759a5;

    font-size: 23px;

}


.user-box {

    display: flex;

    align-items: center;

    gap: 12px;

}


.user-icon {

    width: 42px;
    height: 42px;

    border-radius: 50%;

    background: #e5f2ff;

    display: flex;

    align-items: center;

    justify-content: center;

    font-size: 20px;

}


.user-name {

    font-weight: 700;

}


.user-dept {

    font-size: 12px;

    color: #64748b;

}


/* =========================
   CONTENT
========================= */

.content {

    padding: 30px;

}


/* =========================
   SEARCH CARD
========================= */

.search-card {

    background: white;

    border-radius: 16px;

    padding: 23px;

    margin-bottom: 20px;

    box-shadow:
        0 5px 20px
        rgba(30,64,175,.07);

    border:
        1px solid #e5edf7;

}


.search-title {

    font-size: 18px;

    font-weight: 700;

    color: #0759a5;

    margin-bottom: 16px;

}


.search-row {

    display: flex;

    gap: 12px;

}


.search-row input {

    flex: 1;

}


input {

    width: 100%;

    padding: 12px 14px;

    border:
        1px solid #d8e2ef;

    border-radius: 10px;

    font-size: 14px;

    outline: none;

}


input:focus {

    border-color: #1683dc;

    box-shadow:
        0 0 0 3px
        rgba(22,131,220,.08);

}


/* =========================
   BUTTON
========================= */

.btn {

    border: none;

    border-radius: 10px;

    padding: 11px 17px;

    cursor: pointer;

    text-decoration: none;

    display: inline-block;

    font-weight: 600;

    font-size: 14px;

}


.btn-blue {

    background: #1565c0;

    color: white;

}


.btn-blue:hover {

    background: #0d47a1;

}


.btn-green {

    background: #16a34a;

    color: white;

}


.btn-green:hover {

    background: #15803d;

}


/* =========================
   USER CARD
========================= */

.table-card {

    background: white;

    border-radius: 16px;

    padding: 25px;

    box-shadow:
        0 3px 15px
        rgba(0,0,0,.06);

}


.table-header {

    display: flex;

    align-items: center;

    justify-content: space-between;

    margin-bottom: 20px;

}


.table-title h2 {

    margin: 0;

    font-size: 19px;

    color: #263238;

}


.result-count {

    color: #64748b;

    font-size: 13px;

    margin-top: 5px;

}


/* =========================
   TABLE
========================= */

.table-wrap {

    overflow-x: auto;

}


table {

    width: 100%;

    border-collapse: collapse;

    min-width: 850px;

}


th {

    background: #e3f2fd;

    color: #0d47a1;

    padding: 13px 12px;

    text-align: left;

    font-size: 13px;

    white-space: nowrap;

}


td {

    padding: 14px 12px;

    border-bottom:
        1px solid #edf1f5;

    font-size: 13px;

    vertical-align: middle;

}


tr:hover td {

    background: #f8fbff;

}


/* =========================
   USER AVATAR
========================= */

.user-avatar {

    width: 38px;
    height: 38px;

    border-radius: 50%;

    background:
        linear-gradient(
            135deg,
            #e3f2fd,
            #bbdefb
        );

    color: #1565c0;

    display: inline-flex;

    align-items: center;

    justify-content: center;

    margin-right: 9px;

    vertical-align: middle;

    font-size: 17px;

}


.user-fullname {

    font-weight: 700;

    color: #263238;

}


/* =========================
   ROLE BADGE
========================= */

.role-badge {

    display: inline-block;

    padding: 6px 11px;

    border-radius: 20px;

    font-size: 11px;

    font-weight: 700;

}


.role-admin {

    background: #ede9fe;

    color: #6d28d9;

}


.role-user {

    background: #e0f2fe;

    color: #0369a1;

}


/* =========================
   ACTIONS
========================= */

.actions {

    display: flex;

    gap: 6px;

    flex-wrap: wrap;

}


.actions a {

    padding:
        7px 10px;

    border-radius: 7px;

    text-decoration: none;

    font-size: 11px;

    font-weight: 600;

}


.edit {

    background: #fef3c7;

    color: #92400e;

}


.edit:hover {

    background: #fde68a;

}


.delete {

    background: #fee2e2;

    color: #b91c1c;

}


.delete:hover {

    background: #fecaca;

}


/* =========================
   EMPTY
========================= */

.empty {

    text-align: center;

    padding: 50px 20px;

    color: #90a4ae;

}


.empty-icon {

    font-size: 45px;

    margin-bottom: 10px;

}


/* =========================
   RESPONSIVE
========================= */

@media (max-width: 700px) {

    .sidebar {

        position: relative;

        width: 100%;

        height: auto;

    }


    .main {

        margin-left: 0;

    }


    .topbar {

        height: auto;

        padding: 18px;

        gap: 15px;

        flex-direction: column;

        align-items: flex-start;

    }


    .content {

        padding: 18px;

    }


    .search-row {

        flex-direction: column;

    }


    .table-header {

        align-items: flex-start;

        flex-direction: column;

        gap: 15px;

    }

}

</style>

</head>


<body>


<!-- ==================================================
     SIDEBAR
================================================== -->

<div class="sidebar">


    <div class="logo-area">

        <img src="oo.image/S__29155335.jpg"
     alt="โลโก้เทศบาล"
     style="
        width:95px;
        height:95px;
        border-radius:50%;
        object-fit:cover;
        display:block;
        margin:0 auto 15px;
        border:4px solid #fff;
        box-shadow:0 4px 15px rgba(0,0,0,.15);
     ">


        <h2>
            ระบบติดตามเอกสาร
        </h2>

        <p>
            Document Tracking System
        </p>

    </div>


    <div class="menu">


        <a href="dashboard.php">

            🏠 หน้าหลัก

        </a>


        <a href="search.php">

            🔎 ค้นหางาน

        </a>


        <a href="add_document.php">

            ➕ เพิ่มเอกสาร

        </a>


        <a href="documents.php">

            📋 เอกสารทั้งหมด

        </a>


        <a
            href="users.php"
            class="active"
        >

            👥 จัดการผู้ใช้งาน

        </a>


        <a
            href="logout.php"
            class="logout"
        >

            🚪 ออกจากระบบ

        </a>


    </div>

</div>



<!-- ==================================================
     MAIN
================================================== -->

<div class="main">


    <!-- ==================================================
         TOPBAR
    ================================================== -->

    <div class="topbar">


        <h1>

            👥 จัดการผู้ใช้งาน

        </h1>


        <div class="user-box">


            <div class="user-icon">

                👤

            </div>


            <div>

                <div class="user-name">

                    <?= htmlspecialchars(
                        $_SESSION["full_name"]
                    ) ?>

                </div>


                <div class="user-dept">

                    <?= htmlspecialchars(
                        $_SESSION["department"]
                    ) ?>

                </div>

            </div>


        </div>


    </div>



    <!-- ==================================================
         CONTENT
    ================================================== -->

    <div class="content">


        <!-- ==================================================
             SEARCH
        ================================================== -->

        <div class="search-card">


            <div class="search-title">

                🔎 ค้นหาผู้ใช้งาน

            </div>


            <form method="GET">


                <div class="search-row">


                    <input
                        type="text"
                        name="keyword"
                        placeholder="ค้นหาจาก Username / ชื่อ-นามสกุล / หน่วยงาน"
                        value="<?= htmlspecialchars(
                            $keyword
                        ) ?>"
                    >


                    <button
                        type="submit"
                        class="btn btn-blue"
                    >

                        🔎 ค้นหา

                    </button>


                </div>


            </form>


        </div>



        <!-- ==================================================
             USER TABLE
        ================================================== -->

        <div class="table-card">


            <div class="table-header">


                <div class="table-title">


                    <h2>

                        👥 รายชื่อผู้ใช้งาน

                    </h2>


                    <div class="result-count">

                        พบ <?= count($users) ?> รายการ

                    </div>


                </div>


                <a
                    href="add_user.php"
                    class="btn btn-green"
                >

                    ➕ เพิ่มผู้ใช้งาน

                </a>


            </div>



            <div class="table-wrap">


                <?php if (
                    count($users) > 0
                ): ?>


                    <table>


                        <thead>

                            <tr>

                                <th>
                                    ลำดับ
                                </th>

                                <th>
                                    ผู้ใช้งาน
                                </th>

                                <th>
                                    Username
                                </th>

                                <th>
                                    หน่วยงาน
                                </th>

                                <th>
                                    สิทธิ์
                                </th>

                                <th>
                                    วันที่สร้าง
                                </th>

                                <th>
                                    จัดการ
                                </th>

                            </tr>

                        </thead>


                        <tbody>


                        <?php
                        $number = 1;
                        ?>


                        <?php foreach (
                            $users as $user
                        ): ?>


                            <tr>


                                <!-- ลำดับ -->

                                <td>

                                    <?= $number++ ?>

                                </td>


                                <!-- ชื่อ -->

                                <td>


                                    <span class="user-avatar">

                                        👤

                                    </span>


                                    <span class="user-fullname">

                                        <?= htmlspecialchars(
                                            $user["full_name"]
                                        ) ?>

                                    </span>


                                </td>


                                <!-- Username -->

                                <td>

                                    <?= htmlspecialchars(
                                        $user["username"]
                                    ) ?>

                                </td>


                                <!-- หน่วยงาน -->

                                <td>

                                    <?= htmlspecialchars(
                                        $user["department"]
                                        ?: "-"
                                    ) ?>

                                </td>


                                <!-- สิทธิ์ -->

                                <td>


                                    <?php if (
                                        $user["role"]
                                        === "admin"
                                    ): ?>


                                        <span
                                            class="role-badge role-admin"
                                        >

                                            👑 ผู้ดูแลระบบ

                                        </span>


                                    <?php else: ?>


                                        <span
                                            class="role-badge role-user"
                                        >

                                            👤 ผู้ใช้งาน

                                        </span>


                                    <?php endif; ?>


                                </td>


                                <!-- วันที่สร้าง -->

                                <td>

                                    <?php if (
                                        !empty(
                                            $user["created_at"]
                                        )
                                    ): ?>

                                        <?= date(
                                            "d/m/Y H:i",
                                            strtotime(
                                                $user["created_at"]
                                            )
                                        ) ?>

                                    <?php else: ?>

                                        -

                                    <?php endif; ?>

                                </td>


                                <!-- จัดการ -->

                                <td>


                                    <div class="actions">


                                        <a
                                            href="edit_user.php?id=<?= (int)$user["id"] ?>"
                                            class="edit"
                                        >

                                            ✏️ แก้ไข

                                        </a>


                                        <?php
                                        /*
                                           ไม่ให้ Admin ลบบัญชีตัวเอง
                                        */
                                        ?>


                                        <?php if (
                                            (int)$user["id"]
                                            !==
                                            (int)$_SESSION["user_id"]
                                        ): ?>


                                            <a
                                                href="delete_user.php?id=<?= (int)$user["id"] ?>"
                                                class="delete"
                                                onclick="return confirm('ยืนยันการลบผู้ใช้งาน <?= htmlspecialchars($user["full_name"], ENT_QUOTES) ?> หรือไม่?');"
                                            >

                                                🗑 ลบ

                                            </a>


                                        <?php endif; ?>


                                    </div>


                                </td>


                            </tr>


                        <?php endforeach; ?>


                        </tbody>


                    </table>


                <?php else: ?>


                    <div class="empty">


                        <div class="empty-icon">

                            👥

                        </div>


                        ไม่พบข้อมูลผู้ใช้งาน


                        <br><br>


                        <a
                            href="add_user.php"
                            class="btn btn-green"
                        >

                            ➕ เพิ่มผู้ใช้งาน

                        </a>


                    </div>


                <?php endif; ?>


            </div>


        </div>


    </div>


</div>


</body>

</html>