<?php
require_once "config.php";

/* =========================
   ตรวจสอบ Login
========================= */
if (!isset($_SESSION["user_id"])) {
    header("Location: login.php");
    exit;
}

/* =========================
   รับ ID
========================= */
$id = intval($_GET["id"] ?? 0);

if ($id <= 0) {
    die("ไม่พบรหัสเอกสาร");
}

/* =========================
   ดึงข้อมูลเอกสาร
========================= */
$stmt = $pdo->prepare("
    SELECT
        d.*,
        u.full_name AS created_by_name
    FROM documents d
    LEFT JOIN users u
        ON d.created_by = u.id
    WHERE d.id = ?
    LIMIT 1
");

$stmt->execute([$id]);

$document = $stmt->fetch();

if (!$document) {
    die("ไม่พบข้อมูลเอกสาร");
}

/* =========================
   ดึงประวัติเอกสาร
========================= */
$history_stmt = $pdo->prepare("
    SELECT
        h.*,
        u.full_name AS action_by_name
    FROM document_history h
    LEFT JOIN users u
        ON h.action_by = u.id
    WHERE h.document_id = ?
    ORDER BY h.action_date DESC, h.id DESC
");

$history_stmt->execute([$id]);
$history = $history_stmt->fetchAll();

/* =========================
   ดึงไฟล์แนบ
========================= */
$files = [];

try {

    $file_stmt = $pdo->prepare("
        SELECT
            df.*,
            u.full_name AS uploaded_by_name
        FROM document_files df
        LEFT JOIN users u
            ON df.uploaded_by = u.id
        WHERE df.document_id = ?
        ORDER BY df.id DESC
    ");

    $file_stmt->execute([$id]);
    $files = $file_stmt->fetchAll();

} catch (PDOException $e) {

    $files = [];
}

/* =========================
   สถานะ
========================= */
$status_class = [

    "ลงรับแล้ว" =>
        "status-blue",

    "กำลังดำเนินการ" =>
        "status-orange",

    "เสนอหัวหน้าสำนักปลัด" =>
        "status-purple",

    "เสนอผู้บริหาร" =>
        "status-red",

    "ส่งให้ผู้ที่ได้รับมอบ" =>
        "status-green",

    "เสร็จสมบูรณ์" =>
        "status-success"

];

$current_status_class =
    $status_class[$document["status"]]
    ?? "status-blue";


/* =========================
   ฟังก์ชันวันที่
========================= */
function thaiDate($date)
{
    if (!$date) {
        return "-";
    }

    $timestamp = strtotime($date);

    if (!$timestamp) {
        return "-";
    }

    return date("d/m/Y H:i", $timestamp);
}


function thaiDateOnly($date)
{
    if (!$date) {
        return "-";
    }

    $timestamp = strtotime($date);

    if (!$timestamp) {
        return "-";
    }

    return date("d/m/Y", $timestamp);
}


/* =========================
   ไอคอนไฟล์
========================= */
function fileIcon($filename)
{
    $ext = strtolower(
        pathinfo($filename, PATHINFO_EXTENSION)
    );

    switch ($ext) {

        case "pdf":
            return "📕";

        case "doc":
        case "docx":
            return "📘";

        case "xls":
        case "xlsx":
            return "📗";

        case "jpg":
        case "jpeg":
        case "png":
            return "🖼️";

        default:
            return "📎";
    }
}

?>

<!DOCTYPE html>

<html lang="th">

<head>

<meta charset="UTF-8">

<meta name="viewport"
      content="width=device-width, initial-scale=1.0">

<title>
    รายละเอียดเอกสาร | ระบบติดตามเอกสาร
</title>


<style>

/* =========================================================
   RESET
========================================================= */

* {
    box-sizing: border-box;
}


/* =========================================================
   BODY
========================================================= */

body {

    margin: 0;

    font-family:
        Tahoma,
        "Noto Sans Thai",
        sans-serif;

    background: #f4f7fb;

    color: #263238;
}


/* =========================================================
   SIDEBAR
========================================================= */

.sidebar {

    position: fixed;

    left: 0;
    top: 0;

    width: 250px;
    height: 100vh;

    background:
        linear-gradient(
            180deg,
            #0d47a1,
            #1565c0
        );

    color: white;

    padding: 25px 15px;

    box-shadow:
        4px 0 15px
        rgba(0,0,0,.10);

    z-index: 1000;
}


/* =========================================================
   LOGO
========================================================= */

.logo-area {

    text-align: center;

    padding-bottom: 25px;

    border-bottom:
        1px solid
        rgba(255,255,255,.2);
}


.logo-area img {

    width: 95px;
    height: 95px;

    border-radius: 50%;

    object-fit: cover;

    display: block;

    margin: 0 auto 15px;

    border: 4px solid #fff;

    box-shadow:
        0 4px 15px
        rgba(0,0,0,.15);
}


.logo-area h2 {

    font-size: 19px;

    margin: 0;
}


.logo-area p {

    font-size: 12px;

    opacity: .8;

    margin: 6px 0 0;
}


/* =========================================================
   MENU
========================================================= */

.menu {

    margin-top: 25px;
}


.menu a {

    display: block;

    color: white;

    text-decoration: none;

    padding: 13px 15px;

    margin-bottom: 7px;

    border-radius: 10px;

    font-size: 15px;

    transition: .2s;
}


.menu a:hover,
.menu a.active {

    background:
        rgba(255,255,255,.18);
}


.menu .logout {

    margin-top: 25px;

    background:
        rgba(198,40,40,.8);
}


.menu .logout:hover {

    background:
        rgba(183,28,28,.95);
}


/* =========================================================
   MAIN
========================================================= */

.main {

    margin-left: 250px;

    min-height: 100vh;
}


/* =========================================================
   TOPBAR
========================================================= */

.topbar {

    height: 75px;

    background: white;

    display: flex;

    align-items: center;

    justify-content: space-between;

    padding: 0 30px;

    box-shadow:
        0 2px 10px
        rgba(0,0,0,.06);
}


.topbar h1 {

    margin: 0;

    color: #0d47a1;

    font-size: 22px;
}


.user-info {

    text-align: right;
}


.user-name {

    color: #1565c0;

    font-weight: bold;

    font-size: 14px;
}


.user-department {

    color: #78909c;

    font-size: 12px;

    margin-top: 3px;
}


/* =========================================================
   CONTENT
========================================================= */

.content {

    padding: 30px;

    max-width: 1400px;

    margin: auto;
}


/* =========================================================
   PAGE HEADER
========================================================= */

.page-header {

    display: flex;

    justify-content: space-between;

    align-items: center;

    margin-bottom: 22px;

    gap: 20px;
}


.page-header h2 {

    margin: 0;

    color: #0d47a1;

    font-size: 25px;
}


.page-header p {

    margin: 6px 0 0;

    color: #78909c;

    font-size: 13px;
}


/* =========================================================
   BUTTON
========================================================= */

.btn {

    display: inline-flex;

    align-items: center;

    justify-content: center;

    gap: 7px;

    border: none;

    border-radius: 9px;

    padding: 11px 18px;

    font-size: 14px;

    font-weight: bold;

    cursor: pointer;

    text-decoration: none;

    transition: .2s;
}


.btn-blue {

    color: white;

    background:
        linear-gradient(
            135deg,
            #1565c0,
            #1e88e5
        );
}


.btn-blue:hover {

    background: #0d47a1;
}


.btn-gray {

    color: #455a64;

    background: #eceff1;
}


.btn-gray:hover {

    background: #cfd8dc;
}


/* =========================================================
   CARD
========================================================= */

.card {

    background: white;

    border-radius: 18px;

    padding: 25px;

    margin-bottom: 20px;

    box-shadow:
        0 4px 18px
        rgba(0,0,0,.06);
}


.card-title {

    color: #1565c0;

    font-size: 17px;

    font-weight: bold;

    margin-bottom: 18px;

    padding-left: 10px;

    border-left:
        4px solid
        #42a5f5;
}


/* =========================================================
   DOCUMENT HEADER
========================================================= */

.document-head {

    display: flex;

    justify-content: space-between;

    align-items: flex-start;

    gap: 20px;
}


.document-no {

    color: #78909c;

    font-size: 14px;

    margin-bottom: 7px;
}


.document-subject {

    color: #263238;

    font-size: 23px;

    font-weight: bold;

    line-height: 1.5;
}


/* =========================================================
   STATUS
========================================================= */

.status {

    display: inline-block;

    padding: 8px 16px;

    border-radius: 30px;

    font-size: 13px;

    font-weight: bold;

    white-space: nowrap;
}


.status-blue {

    background: #e3f2fd;

    color: #1565c0;
}


.status-orange {

    background: #fff3e0;

    color: #ef6c00;
}


.status-purple {

    background: #f3e5f5;

    color: #7b1fa2;
}


.status-red {

    background: #ffebee;

    color: #c62828;
}


.status-green {

    background: #e8f5e9;

    color: #2e7d32;
}


.status-success {

    background: #e0f2f1;

    color: #00695c;
}


/* =========================================================
   INFO GRID
========================================================= */

.info-grid {

    display: grid;

    grid-template-columns:
        repeat(2, 1fr);

    gap: 15px 18px;
}


.info-item {

    background: #f8fbff;

    border:
        1px solid
        #e3f2fd;

    border-radius: 10px;

    padding: 14px 16px;
}


.info-label {

    color: #78909c;

    font-size: 12px;

    margin-bottom: 6px;
}


.info-value {

    color: #263238;

    font-size: 14px;

    font-weight: 500;

    word-break: break-word;

    line-height: 1.6;
}


/* =========================================================
   TEXT BOX
========================================================= */

.text-box {

    background: #f8fbff;

    border:
        1px solid
        #e3f2fd;

    border-radius: 10px;

    padding: 17px;

    line-height: 1.8;

    font-size: 14px;

    white-space: pre-wrap;

    min-height: 60px;
}


/* =========================================================
   FILE UPLOAD / ATTACHMENT
========================================================= */

.file-list {

    display: flex;

    flex-direction: column;

    gap: 10px;
}


.file-item {

    display: flex;

    align-items: center;

    justify-content: space-between;

    gap: 15px;

    padding: 14px 16px;

    background: #f8fbff;

    border:
        1px solid
        #e3f2fd;

    border-radius: 10px;

    transition: .2s;
}


.file-item:hover {

    border-color: #90caf9;

    background: #f1f8ff;
}


.file-left {

    display: flex;

    align-items: center;

    gap: 12px;

    min-width: 0;
}


.file-icon {

    width: 42px;

    height: 42px;

    border-radius: 10px;

    background: #e3f2fd;

    display: flex;

    align-items: center;

    justify-content: center;

    font-size: 22px;

    flex-shrink: 0;
}


.file-name {

    color: #1565c0;

    font-size: 14px;

    font-weight: bold;

    word-break: break-all;
}


.file-meta {

    color: #90a4ae;

    font-size: 11px;

    margin-top: 4px;

    line-height: 1.5;
}


.file-download {

    flex-shrink: 0;

    color: #1565c0;

    background: #e3f2fd;

    text-decoration: none;

    padding: 9px 13px;

    border-radius: 8px;

    font-size: 12px;

    font-weight: bold;

    transition: .2s;
}


.file-download:hover {

    background: #bbdefb;
}


/* =========================================================
   HISTORY
========================================================= */

.timeline {

    position: relative;
}


.history-item {

    position: relative;

    padding-left: 35px;

    padding-bottom: 27px;
}


.history-item:last-child {

    padding-bottom: 0;
}


.history-item::before {

    content: "";

    position: absolute;

    left: 7px;

    top: 4px;

    width: 14px;

    height: 14px;

    border-radius: 50%;

    background: #1976d2;

    border:
        3px solid
        #e3f2fd;

    z-index: 2;
}


.history-item:not(:last-child)::after {

    content: "";

    position: absolute;

    left: 13px;

    top: 18px;

    bottom: 0;

    width: 2px;

    background: #bbdefb;
}


.history-title {

    color: #1565c0;

    font-size: 14px;

    font-weight: bold;

    line-height: 1.5;
}


.history-date {

    color: #90a4ae;

    font-size: 11px;

    margin-top: 4px;
}


.history-detail {

    margin-top: 9px;

    padding: 11px 14px;

    background: #f8fbff;

    border:
        1px solid
        #e3f2fd;

    border-radius: 9px;

    font-size: 13px;

    line-height: 1.8;
}


/* =========================================================
   EMPTY
========================================================= */

.empty-box {

    text-align: center;

    color: #90a4ae;

    padding: 28px;

    background: #f8fbff;

    border-radius: 10px;

    border:
        1px solid
        #e3f2fd;
}


/* =========================================================
   ACTIONS
========================================================= */

.page-actions {

    display: flex;

    gap: 10px;

    flex-wrap: wrap;

}


/* =========================================================
   RESPONSIVE
========================================================= */

@media (max-width: 900px) {

    .sidebar {

        width: 210px;
    }

    .main {

        margin-left: 210px;
    }

    .info-grid {

        grid-template-columns: 1fr;
    }

}


@media (max-width: 700px) {

    .sidebar {

        position: relative;

        width: 100%;

        height: auto;
    }

    .main {

        margin-left: 0;
    }

    .topbar {

        height: auto;

        padding: 18px;

        gap: 10px;
    }

    .content {

        padding: 18px;
    }

    .page-header {

        flex-direction: column;

        align-items: flex-start;
    }

    .document-head {

        flex-direction: column;
    }

    .file-item {

        flex-direction: column;

        align-items: flex-start;
    }

    .file-download {

        width: 100%;

        text-align: center;
    }

    .card {

        padding: 20px;
    }

    .document-subject {

        font-size: 19px;
    }

}

</style>

</head>


<body>


<!-- =========================================================
     SIDEBAR
========================================================= -->

<div class="sidebar">

    <div class="logo-area">

        <img
            src="oo.image/S__29155335.jpg"
            alt="โลโก้เทศบาล"
        >

        <h2>
            ระบบติดตามเอกสาร
        </h2>

        <p>
            Document Tracking System
        </p>

    </div>


    <div class="menu">

        <a href="dashboard.php">
            🏠 หน้าหลัก
        </a>


        <a href="search.php">
            🔎 ค้นหางาน
        </a>


        <a href="add_document.php">
            ➕ เพิ่มเอกสาร
        </a>


        <a
            href="documents.php"
            class="active"
        >
            📋 เอกสารทั้งหมด
        </a>


        <?php if (($_SESSION["role"] ?? "") === "admin"): ?>

            <a href="users.php">
                👥 จัดการผู้ใช้งาน
            </a>

        <?php endif; ?>


        <a
            href="logout.php"
            class="logout"
        >
            🚪 ออกจากระบบ
        </a>

    </div>

</div>



<!-- =========================================================
     MAIN
========================================================= -->

<div class="main">


    <!-- =====================================================
         TOPBAR
    ====================================================== -->

    <div class="topbar">

        <h1>
            📄 รายละเอียดเอกสาร
        </h1>


        <div class="user-info">

            <div class="user-name">

                <?= htmlspecialchars(
                    $_SESSION["full_name"] ?? ""
                ) ?>

            </div>


            <div class="user-department">

                <?= htmlspecialchars(
                    $_SESSION["department"] ?? ""
                ) ?>

            </div>

        </div>

    </div>



    <!-- =====================================================
         CONTENT
    ====================================================== -->

    <div class="content">


        <!-- =================================================
             PAGE HEADER
        ================================================== -->

        <div class="page-header">

            <div>

                <h2>
                    📄 รายละเอียดเอกสาร
                </h2>

                <p>
                    ตรวจสอบรายละเอียด เอกสารแนบ และประวัติการดำเนินงาน
                </p>

            </div>


            <div class="page-actions">

                <a
                    href="documents.php"
                    class="btn btn-gray"
                >
                    ← กลับรายการ
                </a>


                <a
                    href="edit_document.php?id=<?= $id ?>"
                    class="btn btn-blue"
                >
                    ✏️ แก้ไขเอกสาร
                </a>

            </div>

        </div>



        <!-- =================================================
             DOCUMENT HEAD
        ================================================== -->

        <div class="card">

            <div class="document-head">

                <div>

                    <div class="document-no">

                        เลขที่เอกสาร:
                        <?= htmlspecialchars(
                            $document["document_no"]
                        ) ?>

                    </div>


                    <div class="document-subject">

                        <?= htmlspecialchars(
                            $document["subject"]
                        ) ?>

                    </div>

                </div>


                <div>

                    <span
                        class="status
                        <?= $current_status_class ?>"
                    >

                        <?= htmlspecialchars(
                            $document["status"]
                        ) ?>

                    </span>

                </div>

            </div>

        </div>



        <!-- =================================================
             INFORMATION
        ================================================== -->

        <div class="card">

            <div class="card-title">
                📋 ข้อมูลเอกสาร
            </div>


            <div class="info-grid">


                <div class="info-item">

                    <div class="info-label">
                        เลขที่เอกสาร
                    </div>

                    <div class="info-value">

                        <?= htmlspecialchars(
                            $document["document_no"] ?: "-"
                        ) ?>

                    </div>

                </div>



                <div class="info-item">

                    <div class="info-label">
                        วันที่เอกสาร
                    </div>

                    <div class="info-value">

                        <?= thaiDateOnly(
                            $document["document_date"]
                        ) ?>

                    </div>

                </div>



                <div class="info-item">

                    <div class="info-label">
                        หน่วยงาน / ส่วนงาน
                    </div>

                    <div class="info-value">

                        <?= htmlspecialchars(
                            $document["department"] ?: "-"
                        ) ?>

                    </div>

                </div>



                <div class="info-item">

                    <div class="info-label">
                        ผู้รับผิดชอบ
                    </div>

                    <div class="info-value">

                        <?= htmlspecialchars(
                            $document["responsible_person"] ?: "-"
                        ) ?>

                    </div>

                </div>



                <div class="info-item">

                    <div class="info-label">
                        ผู้ส่ง
                    </div>

                    <div class="info-value">

                        <?= htmlspecialchars(
                            $document["sender"] ?: "-"
                        ) ?>

                    </div>

                </div>



                <div class="info-item">

                    <div class="info-label">
                        ผู้รับ
                    </div>

                    <div class="info-value">

                        <?= htmlspecialchars(
                            $document["receiver"] ?: "-"
                        ) ?>

                    </div>

                </div>



                <div class="info-item">

                    <div class="info-label">
                        วันที่รับเอกสาร
                    </div>

                    <div class="info-value">

                        <?= thaiDate(
                            $document["received_date"]
                        ) ?>

                    </div>

                </div>



                <div class="info-item">

                    <div class="info-label">
                        กำหนดส่ง
                    </div>

                    <div class="info-value">

                        <?= thaiDateOnly(
                            $document["due_date"]
                        ) ?>

                    </div>

                </div>



                <div class="info-item">

                    <div class="info-label">
                        สถานะ
                    </div>

                    <div class="info-value">

                        <?= htmlspecialchars(
                            $document["status"] ?: "-"
                        ) ?>

                    </div>

                </div>



                <div class="info-item">

                    <div class="info-label">
                        ความเร่งด่วน
                    </div>

                    <div class="info-value">

                        <?= htmlspecialchars(
                            $document["priority"] ?: "-"
                        ) ?>

                    </div>

                </div>



                <div class="info-item">

                    <div class="info-label">
                        ผู้บันทึก
                    </div>

                    <div class="info-value">

                        <?= htmlspecialchars(
                            $document["created_by_name"] ?: "-"
                        ) ?>

                    </div>

                </div>



                <div class="info-item">

                    <div class="info-label">
                        วันที่สร้าง
                    </div>

                    <div class="info-value">

                        <?= thaiDate(
                            $document["created_at"]
                        ) ?>

                    </div>

                </div>



                <div class="info-item">

                    <div class="info-label">
                        แก้ไขล่าสุด
                    </div>

                    <div class="info-value">

                        <?= thaiDate(
                            $document["updated_at"]
                        ) ?>

                    </div>

                </div>


            </div>

        </div>



        <!-- =================================================
             DETAIL
        ================================================== -->

        <?php if (!empty($document["detail"])): ?>

            <div class="card">

                <div class="card-title">
                    📝 รายละเอียด / การดำเนินการ
                </div>


                <div class="text-box">

                    <?= htmlspecialchars(
                        $document["detail"]
                    ) ?>

                </div>

            </div>

        <?php endif; ?>



        <!-- =================================================
             RESULT
        ================================================== -->

        <?php if (!empty($document["result"])): ?>

            <div class="card">

                <div class="card-title">
                    ✅ ผลการดำเนินงาน
                </div>


                <div class="text-box">

                    <?= htmlspecialchars(
                        $document["result"]
                    ) ?>

                </div>

            </div>

        <?php endif; ?>



        <!-- =================================================
             FILES
        ================================================== -->

        <div class="card">

            <div class="card-title">
                📎 เอกสารแนบ
            </div>


            <?php if (count($files) > 0): ?>


                <div class="file-list">


                    <?php foreach ($files as $file): ?>


                        <div class="file-item">


                            <div class="file-left">


                                <div class="file-icon">

                                    <?= fileIcon(
                                        $file["file_name"]
                                    ) ?>

                                </div>


                                <div>


                                    <div class="file-name">

                                        <?= htmlspecialchars(
                                            $file["file_name"]
                                        ) ?>

                                    </div>


                                    <div class="file-meta">

                                        อัปโหลดโดย

                                        <?= htmlspecialchars(
                                            $file["uploaded_by_name"]
                                            ?: "-"
                                        ) ?>

                                        ·

                                        <?= thaiDate(
                                            $file["uploaded_at"]
                                        ) ?>

                                    </div>


                                </div>


                            </div>


                            <a
                                href="<?= htmlspecialchars(
                                    $file["file_path"]
                                ) ?>"
                                target="_blank"
                                class="file-download"
                            >

                                📥 เปิดไฟล์

                            </a>


                        </div>


                    <?php endforeach; ?>


                </div>


            <?php else: ?>


                <div class="empty-box">

                    📎 ยังไม่มีเอกสารแนบ

                </div>


            <?php endif; ?>


        </div>



        <!-- =================================================
             HISTORY
        ================================================== -->

        <div class="card">

            <div class="card-title">
                🔄 ประวัติการดำเนินงาน
            </div>


            <?php if (count($history) > 0): ?>


                <div class="timeline">


                    <?php foreach ($history as $item): ?>


                        <div class="history-item">


                            <div class="history-title">

                                <?= htmlspecialchars(
                                    $item["action"]
                                ) ?>

                            </div>


                            <div class="history-date">

                                <?= thaiDate(
                                    $item["action_date"]
                                ) ?>

                                ·

                                <?= htmlspecialchars(
                                    $item["action_by_name"]
                                    ?: "-"
                                ) ?>

                            </div>


                            <div class="history-detail">


                                <?php if (
                                    !empty($item["from_department"]) ||
                                    !empty($item["to_department"])
                                ): ?>


                                    <div>

                                        <strong>
                                            ส่วนงาน:
                                        </strong>

                                        <?= htmlspecialchars(
                                            $item["from_department"]
                                            ?: "-"
                                        ) ?>

                                        →

                                        <?= htmlspecialchars(
                                            $item["to_department"]
                                            ?: "-"
                                        ) ?>

                                    </div>


                                <?php endif; ?>


                                <?php if (
                                    !empty($item["from_person"]) ||
                                    !empty($item["to_person"])
                                ): ?>


                                    <div>

                                        <strong>
                                            ผู้รับผิดชอบ:
                                        </strong>

                                        <?= htmlspecialchars(
                                            $item["from_person"]
                                            ?: "-"
                                        ) ?>

                                        →

                                        <?= htmlspecialchars(
                                            $item["to_person"]
                                            ?: "-"
                                        ) ?>

                                    </div>


                                <?php endif; ?>


                                <?php if (!empty($item["note"])): ?>


                                    <div>

                                        <strong>
                                            หมายเหตุ:
                                        </strong>

                                        <?= nl2br(
                                            htmlspecialchars(
                                                $item["note"]
                                            )
                                        ) ?>

                                    </div>


                                <?php endif; ?>


                            </div>


                        </div>


                    <?php endforeach; ?>


                </div>


            <?php else: ?>


                <div class="empty-box">

                    🔄 ยังไม่มีประวัติการดำเนินงาน

                </div>


            <?php endif; ?>


        </div>


    </div>

</div>


</body>

</html>