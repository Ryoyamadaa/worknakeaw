<?php

error_reporting(E_ALL);
ini_set('display_errors', 1);

require_once "config.php";

/*
|--------------------------------------------------------------------------
| ตรวจสอบ Login
|--------------------------------------------------------------------------
*/

if (!isset($_SESSION["user_id"])) {
    header("Location: login.php");
    exit;
}

/*
|--------------------------------------------------------------------------
| ป้องกัน Admin เข้าหน้า User
|--------------------------------------------------------------------------
*/

if ($_SESSION["role"] !== "user") {
    header("Location: dashboard.php");
    exit;
}

/*
|--------------------------------------------------------------------------
| สถานะทั้งหมด
|--------------------------------------------------------------------------
*/

$statuses = [
    "ลงรับแล้ว",
    "กำลังดำเนินการ",
    "เสนอหัวหน้าสำนักปลัด",
    "เสนอผู้บริหาร",
    "ส่งให้ผู้ที่ได้รับมอบ",
    "เสร็จสมบูรณ์"
];

/*
|--------------------------------------------------------------------------
| นับจำนวนเอกสารแต่ละสถานะ
|--------------------------------------------------------------------------
*/

$status_count = [];

foreach ($statuses as $status) {

    $stmt = $pdo->prepare("
        SELECT COUNT(*) 
        FROM documents
        WHERE status = ?
    ");

    $stmt->execute([$status]);

    $status_count[$status] = (int)$stmt->fetchColumn();
}

/*
|--------------------------------------------------------------------------
| จำนวนเอกสารทั้งหมด
|--------------------------------------------------------------------------
*/

$total_documents = array_sum($status_count);

/*
|--------------------------------------------------------------------------
| เอกสารล่าสุด
|--------------------------------------------------------------------------
*/

$stmt = $pdo->query("
    SELECT
        id,
        document_no,
        subject,
        department,
        responsible_person,
        received_date,
        status,
        priority
    FROM documents
    ORDER BY id DESC
    LIMIT 10
");

$documents = $stmt->fetchAll();

?>
<!DOCTYPE html>
<html lang="th">

<head>

<meta charset="UTF-8">

<meta name="viewport"
      content="width=device-width, initial-scale=1.0">

<title>User Dashboard | ระบบติดตามเอกสาร</title>

<style>

*{
    box-sizing:border-box;
}

body{
    margin:0;
    font-family:Tahoma,"Noto Sans Thai",sans-serif;
    background:#f4f7fb;
    color:#263238;
}

/* =========================
   SIDEBAR
========================= */

.sidebar{
    position:fixed;
    left:0;
    top:0;
    width:250px;
    height:100vh;

    background:linear-gradient(
        180deg,
        #0d47a1,
        #1565c0
    );

    color:white;
    padding:25px 15px;

    overflow-y:auto;
}

.logo-area{
    text-align:center;
    padding-bottom:25px;

    border-bottom:
        1px solid rgba(255,255,255,.2);
}

.logo-icon{
    width:65px;
    height:65px;

    margin:0 auto 12px;

    border-radius:50%;

    background:white;

    color:#1565c0;

    display:flex;
    align-items:center;
    justify-content:center;

    font-size:28px;

    box-shadow:
        0 5px 15px rgba(0,0,0,.12);
}

.logo-area h2{
    font-size:19px;
    margin:0;
}

.logo-area p{
    font-size:12px;
    margin-top:6px;
    opacity:.8;
}

.menu{
    margin-top:25px;
}

.menu a{
    display:block;

    color:white;

    text-decoration:none;

    padding:13px 15px;

    margin-bottom:7px;

    border-radius:10px;

    transition:.2s;

    font-size:15px;
}

.menu a:hover,
.menu a.active{
    background:
        rgba(255,255,255,.18);
}

.menu .logout{
    margin-top:25px;

    background:
        rgba(198,40,40,.8);
}

.menu .logout:hover{
    background:
        rgba(183,28,28,.95);
}

/* =========================
   MAIN
========================= */

.main{
    margin-left:250px;
    min-height:100vh;
}

/* =========================
   TOPBAR
========================= */

.topbar{
    height:75px;

    background:white;

    display:flex;

    align-items:center;

    justify-content:space-between;

    padding:0 30px;

    box-shadow:
        0 2px 12px rgba(0,0,0,.05);
}

.topbar h1{
    margin:0;

    color:#0759a5;

    font-size:23px;
}

.user-box{
    display:flex;

    align-items:center;

    gap:12px;
}

.user-icon{
    width:42px;
    height:42px;

    border-radius:50%;

    background:#e5f2ff;

    display:flex;

    align-items:center;
    justify-content:center;

    font-size:20px;
}

.user-name{
    font-weight:700;
}

.user-dept{
    font-size:12px;

    color:#64748b;
}

/* =========================
   CONTENT
========================= */

.content{
    padding:30px;
}

/* =========================
   WELCOME
========================= */

.welcome-card{
    background:
        linear-gradient(
            135deg,
            #0759a5,
            #1683dc
        );

    color:white;

    border-radius:18px;

    padding:28px;

    margin-bottom:25px;

    box-shadow:
        0 8px 25px
        rgba(21,101,192,.18);
}

.welcome-card h2{
    margin:0 0 8px;

    font-size:25px;
}

.welcome-card p{
    margin:0;

    opacity:.9;

    font-size:14px;
}

/* =========================
   STAT GRID
========================= */

.stat-grid{
    display:grid;

    grid-template-columns:
        repeat(3,1fr);

    gap:18px;

    margin-bottom:25px;
}

.stat-card{
    background:white;

    border-radius:16px;

    padding:22px;

    display:flex;

    align-items:center;

    gap:16px;

    box-shadow:
        0 5px 20px
        rgba(30,64,175,.07);

    border:
        1px solid #e5edf7;
}

.stat-icon{
    width:52px;
    height:52px;

    border-radius:14px;

    display:flex;

    align-items:center;
    justify-content:center;

    font-size:25px;

    background:#e3f2fd;
}

.stat-number{
    font-size:27px;

    font-weight:700;

    color:#0759a5;
}

.stat-label{
    font-size:13px;

    color:#64748b;

    margin-top:3px;
}

/* =========================
   QUICK MENU
========================= */

.quick-card{
    background:white;

    border-radius:16px;

    padding:23px;

    margin-bottom:25px;

    box-shadow:
        0 5px 20px
        rgba(30,64,175,.07);

    border:
        1px solid #e5edf7;
}

.quick-title{
    color:#0759a5;

    font-size:18px;

    font-weight:700;

    margin-bottom:17px;
}

.quick-grid{
    display:grid;

    grid-template-columns:
        repeat(3,1fr);

    gap:12px;
}

.quick-btn{
    display:block;

    text-decoration:none;

    background:#f4f9ff;

    border:
        1px solid #dcecff;

    color:#0759a5;

    padding:15px;

    border-radius:12px;

    text-align:center;

    font-weight:600;

    transition:.2s;
}

.quick-btn:hover{
    background:#e3f2fd;

    transform:translateY(-2px);
}

/* =========================
   DOCUMENT TABLE
========================= */

.table-card{
    background:white;

    border-radius:16px;

    padding:25px;

    box-shadow:
        0 5px 20px
        rgba(30,64,175,.07);

    border:
        1px solid #e5edf7;
}

.table-header{
    display:flex;

    align-items:center;

    justify-content:space-between;

    margin-bottom:20px;
}

.table-header h2{
    margin:0;

    font-size:19px;

    color:#263238;
}

.table-header p{
    margin:5px 0 0;

    font-size:13px;

    color:#64748b;
}

.btn{
    display:inline-block;

    text-decoration:none;

    border:none;

    border-radius:10px;

    padding:10px 16px;

    font-size:13px;

    font-weight:600;

    cursor:pointer;
}

.btn-blue{
    background:#1565c0;
    color:white;
}

.btn-blue:hover{
    background:#0d47a1;
}

.table-wrap{
    overflow-x:auto;
}

table{
    width:100%;

    border-collapse:collapse;

    min-width:900px;
}

th{
    background:#e3f2fd;

    color:#0d47a1;

    padding:13px;

    text-align:left;

    font-size:13px;

    white-space:nowrap;
}

td{
    padding:13px;

    border-bottom:
        1px solid #edf1f5;

    font-size:13px;

    vertical-align:middle;
}

tr:hover td{
    background:#f8fbff;
}

/* =========================
   STATUS
========================= */

.status{
    display:inline-block;

    padding:6px 10px;

    border-radius:20px;

    font-size:11px;

    font-weight:700;

    white-space:nowrap;
}

.status-received{
    background:#dbeafe;
    color:#1d4ed8;
}

.status-progress{
    background:#ffedd5;
    color:#c2410c;
}

.status-head{
    background:#ede9fe;
    color:#6d28d9;
}

.status-manager{
    background:#f3e8ff;
    color:#7e22ce;
}

.status-assigned{
    background:#e0f2fe;
    color:#0369a1;
}

.status-complete{
    background:#dcfce7;
    color:#15803d;
}

/* =========================
   PRIORITY
========================= */

.priority{
    display:inline-block;

    padding:5px 9px;

    border-radius:15px;

    font-size:11px;

    font-weight:700;
}

.priority-normal{
    background:#f1f5f9;
    color:#475569;
}

.priority-urgent{
    background:#fef3c7;
    color:#92400e;
}

.priority-very-urgent{
    background:#fed7aa;
    color:#c2410c;
}

.priority-highest{
    background:#fee2e2;
    color:#b91c1c;
}

/* =========================
   VIEW BUTTON
========================= */

.view-btn{
    display:inline-block;

    padding:7px 11px;

    border-radius:8px;

    background:#e3f2fd;

    color:#1565c0;

    text-decoration:none;

    font-size:11px;

    font-weight:700;
}

.view-btn:hover{
    background:#bbdefb;
}

/* =========================
   EMPTY
========================= */

.empty{
    text-align:center;

    padding:45px 20px;

    color:#90a4ae;
}

.empty-icon{
    font-size:45px;

    margin-bottom:10px;
}

/* =========================
   RESPONSIVE
========================= */

@media(max-width:1000px){

    .stat-grid{
        grid-template-columns:
            repeat(2,1fr);
    }

    .quick-grid{
        grid-template-columns:
            repeat(2,1fr);
    }

}

@media(max-width:700px){

    .sidebar{
        position:relative;

        width:100%;

        height:auto;
    }

    .main{
        margin-left:0;
    }

    .topbar{
        height:auto;

        padding:18px;

        flex-direction:column;

        align-items:flex-start;

        gap:15px;
    }

    .content{
        padding:18px;
    }

    .stat-grid{
        grid-template-columns:1fr;
    }

    .quick-grid{
        grid-template-columns:1fr;
    }

    .table-header{
        flex-direction:column;

        align-items:flex-start;

        gap:15px;
    }

}

</style>

</head>

<body>

<!-- =========================
     SIDEBAR
========================= -->

<div class="sidebar">

    <div class="logo-area">

        <div class="logo-icon">
            📄
        </div>

        <h2>
            ระบบติดตามเอกสาร
        </h2>

        <p>
            Document Tracking System
        </p>

    </div>

    <div class="menu">

        <a href="user_dashboard.php"
           class="active">
            🏠 หน้าหลัก
        </a>

        <a href="search.php">
            🔎 ค้นหางาน
        </a>

        <a href="add_document.php">
            ➕ เพิ่มเอกสาร
        </a>

        <a href="documents.php">
            📋 เอกสารทั้งหมด
        </a>

        <a href="logout.php"
           class="logout">
            🚪 ออกจากระบบ
        </a>

    </div>

</div>


<!-- =========================
     MAIN
========================= -->

<div class="main">


    <!-- TOPBAR -->

    <div class="topbar">

        <h1>
            🏠 หน้าหลักผู้ใช้งาน
        </h1>

        <div class="user-box">

            <div class="user-icon">
                👤
            </div>

            <div>

                <div class="user-name">
                    <?= htmlspecialchars($_SESSION["full_name"]) ?>
                </div>

                <div class="user-dept">
                    <?= htmlspecialchars($_SESSION["department"]) ?>
                </div>

            </div>

        </div>

    </div>


    <!-- CONTENT -->

    <div class="content">


        <!-- WELCOME -->

        <div class="welcome-card">

            <h2>
                👋 ยินดีต้อนรับ
                <?= htmlspecialchars($_SESSION["full_name"]) ?>
            </h2>

            <p>
                ระบบติดตามเอกสาร
                สำหรับการติดตามสถานะและประวัติการดำเนินงาน
            </p>

        </div>


        <!-- STAT -->

        <div class="stat-grid">


            <div class="stat-card">

                <div class="stat-icon">
                    📋
                </div>

                <div>

                    <div class="stat-number">
                        <?= $total_documents ?>
                    </div>

                    <div class="stat-label">
                        เอกสารทั้งหมด
                    </div>

                </div>

            </div>


            <div class="stat-card">

                <div class="stat-icon">
                    📥
                </div>

                <div>

                    <div class="stat-number">
                        <?= $status_count["ลงรับแล้ว"] ?>
                    </div>

                    <div class="stat-label">
                        ลงรับแล้ว
                    </div>

                </div>

            </div>


            <div class="stat-card">

                <div class="stat-icon">
                    ⚙️
                </div>

                <div>

                    <div class="stat-number">
                        <?= $status_count["กำลังดำเนินการ"] ?>
                    </div>

                    <div class="stat-label">
                        กำลังดำเนินการ
                    </div>

                </div>

            </div>


            <div class="stat-card">

                <div class="stat-icon">
                    👨‍💼
                </div>

                <div>

                    <div class="stat-number">
                        <?= $status_count["เสนอหัวหน้าสำนักปลัด"] ?>
                    </div>

                    <div class="stat-label">
                        เสนอหัวหน้าสำนักปลัด
                    </div>

                </div>

            </div>


            <div class="stat-card">

                <div class="stat-icon">
                    🏢
                </div>

                <div>

                    <div class="stat-number">
                        <?= $status_count["เสนอผู้บริหาร"] ?>
                    </div>

                    <div class="stat-label">
                        เสนอผู้บริหาร
                    </div>

                </div>

            </div>


            <div class="stat-card">

                <div class="stat-icon">
                    ✅
                </div>

                <div>

                    <div class="stat-number">
                        <?= $status_count["เสร็จสมบูรณ์"] ?>
                    </div>

                    <div class="stat-label">
                        เสร็จสมบูรณ์
                    </div>

                </div>

            </div>


        </div>


        <!-- QUICK MENU -->

        <div class="quick-card">

            <div class="quick-title">
                ⚡ เมนูใช้งานด่วน
            </div>

            <div class="quick-grid">

                <a href="add_document.php"
                   class="quick-btn">
                    ➕ เพิ่มเอกสารใหม่
                </a>

                <a href="search.php"
                   class="quick-btn">
                    🔎 ค้นหาเอกสาร
                </a>

                <a href="documents.php"
                   class="quick-btn">
                    📋 ดูเอกสารทั้งหมด
                </a>

            </div>

        </div>


        <!-- LATEST DOCUMENT -->

        <div class="table-card">

            <div class="table-header">

                <div>

                    <h2>
                        📋 เอกสารล่าสุด
                    </h2>

                    <p>
                        รายการเอกสารที่เพิ่มเข้าสู่ระบบล่าสุด
                    </p>

                </div>

                <a href="documents.php"
                   class="btn btn-blue">
                    ดูทั้งหมด →
                </a>

            </div>


            <div class="table-wrap">

            <?php if (count($documents) > 0): ?>

                <table>

                    <thead>

                        <tr>

                            <th>
                                เลขที่เอกสาร
                            </th>

                            <th>
                                เรื่อง
                            </th>

                            <th>
                                หน่วยงาน
                            </th>

                            <th>
                                ผู้รับผิดชอบ
                            </th>

                            <th>
                                วันที่รับ
                            </th>

                            <th>
                                ความเร่งด่วน
                            </th>

                            <th>
                                สถานะ
                            </th>

                            <th>
                                ดู
                            </th>

                        </tr>

                    </thead>


                    <tbody>

                    <?php foreach ($documents as $document): ?>

                        <?php

                        $status_class = "status-received";

                        if ($document["status"] === "กำลังดำเนินการ") {
                            $status_class = "status-progress";
                        }

                        elseif (
                            $document["status"] ===
                            "เสนอหัวหน้าสำนักปลัด"
                        ) {
                            $status_class = "status-head";
                        }

                        elseif (
                            $document["status"] ===
                            "เสนอผู้บริหาร"
                        ) {
                            $status_class = "status-manager";
                        }

                        elseif (
                            $document["status"] ===
                            "ส่งให้ผู้ที่ได้รับมอบ"
                        ) {
                            $status_class = "status-assigned";
                        }

                        elseif (
                            $document["status"] ===
                            "เสร็จสมบูรณ์"
                        ) {
                            $status_class = "status-complete";
                        }


                        $priority_class =
                            "priority-normal";

                        if ($document["priority"] === "ด่วน") {
                            $priority_class =
                                "priority-urgent";
                        }

                        elseif (
                            $document["priority"] === "ด่วนมาก"
                        ) {
                            $priority_class =
                                "priority-very-urgent";
                        }

                        elseif (
                            $document["priority"] === "ด่วนที่สุด"
                        ) {
                            $priority_class =
                                "priority-highest";
                        }

                        ?>

                        <tr>

                            <td>
                                <strong>
                                    <?= htmlspecialchars(
                                        $document["document_no"]
                                    ) ?>
                                </strong>
                            </td>

                            <td>
                                <?= htmlspecialchars(
                                    $document["subject"]
                                ) ?>
                            </td>

                            <td>
                                <?= htmlspecialchars(
                                    $document["department"] ?: "-"
                                ) ?>
                            </td>

                            <td>
                                <?= htmlspecialchars(
                                    $document["responsible_person"] ?: "-"
                                ) ?>
                            </td>

                            <td>

                                <?php if (
                                    !empty(
                                        $document["received_date"]
                                    )
                                ): ?>

                                    <?= date(
                                        "d/m/Y H:i",
                                        strtotime(
                                            $document["received_date"]
                                        )
                                    ) ?>

                                <?php else: ?>

                                    -

                                <?php endif; ?>

                            </td>

                            <td>

                                <span class="
                                    priority
                                    <?= $priority_class ?>
                                ">
                                    <?= htmlspecialchars(
                                        $document["priority"]
                                    ) ?>
                                </span>

                            </td>

                            <td>

                                <span class="
                                    status
                                    <?= $status_class ?>
                                ">
                                    <?= htmlspecialchars(
                                        $document["status"]
                                    ) ?>
                                </span>

                            </td>

                            <td>

                                <a
                                    href="document.php?id=<?= (int)$document["id"] ?>"
                                    class="view-btn"
                                >
                                    👁 ดู
                                </a>

                            </td>

                        </tr>

                    <?php endforeach; ?>

                    </tbody>

                </table>

            <?php else: ?>

                <div class="empty">

                    <div class="empty-icon">
                        📄
                    </div>

                    ยังไม่มีเอกสารในระบบ

                </div>

            <?php endif; ?>

            </div>

        </div>


    </div>

</div>

</body>

</html>