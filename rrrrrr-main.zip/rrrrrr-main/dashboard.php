<?php

require_once "config.php";

/* ถ้ายังไม่ได้ Login ให้กลับไปหน้า Login */
if (!isset($_SESSION["user_id"])) {
    header("Location: login.php");
    exit;
}

/* สถานะทั้ง 6 ของระบบ */
$statuses = [
    "ลงรับแล้ว",
    "กำลังดำเนินการ",
    "เสนอหัวหน้าสำนักปลัด",
    "เสนอผู้บริหาร",
    "ส่งให้ผู้ที่ได้รับมอบ",
    "เสร็จสมบูรณ์"
];

/* นับเอกสารทั้งหมด */
$stmt = $pdo->query("
    SELECT COUNT(*) AS total
    FROM documents
");

$total_documents = $stmt->fetch()["total"];

/* นับตามสถานะ */
$status_counts = [];

foreach ($statuses as $status) {

    $stmt = $pdo->prepare("
        SELECT COUNT(*) AS total
        FROM documents
        WHERE status = ?
    ");

    $stmt->execute([$status]);

    $status_counts[$status] = $stmt->fetch()["total"];
}

/* เอกสารล่าสุด 10 รายการ */
$stmt = $pdo->query("
    SELECT
        d.id,
        d.document_no,
        d.subject,
        d.department,
        d.responsible_person,
        d.status,
        d.priority,
        d.received_date
    FROM documents d
    ORDER BY d.id DESC
    LIMIT 10
");

$documents = $stmt->fetchAll();

?>

<!DOCTYPE html>
<html lang="th">

<head>

<meta charset="UTF-8">

<meta name="viewport"
      content="width=device-width, initial-scale=1.0">

<title>Dashboard | ระบบติดตามเอกสาร</title>

<style>

* {
    box-sizing: border-box;
}

body {
    margin: 0;
    font-family:
        Tahoma,
        "Noto Sans Thai",
        sans-serif;

    background: #f4f7fb;
    color: #263238;
}

/* =========================
   Sidebar
========================= */

.sidebar {

    position: fixed;

    left: 0;
    top: 0;

    width: 250px;
    height: 100vh;

    background:
        linear-gradient(
            180deg,
            #0d47a1,
            #1565c0
        );

    color: white;

    padding: 25px 15px;

    overflow-y: auto;
}

.logo-area {

    text-align: center;

    padding-bottom: 25px;

    border-bottom:
        1px solid
        rgba(255,255,255,0.2);
}

.logo-icon {

    width: 65px;
    height: 65px;

    margin: auto;

    border-radius: 50%;

    background: white;

    color: #1565c0;

    display: flex;

    align-items: center;

    justify-content: center;

    font-size: 28px;

    margin-bottom: 12px;
}

.logo-area h2 {

    font-size: 19px;

    margin: 0;

}

.logo-area p {

    font-size: 12px;

    margin-top: 6px;

    opacity: .8;

}

.menu {

    margin-top: 25px;
}

.menu a {

    display: block;

    color: white;

    text-decoration: none;

    padding: 13px 15px;

    margin-bottom: 7px;

    border-radius: 10px;

    transition: .2s;

    font-size: 15px;
}

.menu a:hover,
.menu a.active {

    background:
        rgba(255,255,255,.18);

}

.menu .logout {

    margin-top: 25px;

    background:
        rgba(198,40,40,.8);
}

/* =========================
   Main
========================= */

.main {

    margin-left: 250px;

    min-height: 100vh;

}

/* =========================
   Topbar
========================= */

.topbar {

    background: white;

    height: 75px;

    display: flex;

    align-items: center;

    justify-content: space-between;

    padding: 0 30px;

    box-shadow:
        0 2px 10px
        rgba(0,0,0,.06);
}

.topbar h1 {

    margin: 0;

    font-size: 22px;

    color: #0d47a1;
}

.user-info {

    text-align: right;

    font-size: 14px;
}

.user-name {

    font-weight: bold;

    color: #1565c0;
}

.user-department {

    color: #78909c;

    font-size: 12px;

    margin-top: 3px;
}

/* =========================
   Content
========================= */

.content {

    padding: 30px;
}

/* =========================
   Welcome
========================= */

.welcome {

    background:
        linear-gradient(
            135deg,
            #1565c0,
            #42a5f5
        );

    color: white;

    border-radius: 18px;

    padding: 25px 30px;

    margin-bottom: 25px;

    box-shadow:
        0 10px 25px
        rgba(21,101,192,.18);
}

.welcome h2 {

    margin: 0 0 7px;

    font-size: 24px;
}

.welcome p {

    margin: 0;

    opacity: .9;
}

/* =========================
   Statistics
========================= */

.stats {

    display: grid;

    grid-template-columns:
        repeat(3, 1fr);

    gap: 18px;

    margin-bottom: 25px;
}

.stat-card {

    background: white;

    border-radius: 15px;

    padding: 20px;

    box-shadow:
        0 3px 15px
        rgba(0,0,0,.06);

    border-left: 5px solid #1976d2;
}

.stat-card h3 {

    margin: 0;

    font-size: 14px;

    color: #607d8b;

    font-weight: normal;
}

.stat-number {

    font-size: 32px;

    font-weight: bold;

    color: #1565c0;

    margin-top: 8px;
}

/* =========================
   Status cards
========================= */

.status-grid {

    display: grid;

    grid-template-columns:
        repeat(3, 1fr);

    gap: 15px;

    margin-bottom: 30px;
}

.status-card {

    background: white;

    border-radius: 14px;

    padding: 18px;

    box-shadow:
        0 3px 12px
        rgba(0,0,0,.05);

    display: flex;

    align-items: center;

    justify-content: space-between;
}

.status-name {

    font-size: 14px;

    color: #455a64;

}

.status-count {

    font-size: 25px;

    font-weight: bold;

    color: #1565c0;
}

/* สีสถานะ */

.status-1 {
    border-left: 5px solid #42a5f5;
}

.status-2 {
    border-left: 5px solid #ffb300;
}

.status-3 {
    border-left: 5px solid #fb8c00;
}

.status-4 {
    border-left: 5px solid #8e24aa;
}

.status-5 {
    border-left: 5px solid #00897b;
}

.status-6 {
    border-left: 5px solid #43a047;
}

/* =========================
   Table
========================= */

.table-card {

    background: white;

    border-radius: 16px;

    padding: 25px;

    box-shadow:
        0 3px 15px
        rgba(0,0,0,.06);

}

.table-header {

    display: flex;

    justify-content: space-between;

    align-items: center;

    margin-bottom: 20px;
}

.table-header h2 {

    margin: 0;

    color: #263238;

    font-size: 19px;
}

.search-button {

    background: #1565c0;

    color: white;

    text-decoration: none;

    padding: 10px 17px;

    border-radius: 9px;

    font-size: 14px;
}

.search-button:hover {

    background: #0d47a1;
}

table {

    width: 100%;

    border-collapse: collapse;

}

th {

    background: #e3f2fd;

    color: #0d47a1;

    padding: 13px 10px;

    text-align: left;

    font-size: 13px;
}

td {

    padding: 13px 10px;

    border-bottom:
        1px solid #eeeeee;

    font-size: 13px;
}

tr:hover td {

    background: #f8fbff;
}

/* =========================
   Status badge
========================= */

.badge {

    display: inline-block;

    padding: 6px 10px;

    border-radius: 20px;

    font-size: 11px;

    background: #e3f2fd;

    color: #1565c0;

    white-space: nowrap;
}

.priority {

    font-size: 11px;

    font-weight: bold;
}

.view-button {

    color: #1565c0;

    text-decoration: none;

    font-weight: bold;
}

/* =========================
   Responsive
========================= */

@media (max-width: 1000px) {

    .stats,
    .status-grid {

        grid-template-columns:
            repeat(2, 1fr);

    }
}

@media (max-width: 700px) {

    .sidebar {

        position: relative;

        width: 100%;

        height: auto;
    }

    .main {

        margin-left: 0;
    }

    .stats,
    .status-grid {

        grid-template-columns: 1fr;

    }

    .topbar {

        height: auto;

        padding: 18px;

        gap: 10px;

    }

    .content {

        padding: 18px;

    }

    .table-card {

        overflow-x: auto;

    }

    table {

        min-width: 900px;

    }
}

</style>

</head>

<body>


<!-- =========================
     Sidebar
========================= -->

<div class="sidebar">

    <div class="logo-area">

        <img src="oo.image/S__29155335.jpg"
     alt="โลโก้เทศบาล"
     style="
        width:95px;
        height:95px;
        border-radius:50%;
        object-fit:cover;
        display:block;
        margin:0 auto 15px;
        border:4px solid #fff;
        box-shadow:0 4px 15px rgba(0,0,0,.15);
     ">

        <h2>
            ระบบติดตามเอกสาร
        </h2>

        <p>
            Document Tracking System
        </p>

    </div>


    <div class="menu">

        <a href="dashboard.php"
           class="active">
            🏠 หน้าหลัก
        </a>

        <a href="search.php">
            🔎 ค้นหางาน
        </a>

        <a href="add_document.php">
            ➕ เพิ่มเอกสาร
        </a>

        <a href="documents.php">
            📋 เอกสารทั้งหมด
        </a>

        <?php if ($_SESSION["role"] === "admin"): ?>

            <a href="users.php">
                👥 จัดการผู้ใช้งาน
            </a>

        <?php endif; ?>

        <a href="logout.php"
           class="logout">
            🚪 ออกจากระบบ
        </a>

    </div>

</div>


<!-- =========================
     Main
========================= -->

<div class="main">


    <!-- Topbar -->

    <div class="topbar">

        <h1>
            🏠 หน้าหลัก
        </h1>

        <div class="user-info">

            <div class="user-name">

                <?= htmlspecialchars(
                    $_SESSION["full_name"]
                ) ?>

            </div>

            <div class="user-department">

                <?= htmlspecialchars(
                    $_SESSION["department"]
                ) ?>

            </div>

        </div>

    </div>


    <!-- Content -->

    <div class="content">


        <!-- Welcome -->

        <div class="welcome">

            <h2>
                ยินดีต้อนรับเข้าสู่ระบบ
            </h2>

            <p>
                ระบบติดตามและตรวจสอบสถานะการดำเนินงานของเอกสาร
            </p>

        </div>


        <!-- Total -->

        <div class="stats">

            <div class="stat-card">

                <h3>
                    เอกสารทั้งหมด
                </h3>

                <div class="stat-number">
                    <?= $total_documents ?>
                </div>

            </div>

        </div>


        <!-- Status -->

        <div class="status-grid">

            <?php

            $i = 1;

            foreach ($statuses as $status):

            ?>

                <div class="status-card status-<?= $i ?>">

                    <div class="status-name">

                        <?= htmlspecialchars($status) ?>

                    </div>

                    <div class="status-count">

                        <?= $status_counts[$status] ?>

                    </div>

                </div>

            <?php

                $i++;

            endforeach;

            ?>

        </div>


        <!-- Latest documents -->

        <div class="table-card">

            <div class="table-header">

                <h2>
                    📋 เอกสารล่าสุด
                </h2>

                <a href="search.php"
                   class="search-button">
                    🔎 ค้นหางาน
                </a>

            </div>


            <?php if (count($documents) > 0): ?>

            <table>

                <thead>

                    <tr>

                        <th>
                            เลขที่หนังสือ
                        </th>

                        <th>
                            เรื่อง
                        </th>

                        <th>
                            หน่วยงาน
                        </th>

                        <th>
                            ผู้รับผิดชอบ
                        </th>

                        <th>
                            สถานะ
                        </th>

                        <th>
                            วันที่รับ
                        </th>

                        <th>
                            ดู
                        </th>

                    </tr>

                </thead>

                <tbody>

                <?php foreach ($documents as $doc): ?>

                    <tr>

                        <td>
                            <?= htmlspecialchars(
                                $doc["document_no"]
                            ) ?>
                        </td>

                        <td>
                            <?= htmlspecialchars(
                                $doc["subject"]
                            ) ?>
                        </td>

                        <td>
                            <?= htmlspecialchars(
                                $doc["department"]
                            ) ?>
                        </td>

                        <td>
                            <?= htmlspecialchars(
                                $doc["responsible_person"]
                            ) ?>
                        </td>

                        <td>

                            <span class="badge">

                                <?= htmlspecialchars(
                                    $doc["status"]
                                ) ?>

                            </span>

                        </td>

                        <td>

                            <?= $doc["received_date"]
                                ? date(
                                    "d/m/Y H:i",
                                    strtotime(
                                        $doc["received_date"]
                                    )
                                )
                                : "-"
                            ?>

                        </td>

                        <td>

                            <a
                                href="document.php?id=<?= $doc["id"] ?>"
                                class="view-button"
                            >
                                ดู
                            </a>

                        </td>

                    </tr>

                <?php endforeach; ?>

                </tbody>

            </table>

            <?php else: ?>

                <div style="
                    text-align:center;
                    padding:40px;
                    color:#90a4ae;
                ">

                    ยังไม่มีเอกสารในระบบ

                    <br><br>

                    <a href="add_document.php"
                       class="search-button">
                        ➕ เพิ่มเอกสารแรก
                    </a>

                </div>

            <?php endif; ?>

        </div>


    </div>

</div>

</body>

</html>