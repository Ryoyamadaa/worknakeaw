<?php

require_once "config.php";

$username = "admin";
$password = "admin123";
$full_name = "ผู้ดูแลระบบ";
$department = "ผู้ดูแลระบบ";
$role = "admin";

$hashed_password = password_hash($password, PASSWORD_DEFAULT);

$stmt = $pdo->prepare("
    INSERT INTO users
    (username, password, full_name, department, role)
    VALUES (?, ?, ?, ?, ?)
");

$stmt->execute([
    $username,
    $hashed_password,
    $full_name,
    $department,
    $role
]);

echo "สร้างบัญชีผู้ดูแลระบบสำเร็จ<br>";
echo "Username: admin<br>";
echo "Password: admin123<br>";
echo "<br>กรุณาลบไฟล์ create_admin.php หลังจากสร้างบัญชีเสร็จ";
?>