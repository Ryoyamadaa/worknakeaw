<?php

error_reporting(E_ALL);
ini_set('display_errors', 1);

require_once "config.php";

/* =========================
   ตรวจสอบการเข้าสู่ระบบ
========================= */

if (!isset($_SESSION["user_id"])) {
    header("Location: login.php");
    exit;
}

/* =========================
   เฉพาะ Admin
========================= */

if ($_SESSION["role"] !== "admin") {
    die("
        <h2 style='font-family:Arial;text-align:center;margin-top:60px;'>
            ไม่มีสิทธิ์เข้าถึงหน้านี้
        </h2>
        <p style='text-align:center;'>
            เฉพาะผู้ดูแลระบบเท่านั้น
        </p>
    ");
}

/* =========================
   รับข้อมูล
========================= */

if ($_SERVER["REQUEST_METHOD"] !== "POST") {
    header("Location: users.php");
    exit;
}

$user_id = (int)($_POST["user_id"] ?? 0);

$username = trim($_POST["username"] ?? "");
$full_name = trim($_POST["full_name"] ?? "");
$department = trim($_POST["department"] ?? "");
$role = $_POST["role"] ?? "user";

$new_password = $_POST["new_password"] ?? "";
$confirm_password = $_POST["confirm_password"] ?? "";


/* =========================
   ตรวจสอบข้อมูล
========================= */

if ($user_id <= 0) {
    header("Location: users.php?error=" . urlencode("ไม่พบรหัสผู้ใช้งาน"));
    exit;
}

if ($username === "" || $full_name === "") {
    header(
        "Location: edit_user.php?id=" .
        $user_id .
        "&error=" .
        urlencode("กรุณากรอกชื่อผู้ใช้งานและชื่อ-นามสกุล")
    );
    exit;
}


/* =========================
   ตรวจสอบ Role
========================= */

$allowed_roles = ["admin", "user"];

if (!in_array($role, $allowed_roles, true)) {
    header(
        "Location: edit_user.php?id=" .
        $user_id .
        "&error=" .
        urlencode("สิทธิ์การใช้งานไม่ถูกต้อง")
    );
    exit;
}


/* =========================
   ตรวจสอบ Username ซ้ำ
========================= */

$stmt = $pdo->prepare("
    SELECT id
    FROM users
    WHERE username = ?
    AND id <> ?
    LIMIT 1
");

$stmt->execute([
    $username,
    $user_id
]);

$duplicate = $stmt->fetch();

if ($duplicate) {

    header(
        "Location: edit_user.php?id=" .
        $user_id .
        "&error=" .
        urlencode("ชื่อผู้ใช้งานนี้มีอยู่ในระบบแล้ว")
    );

    exit;
}


/* =========================
   ตรวจสอบ Password
========================= */

if ($new_password !== "" || $confirm_password !== "") {

    if ($new_password === "" || $confirm_password === "") {

        header(
            "Location: edit_user.php?id=" .
            $user_id .
            "&error=" .
            urlencode("กรุณากรอกรหัสผ่านใหม่ทั้งสองช่อง")
        );

        exit;
    }

    if ($new_password !== $confirm_password) {

        header(
            "Location: edit_user.php?id=" .
            $user_id .
            "&error=" .
            urlencode("รหัสผ่านใหม่ไม่ตรงกัน")
        );

        exit;
    }

    if (strlen($new_password) < 6) {

        header(
            "Location: edit_user.php?id=" .
            $user_id .
            "&error=" .
            urlencode("รหัสผ่านใหม่ต้องมีอย่างน้อย 6 ตัวอักษร")
        );

        exit;
    }
}


/* =========================
   ป้องกัน Admin คนสุดท้าย
   ถูกเปลี่ยนเป็น User
========================= */

if ($role === "user") {

    $stmt = $pdo->query("
        SELECT COUNT(*) AS total_admin
        FROM users
        WHERE role = 'admin'
    ");

    $admin_count = (int)$stmt->fetch()["total_admin"];

    /* ตรวจสอบว่าผู้ใช้คนนี้เป็น Admin อยู่หรือไม่ */

    $stmt = $pdo->prepare("
        SELECT role
        FROM users
        WHERE id = ?
        LIMIT 1
    ");

    $stmt->execute([$user_id]);

    $current_user = $stmt->fetch();

    if (
        $current_user &&
        $current_user["role"] === "admin" &&
        $admin_count <= 1
    ) {

        header(
            "Location: edit_user.php?id=" .
            $user_id .
            "&error=" .
            urlencode("ไม่สามารถเปลี่ยนสิทธิ์ได้ เพราะระบบต้องมีผู้ดูแลระบบอย่างน้อย 1 คน")
        );

        exit;
    }
}


/* =========================
   บันทึกข้อมูล
========================= */

try {

    $pdo->beginTransaction();


    /* =========================
       ถ้ามีการเปลี่ยน Password
    ========================= */

    if ($new_password !== "") {

        $hashed_password = password_hash(
            $new_password,
            PASSWORD_DEFAULT
        );

        $stmt = $pdo->prepare("
            UPDATE users
            SET
                username = ?,
                password = ?,
                full_name = ?,
                department = ?,
                role = ?
            WHERE id = ?
        ");

        $stmt->execute([
            $username,
            $hashed_password,
            $full_name,
            $department,
            $role,
            $user_id
        ]);

    } else {

        /* =========================
           ไม่เปลี่ยน Password
        ========================= */

        $stmt = $pdo->prepare("
            UPDATE users
            SET
                username = ?,
                full_name = ?,
                department = ?,
                role = ?
            WHERE id = ?
        ");

        $stmt->execute([
            $username,
            $full_name,
            $department,
            $role,
            $user_id
        ]);
    }


    $pdo->commit();


    /* =========================
       ถ้าแก้ไขบัญชีตัวเอง
       อัปเดต Session ด้วย
    ========================= */

    if ((int)$_SESSION["user_id"] === $user_id) {

        $_SESSION["username"] = $username;
        $_SESSION["full_name"] = $full_name;
        $_SESSION["department"] = $department;
        $_SESSION["role"] = $role;
    }


    header(
        "Location: edit_user.php?id=" .
        $user_id .
        "&success=" .
        urlencode("บันทึกข้อมูลผู้ใช้งานเรียบร้อยแล้ว")
    );

    exit;


} catch (PDOException $e) {

    if ($pdo->inTransaction()) {
        $pdo->rollBack();
    }

    header(
        "Location: edit_user.php?id=" .
        $user_id .
        "&error=" .
        urlencode("ไม่สามารถบันทึกข้อมูลได้: " . $e->getMessage())
    );

    exit;
}

?>