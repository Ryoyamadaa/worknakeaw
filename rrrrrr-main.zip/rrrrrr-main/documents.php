<?php

error_reporting(E_ALL);
ini_set('display_errors', 1);

require_once "config.php";


/* =========================
   ตรวจสอบ Login
========================= */

if (!isset($_SESSION["user_id"])) {

    header("Location: login.php");
    exit;

}


/* =========================
   ค่าค้นหา
========================= */

$keyword = trim($_GET["keyword"] ?? "");
$status = trim($_GET["status"] ?? "");
$priority = trim($_GET["priority"] ?? "");


/* =========================
   สถานะทั้ง 6
========================= */

$statuses = [
    "ลงรับแล้ว",
    "กำลังดำเนินการ",
    "เสนอหัวหน้าสำนักปลัด",
    "เสนอผู้บริหาร",
    "ส่งให้ผู้ที่ได้รับมอบ",
    "เสร็จสมบูรณ์"
];


/* =========================
   ความเร่งด่วน
========================= */

$priorities = [
    "ปกติ",
    "ด่วน",
    "ด่วนมาก",
    "ด่วนที่สุด"
];


/* =========================
   SQL
========================= */

$sql = "
    SELECT
        d.*,
        u.full_name AS creator_name
    FROM documents d
    LEFT JOIN users u
        ON d.created_by = u.id
    WHERE 1=1
";

$params = [];


/* =========================
   ค้นหา
========================= */

if ($keyword !== "") {

    $sql .= "
        AND (
            d.document_no LIKE ?
            OR d.subject LIKE ?
            OR d.department LIKE ?
            OR d.responsible_person LIKE ?
        )
    ";

    $search = "%" . $keyword . "%";

    $params[] = $search;
    $params[] = $search;
    $params[] = $search;
    $params[] = $search;
}


/* =========================
   กรองสถานะ
========================= */

if ($status !== "") {

    $sql .= "
        AND d.status = ?
    ";

    $params[] = $status;
}


/* =========================
   กรองความเร่งด่วน
========================= */

if ($priority !== "") {

    $sql .= "
        AND d.priority = ?
    ";

    $params[] = $priority;
}


/* =========================
   เรียงข้อมูล
========================= */

$sql .= "
    ORDER BY d.id DESC
";


/* =========================
   ดึงข้อมูล
========================= */

try {

    $stmt = $pdo->prepare($sql);

    $stmt->execute($params);

    $documents = $stmt->fetchAll();

} catch (PDOException $e) {

    die("
        <div style='
            font-family:Arial,sans-serif;
            max-width:800px;
            margin:60px auto;
            padding:30px;
            background:white;
            border-radius:15px;
            box-shadow:0 5px 20px rgba(0,0,0,.08);
        '>

            <h2 style='color:#dc2626;'>
                ❌ เกิดข้อผิดพลาดในการโหลดข้อมูล
            </h2>

            <p style='color:#555;'>
                " .
                htmlspecialchars($e->getMessage())
                . "
            </p>

            <a
                href='dashboard.php'
                style='
                    display:inline-block;
                    margin-top:15px;
                    padding:10px 18px;
                    background:#1565c0;
                    color:white;
                    text-decoration:none;
                    border-radius:9px;
                '
            >
                ← กลับหน้าหลัก
            </a>

        </div>
    ");

}

?>

<!DOCTYPE html>
<html lang="th">

<head>

<meta charset="UTF-8">

<meta
    name="viewport"
    content="width=device-width, initial-scale=1.0"
>

<title>เอกสารทั้งหมด | ระบบติดตามเอกสาร</title>


<style>

/* =========================
   RESET
========================= */

* {
    box-sizing: border-box;
}


/* =========================
   BODY
========================= */

body {

    margin: 0;

    font-family:
        Tahoma,
        "Noto Sans Thai",
        sans-serif;

    background: #f4f7fb;

    color: #263238;

}


/* =========================
   SIDEBAR
========================= */

.sidebar {

    position: fixed;

    left: 0;
    top: 0;

    width: 250px;

    height: 100vh;

    background:
        linear-gradient(
            180deg,
            #0d47a1,
            #1565c0
        );

    color: white;

    padding: 25px 15px;

    overflow-y: auto;

}


.logo-area {

    text-align: center;

    padding-bottom: 25px;

    border-bottom:
        1px solid
        rgba(255,255,255,0.2);

}


.logo-icon {

    width: 65px;
    height: 65px;

    margin: auto;

    border-radius: 50%;

    background: white;

    color: #1565c0;

    display: flex;

    align-items: center;

    justify-content: center;

    font-size: 28px;

    margin-bottom: 12px;

}


.logo-area h2 {

    font-size: 19px;

    margin: 0;

}


.logo-area p {

    font-size: 12px;

    margin-top: 6px;

    opacity: .8;

}


/* =========================
   MENU
========================= */

.menu {

    margin-top: 25px;

}


.menu a {

    display: block;

    color: white;

    text-decoration: none;

    padding: 13px 15px;

    margin-bottom: 7px;

    border-radius: 10px;

    transition: .2s;

    font-size: 15px;

}


.menu a:hover,
.menu a.active {

    background:
        rgba(255,255,255,.18);

}


.menu .logout {

    margin-top: 25px;

    background:
        rgba(198,40,40,.8);

}


.menu .logout:hover {

    background:
        rgba(183,28,28,.95);

}


/* =========================
   MAIN
========================= */

.main {

    margin-left: 250px;

    min-height: 100vh;

}


/* =========================
   TOPBAR
========================= */

.topbar {

    height: 75px;

    background: white;

    display: flex;

    align-items: center;

    justify-content: space-between;

    padding: 0 30px;

    box-shadow:
        0 2px 12px
        rgba(0,0,0,.05);

}


.topbar h1 {

    margin: 0;

    color: #0759a5;

    font-size: 23px;

}


.user-box {

    display: flex;

    align-items: center;

    gap: 12px;

}


.user-icon {

    width: 42px;
    height: 42px;

    border-radius: 50%;

    background: #e5f2ff;

    display: flex;

    align-items: center;

    justify-content: center;

    font-size: 20px;

}


.user-name {

    font-weight: 700;

}


.user-dept {

    font-size: 12px;

    color: #64748b;

}


/* =========================
   CONTENT
========================= */

.content {

    padding: 30px;

}


/* =========================
   SEARCH CARD
========================= */

.card {

    background: white;

    border-radius: 16px;

    padding: 23px;

    margin-bottom: 20px;

    box-shadow:
        0 5px 20px
        rgba(30,64,175,.07);

    border:
        1px solid #e5edf7;

}


.title {

    font-size: 19px;

    font-weight: 700;

    color: #0759a5;

    margin-bottom: 18px;

}


.search-grid {

    display: grid;

    grid-template-columns:
        2fr 1fr 1fr auto;

    gap: 12px;

}


input,
select {

    width: 100%;

    padding: 12px 14px;

    border:
        1px solid #d8e2ef;

    border-radius: 10px;

    font-size: 14px;

    outline: none;

    background: white;

    color: #263238;

}


input:focus,
select:focus {

    border-color: #1683dc;

    box-shadow:
        0 0 0 3px
        rgba(22,131,220,.08);

}


/* =========================
   BUTTON
========================= */

.btn {

    border: none;

    border-radius: 10px;

    padding: 12px 18px;

    cursor: pointer;

    text-decoration: none;

    display: inline-block;

    font-weight: 600;

    font-size: 14px;

}


.btn-blue {

    background: #1565c0;

    color: white;

}


.btn-blue:hover {

    background: #0d47a1;

}


.btn-green {

    background: #16a34a;

    color: white;

}


.btn-green:hover {

    background: #15803d;

}


/* =========================
   DOCUMENT LIST
========================= */

.table-card {

    background: white;

    border-radius: 16px;

    padding: 25px;

    box-shadow:
        0 3px 15px
        rgba(0,0,0,.06);

}


.table-header {

    display: flex;

    justify-content: space-between;

    align-items: center;

    gap: 15px;

    margin-bottom: 20px;

}


.table-header h2 {

    margin: 0;

    color: #263238;

    font-size: 19px;

}


/* =========================
   TABLE
========================= */

.table-wrap {

    overflow-x: auto;

}


table {

    width: 100%;

    border-collapse: collapse;

    min-width: 1050px;

}


th {

    background: #e3f2fd;

    color: #0d47a1;

    padding: 13px 10px;

    text-align: left;

    font-size: 13px;

    white-space: nowrap;

}


td {

    padding: 13px 10px;

    border-bottom:
        1px solid #eeeeee;

    font-size: 13px;

    vertical-align: middle;

}


tr:hover td {

    background: #f8fbff;

}


.subject {

    font-weight: 600;

    color: #1e3a5f;

    max-width: 330px;

}


/* =========================
   BADGE
========================= */

.badge {

    display: inline-block;

    padding: 6px 10px;

    border-radius: 20px;

    font-size: 11px;

    font-weight: 700;

    white-space: nowrap;

}


/* สถานะ */

.status-1 {

    background: #e3f2fd;

    color: #1565c0;

}


.status-2 {

    background: #fff8e1;

    color: #f57c00;

}


.status-3 {

    background: #fff3e0;

    color: #ef6c00;

}


.status-4 {

    background: #f3e5f5;

    color: #8e24aa;

}


.status-5 {

    background: #e0f2f1;

    color: #00897b;

}


.status-6 {

    background: #e8f5e9;

    color: #2e7d32;

}


/* =========================
   PRIORITY
========================= */

.priority-normal {

    background: #f1f5f9;

    color: #475569;

}


.priority-urgent {

    background: #fff7ed;

    color: #c2410c;

}


.priority-very {

    background: #fef2f2;

    color: #dc2626;

}


/* =========================
   ACTIONS
========================= */

.actions {

    display: flex;

    gap: 5px;

    flex-wrap: wrap;

}


.actions a {

    padding:
        7px 10px;

    border-radius: 7px;

    text-decoration: none;

    font-size: 11px;

    font-weight: 600;

}


.view {

    background: #e0f2fe;

    color: #0369a1;

}


.view:hover {

    background: #bae6fd;

}


.edit {

    background: #fef3c7;

    color: #92400e;

}


.edit:hover {

    background: #fde68a;

}


.delete {

    background: #fee2e2;

    color: #b91c1c;

}


.delete:hover {

    background: #fecaca;

}


/* =========================
   EMPTY
========================= */

.empty {

    text-align: center;

    padding: 50px 20px;

    color: #90a4ae;

    font-size: 15px;

}


.empty-icon {

    font-size: 42px;

    margin-bottom: 10px;

}


/* =========================
   RESULT COUNT
========================= */

.result-count {

    color: #64748b;

    font-size: 13px;

}


/* =========================
   RESPONSIVE
========================= */

@media (max-width: 1000px) {

    .search-grid {

        grid-template-columns:
            repeat(2, 1fr);

    }

}


@media (max-width: 700px) {

    .sidebar {

        position: relative;

        width: 100%;

        height: auto;

    }


    .main {

        margin-left: 0;

    }


    .search-grid {

        grid-template-columns: 1fr;

    }


    .topbar {

        height: auto;

        padding: 18px;

        gap: 10px;

    }


    .content {

        padding: 18px;

    }


    .table-card {

        padding: 18px;

    }


    .table-header {

        align-items: flex-start;

        flex-direction: column;

    }

}

</style>

</head>


<body>


<!-- =========================
     SIDEBAR
========================= -->

<div class="sidebar">

    <div class="logo-area">

        <img src="oo.image/S__29155335.jpg"
     alt="โลโก้เทศบาล"
     style="
        width:95px;
        height:95px;
        border-radius:50%;
        object-fit:cover;
        display:block;
        margin:0 auto 15px;
        border:4px solid #fff;
        box-shadow:0 4px 15px rgba(0,0,0,.15);
     ">


        <h2>
            ระบบติดตามเอกสาร
        </h2>

        <p>
            Document Tracking System
        </p>

    </div>


    <div class="menu">

        <a href="dashboard.php">

            🏠 หน้าหลัก

        </a>


        <a href="search.php">

            🔎 ค้นหางาน

        </a>


        <a href="add_document.php">

            ➕ เพิ่มเอกสาร

        </a>


        <a
            href="documents.php"
            class="active"
        >

            📋 เอกสารทั้งหมด

        </a>


        <?php if ($_SESSION["role"] === "admin"): ?>

            <a href="users.php">

                👥 จัดการผู้ใช้งาน

            </a>

        <?php endif; ?>


        <a
            href="logout.php"
            class="logout"
        >

            🚪 ออกจากระบบ

        </a>

    </div>

</div>



<!-- =========================
     MAIN
========================= -->

<div class="main">


    <!-- TOPBAR -->

    <div class="topbar">

        <h1>
            📋 เอกสารทั้งหมด
        </h1>


        <div class="user-box">

            <div class="user-icon">
                👤
            </div>

            <div>

                <div class="user-name">

                    <?= htmlspecialchars(
                        $_SESSION["full_name"]
                    ) ?>

                </div>

                <div class="user-dept">

                    <?= htmlspecialchars(
                        $_SESSION["department"]
                    ) ?>

                </div>

            </div>

        </div>

    </div>



    <!-- CONTENT -->

    <div class="content">


        <!-- =========================
             SEARCH
        ========================= -->

        <div class="card">

            <div class="title">

                🔎 ค้นหารายการเอกสาร

            </div>


            <form method="GET">

                <div class="search-grid">


                    <input
                        type="text"
                        name="keyword"
                        placeholder="เลขที่หนังสือ / เรื่อง / หน่วยงาน / ผู้รับผิดชอบ"
                        value="<?= htmlspecialchars(
                            $keyword
                        ) ?>"
                    >


                    <select name="status">

                        <option value="">

                            ทุกสถานะ

                        </option>


                        <?php foreach (
                            $statuses as $item
                        ): ?>

                            <option
                                value="<?= htmlspecialchars($item) ?>"
                                <?= $status === $item
                                    ? "selected"
                                    : ""
                                ?>
                            >

                                <?= htmlspecialchars(
                                    $item
                                ) ?>

                            </option>

                        <?php endforeach; ?>

                    </select>


                    <select name="priority">

                        <option value="">

                            ทุกความเร่งด่วน

                        </option>


                        <?php foreach (
                            $priorities as $item
                        ): ?>

                            <option
                                value="<?= htmlspecialchars($item) ?>"
                                <?= $priority === $item
                                    ? "selected"
                                    : ""
                                ?>
                            >

                                <?= htmlspecialchars(
                                    $item
                                ) ?>

                            </option>

                        <?php endforeach; ?>

                    </select>


                    <button
                        type="submit"
                        class="btn btn-blue"
                    >

                        🔎 ค้นหา

                    </button>

                </div>

            </form>

        </div>



        <!-- =========================
             TABLE
        ========================= -->

        <div class="table-card">


            <div class="table-header">

                <div>

                    <h2>
                        📋 รายการเอกสาร
                    </h2>

                    <div class="result-count">

                        พบ <?= count($documents) ?> รายการ

                    </div>

                </div>


                <a
                    href="add_document.php"
                    class="btn btn-green"
                >

                    ➕ เพิ่มเอกสาร

                </a>

            </div>



            <div class="table-wrap">


                <?php if (
                    count($documents) > 0
                ): ?>


                    <table>

                        <thead>

                            <tr>

                                <th>
                                    เลขที่หนังสือ
                                </th>

                                <th>
                                    เรื่อง
                                </th>

                                <th>
                                    หน่วยงาน
                                </th>

                                <th>
                                    ผู้รับผิดชอบ
                                </th>

                                <th>
                                    วันที่รับ
                                </th>

                                <th>
                                    ความเร่งด่วน
                                </th>

                                <th>
                                    สถานะ
                                </th>

                                <th>
                                    จัดการ
                                </th>

                            </tr>

                        </thead>


                        <tbody>


                        <?php foreach (
                            $documents as $item
                        ): ?>


                            <tr>


                                <td>

                                    <?= htmlspecialchars(
                                        $item["document_no"]
                                    ) ?>

                                </td>


                                <td class="subject">

                                    <?= htmlspecialchars(
                                        $item["subject"]
                                    ) ?>

                                </td>


                                <td>

                                    <?= htmlspecialchars(
                                        $item["department"]
                                        ?: "-"
                                    ) ?>

                                </td>


                                <td>

                                    <?= htmlspecialchars(
                                        $item["responsible_person"]
                                        ?: "-"
                                    ) ?>

                                </td>


                                <td>

                                    <?php if (
                                        !empty(
                                            $item["received_date"]
                                        )
                                    ): ?>

                                        <?= date(
                                            "d/m/Y H:i",
                                            strtotime(
                                                $item["received_date"]
                                            )
                                        ) ?>

                                    <?php else: ?>

                                        -

                                    <?php endif; ?>

                                </td>


                                <!-- ความเร่งด่วน -->

                                <td>

                                    <?php

                                    $priority_class =
                                        "priority-normal";


                                    if (
                                        $item["priority"]
                                        === "ด่วน"
                                    ) {

                                        $priority_class =
                                            "priority-urgent";

                                    }


                                    if (
                                        $item["priority"]
                                        === "ด่วนมาก"
                                        ||
                                        $item["priority"]
                                        === "ด่วนที่สุด"
                                    ) {

                                        $priority_class =
                                            "priority-very";

                                    }

                                    ?>


                                    <span
                                        class="badge <?= $priority_class ?>"
                                    >

                                        <?= htmlspecialchars(
                                            $item["priority"]
                                        ) ?>

                                    </span>

                                </td>


                                <!-- สถานะ -->

                                <td>

                                    <?php

                                    $status_class =
                                        "status-1";


                                    if (
                                        $item["status"]
                                        === "กำลังดำเนินการ"
                                    ) {

                                        $status_class =
                                            "status-2";

                                    }
                                    elseif (
                                        $item["status"]
                                        === "เสนอหัวหน้าสำนักปลัด"
                                    ) {

                                        $status_class =
                                            "status-3";

                                    }
                                    elseif (
                                        $item["status"]
                                        === "เสนอผู้บริหาร"
                                    ) {

                                        $status_class =
                                            "status-4";

                                    }
                                    elseif (
                                        $item["status"]
                                        === "ส่งให้ผู้ที่ได้รับมอบ"
                                    ) {

                                        $status_class =
                                            "status-5";

                                    }
                                    elseif (
                                        $item["status"]
                                        === "เสร็จสมบูรณ์"
                                    ) {

                                        $status_class =
                                            "status-6";

                                    }

                                    ?>


                                    <span
                                        class="badge <?= $status_class ?>"
                                    >

                                        <?= htmlspecialchars(
                                            $item["status"]
                                        ) ?>

                                    </span>

                                </td>


                                <!-- จัดการ -->

                                <td>

                                    <div class="actions">


                                        <a
                                            href="document.php?id=<?= (int)$item["id"] ?>"
                                            class="view"
                                        >

                                            👁 ดู

                                        </a>


                                        <a
                                            href="edit_document.php?id=<?= (int)$item["id"] ?>"
                                            class="edit"
                                        >

                                            ✏️ แก้ไข

                                        </a>


                                        <?php if (
                                            $_SESSION["role"]
                                            === "admin"
                                        ): ?>


                                            <a
                                                href="delete_document.php?id=<?= (int)$item["id"] ?>"
                                                class="delete"
                                                onclick="return confirm('ยืนยันการลบเอกสารนี้หรือไม่?');"
                                            >

                                                🗑 ลบ

                                            </a>


                                        <?php endif; ?>


                                    </div>

                                </td>


                            </tr>


                        <?php endforeach; ?>


                        </tbody>

                    </table>


                <?php else: ?>


                    <div class="empty">

                        <div class="empty-icon">
                            📭
                        </div>

                        ไม่พบข้อมูลเอกสาร

                        <br><br>

                        <a
                            href="add_document.php"
                            class="btn btn-green"
                        >

                            ➕ เพิ่มเอกสาร

                        </a>

                    </div>


                <?php endif; ?>


            </div>

        </div>


    </div>

</div>


</body>

</html>