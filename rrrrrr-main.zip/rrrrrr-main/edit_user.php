<?php

error_reporting(E_ALL);
ini_set('display_errors', 1);

require_once "config.php";

/* =========================
   ตรวจสอบ Login
========================= */

if (!isset($_SESSION["user_id"])) {
    header("Location: login.php");
    exit;
}

/* =========================
   เฉพาะ Admin
========================= */

if ($_SESSION["role"] !== "admin") {
    die("
        <div style='
            font-family:Arial,sans-serif;
            text-align:center;
            padding:80px 20px;
        '>
            <h2>ไม่มีสิทธิ์เข้าถึงหน้านี้</h2>
            <p>เฉพาะผู้ดูแลระบบเท่านั้น</p>
            <a href='dashboard.php'>กลับหน้าหลัก</a>
        </div>
    ");
}

/* =========================
   รับ ID
========================= */

$user_id = isset($_GET["id"])
    ? (int)$_GET["id"]
    : 0;

if ($user_id <= 0) {
    header("Location: users.php");
    exit;
}

/* =========================
   ดึงข้อมูลผู้ใช้
========================= */

$stmt = $pdo->prepare("
    SELECT
        id,
        username,
        full_name,
        department,
        role
    FROM users
    WHERE id = ?
    LIMIT 1
");

$stmt->execute([$user_id]);

$user = $stmt->fetch();

if (!$user) {
    die("
        <div style='
            font-family:Arial,sans-serif;
            text-align:center;
            padding:80px 20px;
        '>
            <h2>ไม่พบข้อมูลผู้ใช้งาน</h2>
            <a href='users.php'>กลับหน้าจัดการผู้ใช้งาน</a>
        </div>
    ");
}

/* =========================
   แจ้งเตือน
========================= */

$error = $_GET["error"] ?? "";
$success = $_GET["success"] ?? "";

?>

<!DOCTYPE html>
<html lang="th">

<head>

<meta charset="UTF-8">

<meta name="viewport"
      content="width=device-width, initial-scale=1.0">

<title>แก้ไขผู้ใช้งาน | ระบบติดตามเอกสาร</title>

<style>

/* ==================================================
   RESET
================================================== */

* {
    box-sizing: border-box;
}

html {
    scroll-behavior: smooth;
}

body {
    margin: 0;
    font-family:
        "Segoe UI",
        Tahoma,
        Arial,
        sans-serif;

    background:
        linear-gradient(
            135deg,
            #edf6ff 0%,
            #f7fbff 45%,
            #eaf4ff 100%
        );

    color: #1e293b;
}


/* ==================================================
   SIDEBAR
================================================== */

.sidebar {

    position: fixed;

    left: 0;
    top: 0;

    width: 255px;
    height: 100vh;

    background:
        linear-gradient(
            180deg,
            #064da5 0%,
            #086bc4 45%,
            #1594e8 100%
        );

    color: white;

    padding: 25px 17px;

    box-shadow:
        6px 0 25px rgba(0, 65, 130, 0.12);

    z-index: 1000;
}


/* ==================================================
   LOGO
================================================== */

.logo {

    text-align: center;

    padding-bottom: 24px;

    border-bottom:
        1px solid
        rgba(255,255,255,0.15);

}

.logo-icon {

    width: 65px;
    height: 65px;

    margin: 0 auto 13px;

    display: flex;

    align-items: center;
    justify-content: center;

    border-radius: 20px;

    background:
        rgba(255,255,255,0.16);

    border:
        1px solid
        rgba(255,255,255,0.20);

    box-shadow:
        0 8px 20px
        rgba(0,0,0,0.10);

    font-size: 30px;
}

.logo h2 {

    margin: 0;

    font-size: 19px;

    font-weight: 700;

    letter-spacing: .2px;
}

.logo p {

    margin: 6px 0 0;

    font-size: 11px;

    opacity: .78;
}


/* ==================================================
   MENU
================================================== */

.menu {

    margin-top: 25px;
}

.menu-title {

    padding:
        0 12px 10px;

    font-size: 11px;

    color:
        rgba(255,255,255,.60);

    text-transform: uppercase;

    letter-spacing: 1px;
}

.menu a {

    position: relative;

    display: flex;

    align-items: center;

    gap: 13px;

    padding:
        13px 15px;

    margin-bottom: 7px;

    border-radius: 13px;

    color: white;

    text-decoration: none;

    font-size: 14px;

    transition:
        all .25s ease;
}

.menu a:hover {

    background:
        rgba(255,255,255,.13);

    transform:
        translateX(3px);
}

.menu a.active {

    background:
        rgba(255,255,255,.19);

    box-shadow:
        inset 3px 0 0 white,
        0 5px 15px
        rgba(0,0,0,.08);

    font-weight: 600;
}

.menu-icon {

    width: 28px;
    height: 28px;

    display: flex;

    align-items: center;
    justify-content: center;

    border-radius: 8px;

    background:
        rgba(255,255,255,.12);

    font-size: 15px;
}


/* ==================================================
   MAIN
================================================== */

.main {

    margin-left: 255px;

    min-height: 100vh;
}


/* ==================================================
   TOPBAR
================================================== */

.topbar {

    height: 78px;

    display: flex;

    align-items: center;

    justify-content: space-between;

    padding:
        0 35px;

    background:
        rgba(255,255,255,.92);

    backdrop-filter:
        blur(10px);

    border-bottom:
        1px solid #e2e8f0;

    position: sticky;

    top: 0;

    z-index: 100;
}

.topbar-left h1 {

    margin: 0;

    font-size: 21px;

    color: #0b438b;

    font-weight: 700;
}

.topbar-left p {

    margin:
        4px 0 0;

    font-size: 12px;

    color: #64748b;
}


/* ==================================================
   USER
================================================== */

.user-box {

    display: flex;

    align-items: center;

    gap: 12px;
}

.user-info {

    text-align: right;
}

.user-info strong {

    display: block;

    font-size: 13px;

    color: #1e293b;
}

.user-info span {

    display: block;

    margin-top: 2px;

    font-size: 11px;

    color: #64748b;
}

.user-avatar {

    width: 43px;
    height: 43px;

    display: flex;

    align-items: center;
    justify-content: center;

    border-radius: 50%;

    background:
        linear-gradient(
            135deg,
            #dbeafe,
            #bfdbfe
        );

    border:
        2px solid white;

    box-shadow:
        0 4px 12px
        rgba(37,99,235,.15);

    font-size: 19px;
}


/* ==================================================
   CONTENT
================================================== */

.content {

    padding: 35px;

    max-width: 1150px;
}


/* ==================================================
   PAGE HEADER
================================================== */

.page-header {

    display: flex;

    justify-content: space-between;

    align-items: center;

    margin-bottom: 25px;
}

.page-title {

    display: flex;

    align-items: center;

    gap: 15px;
}

.page-title-icon {

    width: 55px;
    height: 55px;

    display: flex;

    align-items: center;
    justify-content: center;

    border-radius: 16px;

    background:
        linear-gradient(
            135deg,
            #dbeafe,
            #eff6ff
        );

    border:
        1px solid #bfdbfe;

    font-size: 25px;
}

.page-header h2 {

    margin: 0;

    font-size: 25px;

    color: #0b438b;
}

.page-header p {

    margin:
        5px 0 0;

    font-size: 13px;

    color: #64748b;
}


/* ==================================================
   BACK BUTTON
================================================== */

.back-btn {

    display: inline-flex;

    align-items: center;

    gap: 7px;

    padding:
        11px 18px;

    border-radius: 11px;

    background: white;

    color: #0756b8;

    border:
        1px solid #d5e1ef;

    text-decoration: none;

    font-size: 13px;

    box-shadow:
        0 3px 10px
        rgba(15,23,42,.04);

    transition: .2s;
}

.back-btn:hover {

    border-color:
        #8dbbea;

    background:
        #f8fbff;

    transform:
        translateY(-1px);
}


/* ==================================================
   ALERT
================================================== */

.alert {

    padding:
        14px 18px;

    border-radius:
        12px;

    margin-bottom:
        20px;

    font-size:
        13px;

    display: flex;

    align-items: center;

    gap: 10px;
}

.alert-error {

    background:
        #fff1f2;

    color:
        #be123c;

    border:
        1px solid #fecdd3;
}

.alert-success {

    background:
        #f0fdf4;

    color:
        #15803d;

    border:
        1px solid #bbf7d0;
}


/* ==================================================
   CARD
================================================== */

.card {

    background:
        rgba(255,255,255,.97);

    border:
        1px solid #e2e8f0;

    border-radius:
        20px;

    box-shadow:
        0 12px 35px
        rgba(15,23,42,.07);

    overflow: hidden;
}

.card-header {

    padding:
        22px 28px;

    background:
        linear-gradient(
            135deg,
            #f8fbff,
            #eef7ff
        );

    border-bottom:
        1px solid #e1edf9;

    display: flex;

    align-items: center;

    gap: 13px;
}

.card-header-icon {

    width: 42px;
    height: 42px;

    border-radius: 12px;

    display: flex;

    align-items: center;
    justify-content: center;

    background:
        #dbeafe;

    font-size: 19px;
}

.card-header h3 {

    margin: 0;

    color:
        #0f3f82;

    font-size:
        17px;
}

.card-header p {

    margin:
        3px 0 0;

    color:
        #64748b;

    font-size:
        12px;
}

.card-body {

    padding:
        30px;
}


/* ==================================================
   FORM
================================================== */

.form-grid {

    display:
        grid;

    grid-template-columns:
        repeat(2, 1fr);

    gap:
        22px;
}

.form-group {

    display:
        flex;

    flex-direction:
        column;
}

.form-group label {

    margin-bottom:
        8px;

    color:
        #334155;

    font-size:
        13px;

    font-weight:
        600;
}

.required {

    color:
        #dc2626;
}

.form-control {

    width:
        100%;

    padding:
        12px 14px;

    border:
        1px solid #cbd5e1;

    border-radius:
        11px;

    background:
        white;

    color:
        #1e293b;

    font-family:
        inherit;

    font-size:
        14px;

    outline:
        none;

    transition:
        all .2s ease;
}

.form-control:hover {

    border-color:
        #94a3b8;
}

.form-control:focus {

    border-color:
        #1683df;

    box-shadow:
        0 0 0 4px
        rgba(22,131,223,.10);
}

select.form-control {

    cursor:
        pointer;
}

.help {

    margin-top:
        6px;

    color:
        #64748b;

    font-size:
        11px;
}


/* ==================================================
   PASSWORD BOX
================================================== */

.password-box {

    margin-top:
        28px;

    border:
        1px solid #d8e9fb;

    border-radius:
        16px;

    overflow:
        hidden;

    background:
        #f8fbff;
}

.password-header {

    padding:
        18px 22px;

    background:
        linear-gradient(
            135deg,
            #edf6ff,
            #f8fbff
        );

    border-bottom:
        1px solid #dbeafe;

    display:
        flex;

    align-items:
        center;

    gap:
        12px;
}

.password-icon {

    width:
        40px;

    height:
        40px;

    border-radius:
        11px;

    background:
        #dbeafe;

    display:
        flex;

    align-items:
        center;

    justify-content:
        center;

    font-size:
        18px;
}

.password-header h3 {

    margin:
        0;

    color:
        #0f3f82;

    font-size:
        16px;
}

.password-header p {

    margin:
        3px 0 0;

    color:
        #64748b;

    font-size:
        11px;
}

.password-body {

    padding:
        22px;
}


/* ==================================================
   BUTTON AREA
================================================== */

.form-actions {

    display:
        flex;

    justify-content:
        flex-end;

    gap:
        12px;

    margin-top:
        30px;

    padding-top:
        25px;

    border-top:
        1px solid #e2e8f0;
}

.btn {

    display:
        inline-flex;

    align-items:
        center;

    justify-content:
        center;

    gap:
        8px;

    min-width:
        145px;

    padding:
        12px 20px;

    border:
        none;

    border-radius:
        11px;

    font-family:
        inherit;

    font-size:
        13px;

    font-weight:
        600;

    text-decoration:
        none;

    cursor:
        pointer;

    transition:
        all .22s ease;
}

.btn-cancel {

    background:
        #f1f5f9;

    color:
        #475569;

    border:
        1px solid #e2e8f0;
}

.btn-cancel:hover {

    background:
        #e2e8f0;

    transform:
        translateY(-1px);
}

.btn-save {

    color:
        white;

    background:
        linear-gradient(
            135deg,
            #0756b8,
            #168de2
        );

    box-shadow:
        0 7px 18px
        rgba(7,86,184,.22);
}

.btn-save:hover {

    transform:
        translateY(-2px);

    box-shadow:
        0 10px 22px
        rgba(7,86,184,.28);
}

.btn-save:active {

    transform:
        translateY(0);
}


/* ==================================================
   USER INFORMATION BADGE
================================================== */

.user-status {

    margin-top:
        24px;

    padding:
        14px 17px;

    border-radius:
        12px;

    background:
        #f8fafc;

    border:
        1px solid #e2e8f0;

    display:
        flex;

    align-items:
        center;

    justify-content:
        space-between;

    font-size:
        12px;

    color:
        #64748b;
}

.role-badge {

    display:
        inline-flex;

    align-items:
        center;

    gap:
        6px;

    padding:
        6px 12px;

    border-radius:
        20px;

    font-size:
        11px;

    font-weight:
        600;
}

.role-admin {

    background:
        #dbeafe;

    color:
        #1d4ed8;
}

.role-user {

    background:
        #f1f5f9;

    color:
        #475569;
}


/* ==================================================
   RESPONSIVE
================================================== */

@media (max-width: 900px) {

    .sidebar {

        width:
            220px;
    }

    .main {

        margin-left:
            220px;
    }

    .topbar {

        padding:
            0 22px;
    }

    .content {

        padding:
            25px;
    }

    .form-grid {

        grid-template-columns:
            1fr;
    }
}


@media (max-width: 700px) {

    .sidebar {

        position:
            relative;

        width:
            100%;

        height:
            auto;

        padding:
            18px;
    }

    .logo {

        padding-bottom:
            18px;
    }

    .menu {

        display:
            grid;

        grid-template-columns:
            1fr 1fr;

        gap:
            5px;

        margin-top:
            18px;
    }

    .menu-title {

        display:
            none;
    }

    .menu a {

        margin-bottom:
            0;

        font-size:
            12px;

        padding:
            10px;
    }

    .main {

        margin-left:
            0;
    }

    .topbar {

        height:
            auto;

        padding:
            15px;

        gap:
            10px;
    }

    .topbar-left h1 {

        font-size:
            17px;
    }

    .user-info {

        display:
            none;
    }

    .content {

        padding:
            15px;
    }

    .page-header {

        align-items:
            flex-start;

        flex-direction:
            column;

        gap:
            15px;
    }

    .page-title {

        align-items:
            flex-start;
    }

    .page-header h2 {

        font-size:
            21px;
    }

    .back-btn {

        width:
            100%;

        justify-content:
            center;
    }

    .card-body {

        padding:
            20px;
    }

    .form-actions {

        flex-direction:
            column;
    }

    .btn {

        width:
            100%;
    }

    .user-status {

        align-items:
            flex-start;

        flex-direction:
            column;

        gap:
            10px;
    }
}

</style>

</head>


<body>


<!-- ==================================================
     SIDEBAR
================================================== -->

<aside class="sidebar">

    <div class="logo">

       <img src="oo.image/S__29155335.jpg"
     alt="โลโก้เทศบาล"
     style="
        width:95px;
        height:95px;
        border-radius:50%;
        object-fit:cover;
        display:block;
        margin:0 auto 15px;
        border:4px solid #fff;
        box-shadow:0 4px 15px rgba(0,0,0,.15);
     ">


        <h2>
            ระบบติดตามเอกสาร
        </h2>

        <p>
            Document Tracking System
        </p>

    </div>


    <nav class="menu">

        <div class="menu-title">
            เมนูหลัก
        </div>


        <a href="dashboard.php">

            <span class="menu-icon">
                🏠
            </span>

            หน้าหลัก

        </a>


        <a href="search.php">

            <span class="menu-icon">
                🔎
            </span>

            ค้นหางาน

        </a>


        <a href="add_document.php">

            <span class="menu-icon">
                ➕
            </span>

            เพิ่มเอกสาร

        </a>


        <a href="documents.php">

            <span class="menu-icon">
                📋
            </span>

            รายการเอกสาร

        </a>


        <a href="users.php" class="active">

            <span class="menu-icon">
                👥
            </span>

            จัดการผู้ใช้งาน

        </a>


        <a href="logout.php">

            <span class="menu-icon">
                🚪
            </span>

            ออกจากระบบ

        </a>

    </nav>

</aside>


<!-- ==================================================
     MAIN
================================================== -->

<main class="main">


<!-- ==================================================
     TOPBAR
================================================== -->

<header class="topbar">

    <div class="topbar-left">

        <h1>
            แก้ไขข้อมูลผู้ใช้งาน
        </h1>

        <p>
            ระบบติดตามเอกสารเทศบาล
        </p>

    </div>


    <div class="user-box">

        <div class="user-info">

            <strong>
                <?= htmlspecialchars(
                    $_SESSION["full_name"] ?? ""
                ) ?>
            </strong>

            <span>
                <?= htmlspecialchars(
                    $_SESSION["department"] ?? ""
                ) ?>
            </span>

        </div>


        <div class="user-avatar">
            👤
        </div>

    </div>

</header>


<!-- ==================================================
     CONTENT
================================================== -->

<section class="content">


<!-- PAGE HEADER -->

<div class="page-header">

    <div class="page-title">

        <div class="page-title-icon">
            👤
        </div>

        <div>

            <h2>
                แก้ไขผู้ใช้งาน
            </h2>

            <p>
                ปรับปรุงข้อมูลและสิทธิ์การใช้งานของสมาชิกในระบบ
            </p>

        </div>

    </div>


    <a
        href="users.php"
        class="back-btn"
    >
        ← กลับหน้าผู้ใช้งาน
    </a>

</div>


<!-- ALERT -->

<?php if ($error !== ""): ?>

    <div class="alert alert-error">

        ⚠️

        <span>
            <?= htmlspecialchars($error) ?>
        </span>

    </div>

<?php endif; ?>


<?php if ($success !== ""): ?>

    <div class="alert alert-success">

        ✅

        <span>
            <?= htmlspecialchars($success) ?>
        </span>

    </div>

<?php endif; ?>


<!-- ==================================================
     MAIN CARD
================================================== -->

<div class="card">


    <!-- CARD HEADER -->

    <div class="card-header">

        <div class="card-header-icon">
            👤
        </div>

        <div>

            <h3>
                ข้อมูลผู้ใช้งาน
            </h3>

            <p>
                แก้ไขข้อมูลพื้นฐานของผู้ใช้งาน
            </p>

        </div>

    </div>


    <!-- CARD BODY -->

    <div class="card-body">


        <form
            action="update_user.php"
            method="POST"
        >


            <!-- USER ID -->

            <input
                type="hidden"
                name="user_id"
                value="<?= (int)$user["id"] ?>"
            >


            <!-- FORM -->

            <div class="form-grid">


                <!-- USERNAME -->

                <div class="form-group">

                    <label>

                        ชื่อผู้ใช้งาน

                        <span class="required">
                            *
                        </span>

                    </label>

                    <input
                        type="text"
                        name="username"
                        class="form-control"
                        value="<?= htmlspecialchars(
                            $user["username"]
                        ) ?>"
                        required
                        autocomplete="username"
                    >

                    <div class="help">
                        ใช้สำหรับเข้าสู่ระบบ
                    </div>

                </div>


                <!-- FULL NAME -->

                <div class="form-group">

                    <label>

                        ชื่อ-นามสกุล

                        <span class="required">
                            *
                        </span>

                    </label>

                    <input
                        type="text"
                        name="full_name"
                        class="form-control"
                        value="<?= htmlspecialchars(
                            $user["full_name"]
                        ) ?>"
                        required
                    >

                    <div class="help">
                        ชื่อที่จะแสดงในระบบ
                    </div>

                </div>


                <!-- DEPARTMENT -->

                <div class="form-group">

                    <label>
                        สำนัก / กอง / หน่วยงาน
                    </label>

                    <input
                        type="text"
                        name="department"
                        class="form-control"
                        value="<?= htmlspecialchars(
                            $user["department"]
                        ) ?>"
                        placeholder="เช่น สำนักปลัดเทศบาล"
                    >

                    <div class="help">
                        ระบุหน่วยงานที่ผู้ใช้งานสังกัด
                    </div>

                </div>


                <!-- ROLE -->

                <div class="form-group">

                    <label>

                        สิทธิ์การใช้งาน

                        <span class="required">
                            *
                        </span>

                    </label>

                    <select
                        name="role"
                        class="form-control"
                        required
                    >

                        <option
                            value="user"
                            <?= $user["role"] === "user"
                                ? "selected"
                                : "" ?>
                        >
                            ผู้ใช้งานทั่วไป
                        </option>

                        <option
                            value="admin"
                            <?= $user["role"] === "admin"
                                ? "selected"
                                : "" ?>
                        >
                            ผู้ดูแลระบบ
                        </option>

                    </select>

                    <div class="help">
                        ผู้ดูแลระบบสามารถจัดการผู้ใช้งานได้
                    </div>

                </div>


            </div>


            <!-- CURRENT ROLE -->

            <div class="user-status">

                <span>
                    สิทธิ์ปัจจุบันของผู้ใช้งาน
                </span>


                <?php if ($user["role"] === "admin"): ?>

                    <span class="role-badge role-admin">
                        🔐 ผู้ดูแลระบบ
                    </span>

                <?php else: ?>

                    <span class="role-badge role-user">
                        👤 ผู้ใช้งานทั่วไป
                    </span>

                <?php endif; ?>

            </div>


            <!-- ==================================================
                 PASSWORD
            ================================================== -->

            <div class="password-box">


                <div class="password-header">

                    <div class="password-icon">
                        🔐
                    </div>

                    <div>

                        <h3>
                            เปลี่ยนรหัสผ่าน
                        </h3>

                        <p>
                            หากไม่ต้องการเปลี่ยนรหัสผ่าน ให้เว้นว่างไว้
                        </p>

                    </div>

                </div>


                <div class="password-body">


                    <div class="form-grid">


                        <!-- NEW PASSWORD -->

                        <div class="form-group">

                            <label>
                                รหัสผ่านใหม่
                            </label>

                            <input
                                type="password"
                                name="new_password"
                                class="form-control"
                                placeholder="กรอกรหัสผ่านใหม่"
                                minlength="6"
                                autocomplete="new-password"
                            >

                            <div class="help">
                                ต้องมีอย่างน้อย 6 ตัวอักษร
                            </div>

                        </div>


                        <!-- CONFIRM PASSWORD -->

                        <div class="form-group">

                            <label>
                                ยืนยันรหัสผ่านใหม่
                            </label>

                            <input
                                type="password"
                                name="confirm_password"
                                class="form-control"
                                placeholder="กรอกรหัสผ่านใหม่อีกครั้ง"
                                minlength="6"
                                autocomplete="new-password"
                            >

                            <div class="help">
                                กรุณากรอกให้ตรงกับช่องด้านบน
                            </div>

                        </div>


                    </div>

                </div>

            </div>


            <!-- ==================================================
                 BUTTONS
            ================================================== -->

            <div class="form-actions">


                <a
                    href="users.php"
                    class="btn btn-cancel"
                >

                    ↩

                    ยกเลิก

                </a>


                <button
                    type="submit"
                    class="btn btn-save"
                >

                    💾

                    บันทึกการแก้ไข

                </button>


            </div>


        </form>


    </div>

</div>


</section>


</main>


</body>

</html>