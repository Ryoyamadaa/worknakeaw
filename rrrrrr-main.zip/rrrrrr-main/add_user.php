<?php

require_once "config.php";

if (!isset($_SESSION["user_id"])) {
    header("Location: login.php");
    exit;
}

if ($_SESSION["role"] !== "admin") {
    die("ไม่มีสิทธิ์เข้าถึงหน้านี้");
}

$error = "";
$success = "";

if ($_SERVER["REQUEST_METHOD"] === "POST") {

    $username = trim($_POST["username"] ?? "");
    $password = $_POST["password"] ?? "";
    $full_name = trim($_POST["full_name"] ?? "");
    $department = trim($_POST["department"] ?? "");
    $role = $_POST["role"] ?? "user";

    if ($username === "" || $password === "" || $full_name === "") {

        $error = "กรุณากรอกข้อมูลให้ครบ";

    } elseif (!in_array($role, ["admin", "user"], true)) {

        $error = "สิทธิ์ผู้ใช้งานไม่ถูกต้อง";

    } else {

        try {

            // ตรวจสอบ Username ซ้ำ
            $check = $pdo->prepare("
                SELECT id
                FROM users
                WHERE username = ?
                LIMIT 1
            ");

            $check->execute([$username]);

            if ($check->fetch()) {

                $error = "Username นี้มีอยู่ในระบบแล้ว";

            } else {

                // เข้ารหัส Password
                $hashed_password = password_hash(
                    $password,
                    PASSWORD_DEFAULT
                );

                // เพิ่ม User
                $stmt = $pdo->prepare("
                    INSERT INTO users
                    (
                        username,
                        password,
                        full_name,
                        department,
                        role
                    )
                    VALUES (?, ?, ?, ?, ?)
                ");

                $stmt->execute([
                    $username,
                    $hashed_password,
                    $full_name,
                    $department,
                    $role
                ]);

                $success = "สร้างผู้ใช้งานสำเร็จ";

                // ล้างค่าในฟอร์ม
                $_POST = [];
            }

        } catch (PDOException $e) {

            $error = "เกิดข้อผิดพลาด: " . $e->getMessage();

        }
    }
}

?>

<!DOCTYPE html>
<html lang="th">

<head>

<meta charset="UTF-8">

<meta name="viewport"
      content="width=device-width, initial-scale=1.0">

<title>เพิ่มผู้ใช้งาน | ระบบติดตามเอกสาร</title>

<style>

*{
    box-sizing:border-box;
}

body{
    margin:0;
    font-family:Tahoma,"Noto Sans Thai",sans-serif;
    background:#f4f7fb;
    color:#263238;
}

.sidebar{
    position:fixed;
    left:0;
    top:0;
    width:250px;
    height:100vh;

    background:linear-gradient(
        180deg,
        #0d47a1,
        #1565c0
    );

    color:white;
    padding:25px 15px;
}

.logo-area{
    text-align:center;
    padding-bottom:25px;
    border-bottom:1px solid rgba(255,255,255,.2);
}

.logo-icon{
    width:65px;
    height:65px;
    margin:0 auto 12px;

    border-radius:50%;

    background:white;
    color:#1565c0;

    display:flex;
    align-items:center;
    justify-content:center;

    font-size:28px;
}

.logo-area h2{
    font-size:19px;
    margin:0;
}

.logo-area p{
    font-size:12px;
    margin-top:6px;
    opacity:.8;
}

.menu{
    margin-top:25px;
}

.menu a{
    display:block;
    color:white;
    text-decoration:none;

    padding:13px 15px;
    margin-bottom:7px;

    border-radius:10px;

    font-size:15px;
}

.menu a:hover,
.menu a.active{
    background:rgba(255,255,255,.18);
}

.menu .logout{
    margin-top:25px;
    background:rgba(198,40,40,.8);
}

.main{
    margin-left:250px;
    min-height:100vh;
}

.topbar{
    height:75px;
    background:white;

    display:flex;
    align-items:center;
    justify-content:space-between;

    padding:0 30px;

    box-shadow:0 2px 12px rgba(0,0,0,.05);
}

.topbar h1{
    margin:0;
    color:#0759a5;
    font-size:23px;
}

.user-box{
    display:flex;
    align-items:center;
    gap:12px;
}

.user-icon{
    width:42px;
    height:42px;
    border-radius:50%;

    background:#e5f2ff;

    display:flex;
    align-items:center;
    justify-content:center;
}

.user-name{
    font-weight:700;
}

.user-dept{
    font-size:12px;
    color:#64748b;
}

.content{
    padding:30px;
}

.card{
    max-width:850px;
    margin:auto;

    background:white;

    border-radius:18px;

    padding:30px;

    box-shadow:
        0 5px 20px rgba(30,64,175,.07);

    border:1px solid #e5edf7;
}

.card-title{
    font-size:20px;
    font-weight:700;

    color:#0759a5;

    margin-bottom:25px;
}

.form-grid{
    display:grid;
    grid-template-columns:1fr 1fr;
    gap:20px;
}

.form-group{
    margin-bottom:5px;
}

.form-group.full{
    grid-column:1 / -1;
}

label{
    display:block;

    margin-bottom:8px;

    font-size:14px;

    font-weight:600;
}

input,
select{
    width:100%;

    padding:12px 14px;

    border:1px solid #d8e2ef;

    border-radius:10px;

    font-size:14px;

    outline:none;

    background:white;
}

input:focus,
select:focus{
    border-color:#1683dc;

    box-shadow:
        0 0 0 3px
        rgba(22,131,220,.08);
}

.help{
    font-size:12px;
    color:#64748b;
    margin-top:6px;
}

.alert{
    padding:13px 15px;

    border-radius:10px;

    margin-bottom:20px;

    font-size:14px;
}

.alert-error{
    background:#fef2f2;
    color:#b91c1c;
    border:1px solid #fecaca;
}

.alert-success{
    background:#f0fdf4;
    color:#15803d;
    border:1px solid #bbf7d0;
}

.buttons{
    display:flex;
    gap:10px;

    margin-top:25px;
}

.btn{
    display:inline-block;

    padding:11px 18px;

    border:none;

    border-radius:10px;

    text-decoration:none;

    font-size:14px;

    font-weight:600;

    cursor:pointer;
}

.btn-green{
    background:#16a34a;
    color:white;
}

.btn-blue{
    background:#1565c0;
    color:white;
}

.btn-gray{
    background:#e2e8f0;
    color:#475569;
}

@media(max-width:700px){

    .sidebar{
        position:relative;
        width:100%;
        height:auto;
    }

    .main{
        margin-left:0;
    }

    .topbar{
        height:auto;
        padding:18px;

        flex-direction:column;
        align-items:flex-start;

        gap:15px;
    }

    .content{
        padding:18px;
    }

    .form-grid{
        grid-template-columns:1fr;
    }

    .form-group.full{
        grid-column:auto;
    }

}

</style>

</head>

<body>


<!-- SIDEBAR -->

<div class="sidebar">

    <div class="logo-area">
<img src="oo.image/S__29155335.jpg"
     alt="โลโก้เทศบาล"
     style="
        width:95px;
        height:95px;
        border-radius:50%;
        object-fit:cover;
        display:block;
        margin:0 auto 15px;
        border:4px solid #fff;
        box-shadow:0 4px 15px rgba(0,0,0,.15)";
        >

        <h2>
            ระบบติดตามเอกสาร
        </h2>

        <p>
            Document Tracking System
        </p>

    </div>


    <div class="menu">

        <a href="dashboard.php">
            🏠 หน้าหลัก
        </a>

        <a href="search.php">
            🔎 ค้นหางาน
        </a>

        <a href="add_document.php">
            ➕ เพิ่มเอกสาร
        </a>

        <a href="documents.php">
            📋 เอกสารทั้งหมด
        </a>

        <a href="users.php" class="active">
            👥 จัดการผู้ใช้งาน
        </a>

        <a href="logout.php" class="logout">
            🚪 ออกจากระบบ
        </a>

    </div>

</div>


<!-- MAIN -->

<div class="main">


    <div class="topbar">

        <h1>
            👥 เพิ่มผู้ใช้งาน
        </h1>

        <div class="user-box">

            <div class="user-icon">
                👤
            </div>

            <div>

                <div class="user-name">
                    <?= htmlspecialchars($_SESSION["full_name"]) ?>
                </div>

                <div class="user-dept">
                    <?= htmlspecialchars($_SESSION["department"]) ?>
                </div>

            </div>

        </div>

    </div>


    <div class="content">

        <div class="card">

            <div class="card-title">
                ➕ สร้างบัญชีผู้ใช้งาน
            </div>


            <?php if ($error !== ""): ?>

                <div class="alert alert-error">
                    ❌ <?= htmlspecialchars($error) ?>
                </div>

            <?php endif; ?>


            <?php if ($success !== ""): ?>

                <div class="alert alert-success">
                    ✅ <?= htmlspecialchars($success) ?>
                </div>

            <?php endif; ?>


            <form method="POST">


                <div class="form-grid">


                    <!-- USERNAME -->

                    <div class="form-group">

                        <label>
                            Username *
                        </label>

                        <input
                            type="text"
                            name="username"
                            required
                            autocomplete="off"
                            value="<?= htmlspecialchars($_POST["username"] ?? "") ?>"
                            placeholder="เช่น user01"
                        >

                        <div class="help">
                            ใช้สำหรับเข้าสู่ระบบ
                        </div>

                    </div>


                    <!-- PASSWORD -->

                    <div class="form-group">

                        <label>
                            Password *
                        </label>

                        <input
                            type="password"
                            name="password"
                            required
                            autocomplete="new-password"
                            placeholder="กำหนดรหัสผ่าน"
                        >

                        <div class="help">
                            แนะนำให้ใช้รหัสผ่านที่คาดเดาได้ยาก
                        </div>

                    </div>


                    <!-- NAME -->

                    <div class="form-group">

                        <label>
                            ชื่อ-นามสกุล *
                        </label>

                        <input
                            type="text"
                            name="full_name"
                            required
                            value="<?= htmlspecialchars($_POST["full_name"] ?? "") ?>"
                            placeholder="เช่น นายสมชาย ใจดี"
                        >

                    </div>


                    <!-- DEPARTMENT -->

                    <div class="form-group">

                        <label>
                            หน่วยงาน
                        </label>

                        <input
                            type="text"
                            name="department"
                            value="<?= htmlspecialchars($_POST["department"] ?? "") ?>"
                            placeholder="เช่น สำนักปลัดเทศบาล"
                        >

                    </div>


                    <!-- ROLE -->

                    <div class="form-group full">

                        <label>
                            สิทธิ์ผู้ใช้งาน
                        </label>

                        <select name="role">

                            <option
                                value="user"
                                <?= ($_POST["role"] ?? "user") === "user"
                                    ? "selected"
                                    : "" ?>
                            >
                                👤 ผู้ใช้งาน
                            </option>

                            

                        </select>

                    </div>


                </div>


                <div class="buttons">

                    <button
                        type="submit"
                        class="btn btn-green"
                    >
                        💾 สร้างผู้ใช้งาน
                    </button>

                    <a
                        href="users.php"
                        class="btn btn-gray"
                    >
                        ← ยกเลิก
                    </a>

                </div>


            </form>

        </div>

    </div>

</div>

</body>

</html>