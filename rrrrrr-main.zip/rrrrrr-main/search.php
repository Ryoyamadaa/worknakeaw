<?php

require_once "config.php";

/* ตรวจสอบ Login */
if (!isset($_SESSION["user_id"])) {
    header("Location: login.php");
    exit;
}

/* สถานะทั้ง 6 */
$statuses = [
    "ลงรับแล้ว",
    "กำลังดำเนินการ",
    "เสนอหัวหน้าสำนักปลัด",
    "เสนอผู้บริหาร",
    "ส่งให้ผู้ที่ได้รับมอบ",
    "เสร็จสมบูรณ์"
];

/* รับค่าค้นหา */
$document_no = trim($_GET["document_no"] ?? "");
$subject = trim($_GET["subject"] ?? "");
$department = trim($_GET["department"] ?? "");
$responsible_person = trim($_GET["responsible_person"] ?? "");
$status = trim($_GET["status"] ?? "");
$priority = trim($_GET["priority"] ?? "");
$date_from = trim($_GET["date_from"] ?? "");
$date_to = trim($_GET["date_to"] ?? "");

/*
|--------------------------------------------------------------------------
| สร้าง SQL
|--------------------------------------------------------------------------
*/

$sql = "
    SELECT
        d.id,
        d.document_no,
        d.document_date,
        d.subject,
        d.sender,
        d.receiver,
        d.department,
        d.responsible_person,
        d.received_date,
        d.due_date,
        d.status,
        d.priority
    FROM documents d
    WHERE 1=1
";

$params = [];

/* เลขที่หนังสือ */
if ($document_no !== "") {

    $sql .= "
        AND d.document_no LIKE ?
    ";

    $params[] = "%{$document_no}%";
}

/* เรื่อง */
if ($subject !== "") {

    $sql .= "
        AND d.subject LIKE ?
    ";

    $params[] = "%{$subject}%";
}

/* หน่วยงาน */
if ($department !== "") {

    $sql .= "
        AND d.department LIKE ?
    ";

    $params[] = "%{$department}%";
}

/* ผู้รับผิดชอบ */
if ($responsible_person !== "") {

    $sql .= "
        AND d.responsible_person LIKE ?
    ";

    $params[] = "%{$responsible_person}%";
}

/* สถานะ */
if ($status !== "") {

    $sql .= "
        AND d.status = ?
    ";

    $params[] = $status;
}

/* ความเร่งด่วน */
if ($priority !== "") {

    $sql .= "
        AND d.priority = ?
    ";

    $params[] = $priority;
}

/* วันที่รับ - เริ่มต้น */
if ($date_from !== "") {

    $sql .= "
        AND DATE(d.received_date) >= ?
    ";

    $params[] = $date_from;
}

/* วันที่รับ - สิ้นสุด */
if ($date_to !== "") {

    $sql .= "
        AND DATE(d.received_date) <= ?
    ";

    $params[] = $date_to;
}

$sql .= "
    ORDER BY d.id DESC
";

$stmt = $pdo->prepare($sql);
$stmt->execute($params);

$documents = $stmt->fetchAll();

/* จำนวนผลการค้นหา */
$result_count = count($documents);

/* ดึงชื่อหน่วยงานที่มีอยู่ในระบบ */
$stmt = $pdo->query("
    SELECT DISTINCT department
    FROM documents
    WHERE department <> ''
    ORDER BY department
");

$departments = $stmt->fetchAll();

?>

<!DOCTYPE html>
<html lang="th">

<head>

<meta charset="UTF-8">

<meta name="viewport"
      content="width=device-width, initial-scale=1.0">

<title>ค้นหางาน | ระบบติดตามเอกสาร</title>

<style>

* {
    box-sizing: border-box;
}

body {

    margin: 0;

    font-family:
        Tahoma,
        "Noto Sans Thai",
        sans-serif;

    background: #f4f7fb;

    color: #263238;
}

/* =========================
   Sidebar
========================= */

.sidebar {

    position: fixed;

    left: 0;
    top: 0;

    width: 250px;
    height: 100vh;

    background:
        linear-gradient(
            180deg,
            #0d47a1,
            #1565c0
        );

    color: white;

    padding: 25px 15px;
}

.logo-area {

    text-align: center;

    padding-bottom: 25px;

    border-bottom:
        1px solid
        rgba(255,255,255,.2);
}

.logo-icon {

    width: 65px;
    height: 65px;

    margin: auto;

    border-radius: 50%;

    background: white;

    color: #1565c0;

    display: flex;

    align-items: center;

    justify-content: center;

    font-size: 28px;

    margin-bottom: 12px;
}

.logo-area h2 {

    font-size: 19px;

    margin: 0;
}

.logo-area p {

    font-size: 12px;

    opacity: .8;
}

.menu {

    margin-top: 25px;
}

.menu a {

    display: block;

    color: white;

    text-decoration: none;

    padding: 13px 15px;

    margin-bottom: 7px;

    border-radius: 10px;

    font-size: 15px;
}

.menu a:hover,
.menu a.active {

    background:
        rgba(255,255,255,.18);
}

.menu .logout {

    margin-top: 25px;

    background:
        rgba(198,40,40,.8);
}

/* =========================
   Main
========================= */

.main {

    margin-left: 250px;

    min-height: 100vh;
}

/* =========================
   Topbar
========================= */

.topbar {

    height: 75px;

    background: white;

    display: flex;

    align-items: center;

    justify-content: space-between;

    padding: 0 30px;

    box-shadow:
        0 2px 10px
        rgba(0,0,0,.06);
}

.topbar h1 {

    margin: 0;

    color: #0d47a1;

    font-size: 22px;
}

.user-info {

    text-align: right;
}

.user-name {

    color: #1565c0;

    font-weight: bold;
}

.user-department {

    color: #78909c;

    font-size: 12px;

    margin-top: 3px;
}

/* =========================
   Content
========================= */

.content {

    padding: 30px;
}

/* =========================
   Search box
========================= */

.search-card {

    background: white;

    border-radius: 18px;

    padding: 25px;

    box-shadow:
        0 4px 18px
        rgba(0,0,0,.06);

    margin-bottom: 25px;
}

.search-title {

    margin: 0 0 20px;

    font-size: 20px;

    color: #0d47a1;
}

.search-grid {

    display: grid;

    grid-template-columns:
        repeat(3, 1fr);

    gap: 18px;
}

.form-group label {

    display: block;

    margin-bottom: 7px;

    font-size: 14px;

    font-weight: bold;

    color: #455a64;
}

.form-group input,
.form-group select {

    width: 100%;

    height: 44px;

    border: 1px solid #cfd8dc;

    border-radius: 9px;

    padding: 0 12px;

    font-size: 14px;

    background: white;

    outline: none;
}

.form-group input:focus,
.form-group select:focus {

    border-color: #1976d2;

    box-shadow:
        0 0 0 3px
        rgba(25,118,210,.10);
}

.search-actions {

    display: flex;

    gap: 10px;

    margin-top: 20px;
}

.btn-search {

    border: none;

    background:
        linear-gradient(
            135deg,
            #1565c0,
            #1e88e5
        );

    color: white;

    padding: 11px 25px;

    border-radius: 9px;

    cursor: pointer;

    font-weight: bold;

    font-size: 14px;
}

.btn-reset {

    text-decoration: none;

    background: #eceff1;

    color: #455a64;

    padding: 11px 25px;

    border-radius: 9px;

    font-size: 14px;
}

/* =========================
   Results
========================= */

.result-card {

    background: white;

    border-radius: 18px;

    padding: 25px;

    box-shadow:
        0 4px 18px
        rgba(0,0,0,.06);
}

.result-header {

    display: flex;

    justify-content: space-between;

    align-items: center;

    margin-bottom: 20px;
}

.result-header h2 {

    margin: 0;

    font-size: 19px;
}

.result-count {

    color: #1565c0;

    font-weight: bold;
}

/* =========================
   Table
========================= */

.table-wrapper {

    overflow-x: auto;
}

table {

    width: 100%;

    border-collapse: collapse;

    min-width: 1050px;
}

th {

    background: #e3f2fd;

    color: #0d47a1;

    padding: 13px 10px;

    text-align: left;

    font-size: 13px;

    white-space: nowrap;
}

td {

    padding: 13px 10px;

    border-bottom:
        1px solid #eeeeee;

    font-size: 13px;

    vertical-align: middle;
}

tr:hover td {

    background: #f8fbff;
}

/* =========================
   Badge
========================= */

.badge {

    display: inline-block;

    padding: 6px 10px;

    border-radius: 20px;

    font-size: 11px;

    white-space: nowrap;

    background: #e3f2fd;

    color: #1565c0;
}

.view-button {

    display: inline-block;

    text-decoration: none;

    background: #1565c0;

    color: white;

    padding: 6px 12px;

    border-radius: 7px;

    font-size: 12px;
}

.view-button:hover {

    background: #0d47a1;
}

.empty {

    text-align: center;

    padding: 50px 20px;

    color: #90a4ae;
}

/* =========================
   Responsive
========================= */

@media (max-width: 1000px) {

    .search-grid {

        grid-template-columns:
            repeat(2, 1fr);
    }
}

@media (max-width: 700px) {

    .sidebar {

        position: relative;

        width: 100%;

        height: auto;
    }

    .main {

        margin-left: 0;
    }

    .topbar {

        height: auto;

        padding: 18px;

    }

    .content {

        padding: 18px;
    }

    .search-grid {

        grid-template-columns: 1fr;
    }

    .search-actions {

        flex-direction: column;
    }

    .btn-search,
    .btn-reset {

        text-align: center;
    }
}

</style>

</head>

<body>


<!-- =========================
     Sidebar
========================= -->

<div class="sidebar">

    <div class="logo-area">

        <img src="oo.image/S__29155335.jpg"
     alt="โลโก้เทศบาล"
     style="
        width:95px;
        height:95px;
        border-radius:50%;
        object-fit:cover;
        display:block;
        margin:0 auto 15px;
        border:4px solid #fff;
        box-shadow:0 4px 15px rgba(0,0,0,.15);
     ">


        <h2>
            ระบบติดตามเอกสาร
        </h2>

        <p>
            Document Tracking System
        </p>

    </div>


    <div class="menu">

        <a href="dashboard.php">
            🏠 หน้าหลัก
        </a>

        <a href="search.php"
           class="active">
            🔎 ค้นหางาน
        </a>

        <a href="add_document.php">
            ➕ เพิ่มเอกสาร
        </a>

        <a href="documents.php">
            📋 เอกสารทั้งหมด
        </a>

        <?php if ($_SESSION["role"] === "admin"): ?>

            <a href="users.php">
                👥 จัดการผู้ใช้งาน
            </a>

        <?php endif; ?>

        <a href="logout.php"
           class="logout">
            🚪 ออกจากระบบ
        </a>

    </div>

</div>


<!-- =========================
     Main
========================= -->

<div class="main">


    <div class="topbar">

        <h1>
            🔎 ค้นหางาน
        </h1>

        <div class="user-info">

            <div class="user-name">

                <?= htmlspecialchars(
                    $_SESSION["full_name"]
                ) ?>

            </div>

            <div class="user-department">

                <?= htmlspecialchars(
                    $_SESSION["department"]
                ) ?>

            </div>

        </div>

    </div>


    <div class="content">


        <!-- Search -->

        <div class="search-card">

            <h2 class="search-title">
                🔎 ค้นหาเอกสาร
            </h2>


            <form method="GET">

                <div class="search-grid">


                    <!-- เลขที่หนังสือ -->

                    <div class="form-group">

                        <label>
                            เลขที่หนังสือ
                        </label>

                        <input
                            type="text"
                            name="document_no"
                            value="<?= htmlspecialchars($document_no) ?>"
                            placeholder="เช่น ลป 123/2569"
                        >

                    </div>


                    <!-- เรื่อง -->

                    <div class="form-group">

                        <label>
                            เรื่อง
                        </label>

                        <input
                            type="text"
                            name="subject"
                            value="<?= htmlspecialchars($subject) ?>"
                            placeholder="ค้นหาชื่อเรื่อง"
                        >

                    </div>


                    <!-- หน่วยงาน -->

                    <div class="form-group">

                        <label>
                            หน่วยงาน
                        </label>

                        <select name="department">

                            <option value="">
                                -- ทุกหน่วยงาน --
                            </option>

                            <?php foreach ($departments as $dept): ?>

                                <option
                                    value="<?= htmlspecialchars($dept["department"]) ?>"
                                    <?= $department === $dept["department"]
                                        ? "selected"
                                        : ""
                                    ?>
                                >
                                    <?= htmlspecialchars($dept["department"]) ?>
                                </option>

                            <?php endforeach; ?>

                        </select>

                    </div>


                    <!-- ผู้รับผิดชอบ -->

                    <div class="form-group">

                        <label>
                            ผู้รับผิดชอบ
                        </label>

                        <input
                            type="text"
                            name="responsible_person"
                            value="<?= htmlspecialchars($responsible_person) ?>"
                            placeholder="ชื่อผู้รับผิดชอบ"
                        >

                    </div>


                    <!-- สถานะ -->

                    <div class="form-group">

                        <label>
                            สถานะ
                        </label>

                        <select name="status">

                            <option value="">
                                -- ทุกสถานะ --
                            </option>

                            <?php foreach ($statuses as $item): ?>

                                <option
                                    value="<?= htmlspecialchars($item) ?>"
                                    <?= $status === $item
                                        ? "selected"
                                        : ""
                                    ?>
                                >
                                    <?= htmlspecialchars($item) ?>
                                </option>

                            <?php endforeach; ?>

                        </select>

                    </div>


                    <!-- ความเร่งด่วน -->

                    <div class="form-group">

                        <label>
                            ความเร่งด่วน
                        </label>

                        <select name="priority">

                            <option value="">
                                -- ทุกระดับ --
                            </option>

                            <option value="ปกติ"
                                <?= $priority === "ปกติ" ? "selected" : "" ?>>
                                ปกติ
                            </option>

                            <option value="ด่วน"
                                <?= $priority === "ด่วน" ? "selected" : "" ?>>
                                ด่วน
                            </option>

                            <option value="ด่วนมาก"
                                <?= $priority === "ด่วนมาก" ? "selected" : "" ?>>
                                ด่วนมาก
                            </option>

                            <option value="ด่วนที่สุด"
                                <?= $priority === "ด่วนที่สุด" ? "selected" : "" ?>>
                                ด่วนที่สุด
                            </option>

                        </select>

                    </div>


                    <!-- วันที่เริ่มต้น -->

                    <div class="form-group">

                        <label>
                            วันที่รับเอกสาร ตั้งแต่
                        </label>

                        <input
                            type="date"
                            name="date_from"
                            value="<?= htmlspecialchars($date_from) ?>"
                        >

                    </div>


                    <!-- วันที่สิ้นสุด -->

                    <div class="form-group">

                        <label>
                            วันที่รับเอกสาร ถึง
                        </label>

                        <input
                            type="date"
                            name="date_to"
                            value="<?= htmlspecialchars($date_to) ?>"
                        >

                    </div>


                </div>


                <div class="search-actions">

                    <button
                        type="submit"
                        class="btn-search"
                    >
                        🔎 ค้นหา
                    </button>

                    <a
                        href="search.php"
                        class="btn-reset"
                    >
                        ↻ ล้างการค้นหา
                    </a>

                </div>

            </form>

        </div>


        <!-- Results -->

        <div class="result-card">

            <div class="result-header">

                <h2>
                    📋 ผลการค้นหา
                </h2>

                <div class="result-count">

                    พบ <?= number_format($result_count) ?> รายการ

                </div>

            </div>


            <?php if ($result_count > 0): ?>

                <div class="table-wrapper">

                    <table>

                        <thead>

                            <tr>

                                <th>
                                    เลขที่หนังสือ
                                </th>

                                <th>
                                    เรื่อง
                                </th>

                                <th>
                                    หน่วยงาน
                                </th>

                                <th>
                                    ผู้รับผิดชอบ
                                </th>

                                <th>
                                    ความเร่งด่วน
                                </th>

                                <th>
                                    สถานะ
                                </th>

                                <th>
                                    วันที่รับ
                                </th>

                                <th>
                                    กำหนดเสร็จ
                                </th>

                                <th>
                                    รายละเอียด
                                </th>

                            </tr>

                        </thead>

                        <tbody>

                        <?php foreach ($documents as $doc): ?>

                            <tr>

                                <td>
                                    <?= htmlspecialchars(
                                        $doc["document_no"]
                                    ) ?>
                                </td>

                                <td>
                                    <?= htmlspecialchars(
                                        $doc["subject"]
                                    ) ?>
                                </td>

                                <td>
                                    <?= htmlspecialchars(
                                        $doc["department"]
                                    ) ?>
                                </td>

                                <td>
                                    <?= htmlspecialchars(
                                        $doc["responsible_person"]
                                    ) ?>
                                </td>

                                <td>

                                    <span class="priority">

                                        <?= htmlspecialchars(
                                            $doc["priority"]
                                        ) ?>

                                    </span>

                                </td>

                                <td>

                                    <span class="badge">

                                        <?= htmlspecialchars(
                                            $doc["status"]
                                        ) ?>

                                    </span>

                                </td>

                                <td>

                                    <?= $doc["received_date"]
                                        ? date(
                                            "d/m/Y H:i",
                                            strtotime(
                                                $doc["received_date"]
                                            )
                                        )
                                        : "-"
                                    ?>

                                </td>

                                <td>

                                    <?= $doc["due_date"]
                                        ? date(
                                            "d/m/Y",
                                            strtotime(
                                                $doc["due_date"]
                                            )
                                        )
                                        : "-"
                                    ?>

                                </td>

                                <td>

                                    <a
                                        href="document.php?id=<?= $doc["id"] ?>"
                                        class="view-button"
                                    >
                                        👁️ ดู
                                    </a>

                                </td>

                            </tr>

                        <?php endforeach; ?>

                        </tbody>

                    </table>

                </div>

            <?php else: ?>

                <div class="empty">

                    <div style="font-size:40px;">
                        🔍
                    </div>

                    <p>
                        ไม่พบเอกสารที่ตรงกับเงื่อนไขการค้นหา
                    </p>

                </div>

            <?php endif; ?>

        </div>


    </div>

</div>

</body>

</html>