<?php

error_reporting(E_ALL);
ini_set('display_errors', 1);

require_once "config.php";
$error = "";

if ($_SERVER["REQUEST_METHOD"] === "POST") {

    $username = trim($_POST["username"] ?? "");
    $password = $_POST["password"] ?? "";

    if ($username === "" || $password === "") {

        $error = "กรุณากรอกชื่อผู้ใช้งานและรหัสผ่าน";

    } else {

        $stmt = $pdo->prepare("
            SELECT
                id,
                username,
                password,
                full_name,
                department,
                role
            FROM users
            WHERE username = ?
            LIMIT 1
        ");

        $stmt->execute([$username]);

        $user = $stmt->fetch();

        if ($user && password_verify($password, $user["password"])) {

            $_SESSION["user_id"] = $user["id"];
            $_SESSION["username"] = $user["username"];
            $_SESSION["full_name"] = $user["full_name"];
            $_SESSION["department"] = $user["department"];
            $_SESSION["role"] = $user["role"];

            header("Location: dashboard.php");
            exit;

        } else {

            $error = "ชื่อผู้ใช้งานหรือรหัสผ่านไม่ถูกต้อง";

        }
    }
}

?>

<!DOCTYPE html>
<html lang="th">

<head>

    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">

    <title>เข้าสู่ระบบ | ระบบติดตามเอกสาร</title>

    <style>

        * {
            box-sizing: border-box;
        }

        body {
            margin: 0;
            font-family: "Tahoma", "Noto Sans Thai", sans-serif;
            background:
                linear-gradient(
                    135deg,
                    #0d47a1 0%,
                    #1976d2 45%,
                    #64b5f6 100%
                );
            min-height: 100vh;
            display: flex;
            align-items: center;
            justify-content: center;
            color: #263238;
        }

        .login-wrapper {
            width: 100%;
            max-width: 430px;
            padding: 20px;
        }

        .login-card {
            background: rgba(255, 255, 255, 0.98);
            border-radius: 24px;
            padding: 40px 38px;
            box-shadow:
                0 20px 50px rgba(0, 0, 0, 0.20);
        }

        .logo {
            width: 82px;
            height: 82px;
            margin: 0 auto 20px;
            border-radius: 50%;
            background: linear-gradient(
                135deg,
                #1565c0,
                #42a5f5
            );
            display: flex;
            align-items: center;
            justify-content: center;
            color: white;
            font-size: 36px;
            font-weight: bold;
            box-shadow: 0 8px 20px rgba(21, 101, 192, 0.30);
        }

        h1 {
            margin: 0;
            text-align: center;
            color: #0d47a1;
            font-size: 27px;
        }

        .subtitle {
            text-align: center;
            color: #78909c;
            margin: 8px 0 30px;
            font-size: 15px;
        }

        .form-group {
            margin-bottom: 20px;
        }

        label {
            display: block;
            margin-bottom: 8px;
            font-weight: bold;
            color: #37474f;
        }

        input {
            width: 100%;
            height: 48px;
            border: 1px solid #cfd8dc;
            border-radius: 12px;
            padding: 0 15px;
            font-size: 16px;
            outline: none;
            transition: 0.2s;
        }

        input:focus {
            border-color: #1976d2;
            box-shadow: 0 0 0 3px rgba(25, 118, 210, 0.12);
        }

        .error {
            background: #ffebee;
            color: #c62828;
            border: 1px solid #ffcdd2;
            border-radius: 10px;
            padding: 12px 14px;
            margin-bottom: 20px;
            text-align: center;
            font-size: 14px;
        }

        button {
            width: 100%;
            height: 50px;
            border: none;
            border-radius: 12px;
            background: linear-gradient(
                135deg,
                #1565c0,
                #1e88e5
            );
            color: white;
            font-size: 17px;
            font-weight: bold;
            cursor: pointer;
            transition: 0.2s;
        }

        button:hover {
            transform: translateY(-1px);
            box-shadow: 0 8px 18px rgba(21, 101, 192, 0.30);
        }

        .footer {
            text-align: center;
            margin-top: 25px;
            color: #90a4ae;
            font-size: 13px;
        }

        @media (max-width: 480px) {

            .login-card {
                padding: 30px 24px;
            }

            h1 {
                font-size: 23px;
            }
        }

    </style>

</head>

<body>

<div class="login-wrapper">

    <div class="login-card">

        <img src="oo.image/S__29155335.jpg"
     alt="โลโก้เทศบาล"
     style="
        width:95px;
        height:95px;
        border-radius:50%;
        object-fit:cover;
        display:block;
        margin:0 auto 15px;
        border:4px solid #fff;
        box-shadow:0 4px 15px rgba(0,0,0,.15);
     ">


        <h1>
            ระบบติดตามเอกสาร
        </h1>

        <div class="subtitle">
            กรุณาเข้าสู่ระบบเพื่อใช้งาน
        </div>

        <?php if ($error !== ""): ?>

            <div class="error">
                <?= htmlspecialchars($error) ?>
            </div>

        <?php endif; ?>

        <form method="POST">

            <div class="form-group">

                <label>
                    ชื่อผู้ใช้งาน
                </label>

                <input
                    type="text"
                    name="username"
                    placeholder="กรอกชื่อผู้ใช้งาน"
                    autocomplete="username"
                    required
                >

            </div>

            <div class="form-group">

                <label>
                    รหัสผ่าน
                </label>

                <input
                    type="password"
                    name="password"
                    placeholder="กรอกรหัสผ่าน"
                    autocomplete="current-password"
                    required
                >

            </div>

            <button type="submit">
                เข้าสู่ระบบ
            </button>

        </form>

        <div class="footer">
            ระบบติดตามและตรวจสอบสถานะเอกสาร
        </div>

    </div>

</div>

</body>

</html>