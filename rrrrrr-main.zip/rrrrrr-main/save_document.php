<?php

error_reporting(E_ALL);
ini_set("display_errors", 1);

require_once "config.php";


/* =========================================================
   ตรวจสอบ Login
========================================================= */

if (!isset($_SESSION["user_id"])) {

    header("Location: login.php");
    exit;

}


/* =========================================================
   รับข้อมูลจากฟอร์ม
========================================================= */

$document_no = trim($_POST["document_no"] ?? "");
$document_date = trim($_POST["document_date"] ?? "");
$subject = trim($_POST["subject"] ?? "");
$sender = trim($_POST["sender"] ?? "");
$receiver = trim($_POST["receiver"] ?? "");
$department = trim($_POST["department"] ?? "");
$responsible_person = trim($_POST["responsible_person"] ?? "");
$received_date = trim($_POST["received_date"] ?? "");
$due_date = trim($_POST["due_date"] ?? "");
$status = trim($_POST["status"] ?? "ลงรับแล้ว");
$priority = trim($_POST["priority"] ?? "ปกติ");
$detail = trim($_POST["detail"] ?? "");
$result = trim($_POST["result"] ?? "");


/* =========================================================
   ตรวจสอบข้อมูลจำเป็น
========================================================= */

if ($document_no === "") {

    die("
        <div style='
            font-family:Tahoma,Arial,sans-serif;
            max-width:700px;
            margin:80px auto;
            padding:35px;
            background:white;
            border-radius:18px;
            box-shadow:0 5px 25px rgba(0,0,0,.08);
            text-align:center;
        '>

            <div style='font-size:55px;'>⚠️</div>

            <h2 style='color:#dc2626;'>
                กรุณากรอกเลขที่เอกสาร
            </h2>

            <a href='add_document.php'
                style='
                    display:inline-block;
                    margin-top:15px;
                    padding:11px 20px;
                    background:#1565c0;
                    color:white;
                    text-decoration:none;
                    border-radius:10px;
                '>
                ← กลับไปเพิ่มเอกสาร
            </a>

        </div>
    ");

    exit;
}


if ($subject === "") {

    die("
        <div style='
            font-family:Tahoma,Arial,sans-serif;
            max-width:700px;
            margin:80px auto;
            padding:35px;
            background:white;
            border-radius:18px;
            box-shadow:0 5px 25px rgba(0,0,0,.08);
            text-align:center;
        '>

            <div style='font-size:55px;'>⚠️</div>

            <h2 style='color:#dc2626;'>
                กรุณากรอกเรื่องเอกสาร
            </h2>

            <a href='add_document.php'
                style='
                    display:inline-block;
                    margin-top:15px;
                    padding:11px 20px;
                    background:#1565c0;
                    color:white;
                    text-decoration:none;
                    border-radius:10px;
                '>
                ← กลับไปเพิ่มเอกสาร
            </a>

        </div>
    ");

    exit;
}


/* =========================================================
   ตรวจสอบสถานะ
========================================================= */

$allowed_statuses = [

    "ลงรับแล้ว",
    "กำลังดำเนินการ",
    "เสนอหัวหน้าสำนักปลัด",
    "เสนอผู้บริหาร",
    "ส่งให้ผู้ที่ได้รับมอบ",
    "เสร็จสมบูรณ์"

];


if (!in_array($status, $allowed_statuses, true)) {

    $status = "ลงรับแล้ว";

}


/* =========================================================
   ตรวจสอบความเร่งด่วน
========================================================= */

$allowed_priorities = [

    "ปกติ",
    "ด่วน",
    "ด่วนมาก",
    "ด่วนที่สุด"

];


if (!in_array($priority, $allowed_priorities, true)) {

    $priority = "ปกติ";

}


/* =========================================================
   แปลงวันที่
========================================================= */

if ($document_date === "") {

    $document_date = null;

}


if ($due_date === "") {

    $due_date = null;

}


/* =========================================================
   วันที่รับเอกสาร
========================================================= */

if ($received_date === "") {

    $received_date = date("Y-m-d H:i:s");

} else {

    $received_date = str_replace("T", " ", $received_date);

    if (strlen($received_date) === 16) {

        $received_date .= ":00";

    }

}


/* =========================================================
   เริ่มบันทึกข้อมูล
========================================================= */

try {


    /* =====================================================
       เริ่ม Transaction
    ===================================================== */

    $pdo->beginTransaction();


    /* =====================================================
       เพิ่มข้อมูลเอกสาร
    ===================================================== */

    $stmt = $pdo->prepare("
        INSERT INTO documents
        (
            document_no,
            document_date,
            subject,
            sender,
            receiver,
            department,
            responsible_person,
            received_date,
            due_date,
            status,
            priority,
            detail,
            result,
            created_by
        )
        VALUES
        (
            ?,
            ?,
            ?,
            ?,
            ?,
            ?,
            ?,
            ?,
            ?,
            ?,
            ?,
            ?,
            ?,
            ?
        )
    ");


    $stmt->execute([

        $document_no,
        $document_date,
        $subject,
        $sender,
        $receiver,
        $department,
        $responsible_person,
        $received_date,
        $due_date,
        $status,
        $priority,
        $detail,
        $result,
        $_SESSION["user_id"]

    ]);


    /* =====================================================
       ID เอกสาร
    ===================================================== */

    $document_id = $pdo->lastInsertId();


    /* =====================================================
       อัปโหลดไฟล์แนบ
    ===================================================== */

    $upload_dir = __DIR__ . "/uploads/";


    /* สร้างโฟลเดอร์ uploads ถ้ายังไม่มี */

    if (!is_dir($upload_dir)) {

        mkdir($upload_dir, 0777, true);

    }


    /* =====================================================
       ตรวจสอบว่ามีไฟล์แนบหรือไม่
    ===================================================== */

    if (
        isset($_FILES["attachments"]) &&
        isset($_FILES["attachments"]["name"]) &&
        is_array($_FILES["attachments"]["name"])
    ) {


        /* =================================================
           ประเภทไฟล์ที่อนุญาต
        ================================================= */

        $allowed_extensions = [

            "pdf",
            "doc",
            "docx",
            "xls",
            "xlsx",
            "jpg",
            "jpeg",
            "png"

        ];


        /* 10 MB */

        $max_size = 10 * 1024 * 1024;


        /* =================================================
           เตรียมคำสั่งบันทึกไฟล์
        ================================================= */

        $file_stmt = $pdo->prepare("
            INSERT INTO document_files
            (
                document_id,
                file_name,
                file_path,
                uploaded_by
            )
            VALUES
            (
                ?,
                ?,
                ?,
                ?
            )
        ");


        /* =================================================
           วนไฟล์ทั้งหมด
        ================================================= */

        foreach (
            $_FILES["attachments"]["name"]
            as $key => $original_name
        ) {


            /* ไม่มีไฟล์ */

            if (
                empty($original_name) ||
                !isset($_FILES["attachments"]["tmp_name"][$key])
            ) {

                continue;

            }


            /* =================================================
               ตรวจสอบ Error
            ================================================= */

            $upload_error =
                $_FILES["attachments"]["error"][$key]
                ?? UPLOAD_ERR_NO_FILE;


            if ($upload_error === UPLOAD_ERR_NO_FILE) {

                continue;

            }


            if ($upload_error !== UPLOAD_ERR_OK) {

                throw new Exception(
                    "ไม่สามารถอัปโหลดไฟล์ได้: "
                    . $original_name
                );

            }


            /* =================================================
               ข้อมูลไฟล์
            ================================================= */

            $tmp_name =
                $_FILES["attachments"]["tmp_name"][$key];

            $file_size =
                (int)$_FILES["attachments"]["size"][$key];


            $extension = strtolower(
                pathinfo(
                    $original_name,
                    PATHINFO_EXTENSION
                )
            );


            /* =================================================
               ตรวจสอบนามสกุล
            ================================================= */

            if (
                !in_array(
                    $extension,
                    $allowed_extensions,
                    true
                )
            ) {

                throw new Exception(
                    "ไฟล์ "
                    . $original_name
                    . " ไม่รองรับ"
                );

            }


            /* =================================================
               ตรวจสอบขนาด
            ================================================= */

            if ($file_size > $max_size) {

                throw new Exception(
                    "ไฟล์ "
                    . $original_name
                    . " มีขนาดเกิน 10 MB"
                );

            }


            /* =================================================
               สร้างชื่อไฟล์ใหม่
            ================================================= */

            $new_name =
                $document_id
                . "_"
                . date("YmdHis")
                . "_"
                . bin2hex(random_bytes(5))
                . "."
                . $extension;


            $destination =
                $upload_dir
                . $new_name;


            /* =================================================
               ย้ายไฟล์เข้า uploads
            ================================================= */

            if (
                !move_uploaded_file(
                    $tmp_name,
                    $destination
                )
            ) {

                throw new Exception(
                    "ไม่สามารถจัดเก็บไฟล์ "
                    . $original_name
                    . " ได้"
                );

            }


            /* =================================================
               path สำหรับเปิดไฟล์
            ================================================= */

            $file_path =
                "uploads/"
                . $new_name;


            /* =================================================
               บันทึกข้อมูลไฟล์ลงฐานข้อมูล
            ================================================= */

            $file_stmt->execute([

                $document_id,

                $original_name,

                $file_path,

                $_SESSION["user_id"]

            ]);

        }

    }


    /* =====================================================
       บันทึกประวัติเอกสาร
    ===================================================== */

    $history = $pdo->prepare("
        INSERT INTO document_history
        (
            document_id,
            action,
            from_department,
            to_department,
            from_person,
            to_person,
            note,
            action_by
        )
        VALUES
        (
            ?,
            ?,
            ?,
            ?,
            ?,
            ?,
            ?,
            ?
        )
    ");


    $history->execute([

        $document_id,

        "ลงรับเอกสาร",

        "",

        $department,

        "",

        $responsible_person,

        "บันทึกเอกสารเข้าสู่ระบบ",

        $_SESSION["user_id"]

    ]);


    /* =====================================================
       ยืนยัน Transaction
    ===================================================== */

    $pdo->commit();


    /* =====================================================
       ไปหน้า Document
    ===================================================== */

    header(
        "Location: document.php?id="
        . (int)$document_id
    );

    exit;


} catch (Throwable $e) {


    /* =====================================================
       Rollback
    ===================================================== */

    if ($pdo->inTransaction()) {

        $pdo->rollBack();

    }


    /* =====================================================
       แสดง Error
    ===================================================== */

    echo "

    <!DOCTYPE html>

    <html lang='th'>

    <head>

        <meta charset='UTF-8'>

        <meta
            name='viewport'
            content='width=device-width, initial-scale=1.0'
        >

        <title>
            เกิดข้อผิดพลาด
        </title>

        <style>

            * {
                box-sizing: border-box;
            }

            body {

                margin: 0;

                font-family:
                    Tahoma,
                    'Noto Sans Thai',
                    sans-serif;

                background:
                    linear-gradient(
                        135deg,
                        #eef5ff,
                        #f8fbff
                    );

                color: #263238;

            }

            .error-box {

                max-width: 800px;

                margin: 80px auto;

                background: white;

                padding: 35px;

                border-radius: 18px;

                box-shadow:
                    0 5px 25px
                    rgba(0,0,0,.08);

            }

            .icon {

                text-align: center;

                font-size: 55px;

                margin-bottom: 15px;

            }

            h2 {

                text-align: center;

                color: #c62828;

                margin-bottom: 10px;

            }

            .message {

                text-align: center;

                color: #78909c;

                margin-bottom: 25px;

            }

            .error-detail {

                background: #ffebee;

                color: #b71c1c;

                padding: 15px;

                border-radius: 10px;

                word-break: break-word;

                font-size: 13px;

                line-height: 1.7;

            }

            .center {

                text-align: center;

            }

            .btn {

                display: inline-block;

                margin-top: 20px;

                padding: 11px 20px;

                background:
                    linear-gradient(
                        135deg,
                        #1565c0,
                        #1e88e5
                    );

                color: white;

                text-decoration: none;

                border-radius: 10px;

            }

        </style>

    </head>


    <body>


        <div class='error-box'>


            <div class='icon'>
                ❌
            </div>


            <h2>
                เกิดข้อผิดพลาดในการบันทึกเอกสาร
            </h2>


            <div class='message'>

                ระบบไม่สามารถบันทึกเอกสารได้

            </div>


            <div class='error-detail'>

                "
                . htmlspecialchars(
                    $e->getMessage(),
                    ENT_QUOTES,
                    'UTF-8'
                )
                . "

            </div>


            <div class='center'>

                <a
                    href='add_document.php'
                    class='btn'
                >
                    ← กลับไปเพิ่มเอกสาร
                </a>

            </div>


        </div>


    </body>

    </html>

    ";

    exit;

}

?>