<?php

require_once "config.php";


/*
|--------------------------------------------------------------------------
| ตรวจสอบ Login
|--------------------------------------------------------------------------
*/

if (!isset($_SESSION["user_id"])) {

    header("Location: login.php");

    exit;
}


/*
|--------------------------------------------------------------------------
| สถานะเริ่มต้น
|--------------------------------------------------------------------------
*/

$default_status = "ลงรับแล้ว";

?>

<!DOCTYPE html>

<html lang="th">

<head>

<meta charset="UTF-8">

<meta name="viewport"
      content="width=device-width, initial-scale=1.0">

<title>
    เพิ่มเอกสาร | ระบบติดตามเอกสาร
</title>


<style>

/* =========================
   Global
========================= */

* {
    box-sizing: border-box;
}


body {

    margin: 0;

    font-family:
        Tahoma,
        "Noto Sans Thai",
        sans-serif;

    background: #f4f7fb;

    color: #263238;

}


/* =========================
   Sidebar
========================= */

.sidebar {

    position: fixed;

    left: 0;

    top: 0;

    width: 250px;

    height: 100vh;

    background:
        linear-gradient(
            180deg,
            #0d47a1,
            #1565c0
        );

    color: white;

    padding: 25px 15px;

}


.logo-area {

    text-align: center;

    padding-bottom: 25px;

    border-bottom:
        1px solid
        rgba(255,255,255,.2);

}


.logo-icon {

    width: 65px;

    height: 65px;

    margin: auto;

    border-radius: 50%;

    background: white;

    color: #1565c0;

    display: flex;

    align-items: center;

    justify-content: center;

    font-size: 28px;

    margin-bottom: 12px;

}


.logo-area h2 {

    font-size: 19px;

    margin: 0;

}


.logo-area p {

    font-size: 12px;

    opacity: .8;

}


.menu {

    margin-top: 25px;

}


.menu a {

    display: block;

    color: white;

    text-decoration: none;

    padding: 13px 15px;

    margin-bottom: 7px;

    border-radius: 10px;

    font-size: 15px;

}


.menu a:hover,
.menu a.active {

    background:
        rgba(255,255,255,.18);

}


.menu .logout {

    margin-top: 25px;

    background:
        rgba(198,40,40,.8);

}


/* =========================
   Main
========================= */

.main {

    margin-left: 250px;

    min-height: 100vh;

}


/* =========================
   Topbar
========================= */

.topbar {

    height: 75px;

    background: white;

    display: flex;

    align-items: center;

    justify-content: space-between;

    padding: 0 30px;

    box-shadow:
        0 2px 10px
        rgba(0,0,0,.06);

}


.topbar h1 {

    margin: 0;

    color: #0d47a1;

    font-size: 22px;

}


.user-info {

    text-align: right;

}


.user-name {

    color: #1565c0;

    font-weight: bold;

}


.user-department {

    color: #78909c;

    font-size: 12px;

    margin-top: 3px;

}


/* =========================
   Content
========================= */

.content {

    padding: 30px;

}


/* =========================
   Form Card
========================= */

.form-card {

    background: white;

    border-radius: 18px;

    padding: 30px;

    box-shadow:
        0 4px 18px
        rgba(0,0,0,.06);

    max-width: 1100px;

    margin: auto;

}


.form-title {

    margin: 0 0 25px;

    color: #0d47a1;

    font-size: 21px;

    padding-bottom: 15px;

    border-bottom:
        1px solid
        #e0e0e0;

}


.form-section-title {

    color: #1565c0;

    font-size: 17px;

    margin: 25px 0 18px;

    padding-left: 10px;

    border-left:
        4px solid
        #42a5f5;

}


.form-grid {

    display: grid;

    grid-template-columns:
        repeat(2, 1fr);

    gap: 18px;

}


.form-group {

    margin-bottom: 3px;

}


.form-group.full {

    grid-column: 1 / -1;

}


.form-group label {

    display: block;

    margin-bottom: 7px;

    font-weight: bold;

    color: #455a64;

    font-size: 14px;

}


.required {

    color: #e53935;

}


.form-group input,
.form-group select,
.form-group textarea {

    width: 100%;

    border:
        1px solid
        #cfd8dc;

    border-radius: 9px;

    padding: 10px 12px;

    font-family: inherit;

    font-size: 14px;

    outline: none;

    background: white;

}


.form-group input,
.form-group select {

    height: 45px;

}


.form-group textarea {

    min-height: 110px;

    resize: vertical;

}


.form-group input:focus,
.form-group select:focus,
.form-group textarea:focus {

    border-color: #1976d2;

    box-shadow:
        0 0 0 3px
        rgba(25,118,210,.10);

}


/* =========================
   File Upload
========================= */

.file-upload-box {

    border:
        2px dashed
        #90caf9;

    background:
        #f8fbff;

    border-radius: 12px;

    padding: 20px;

    transition: .2s;

}


.file-upload-box:hover {

    border-color:
        #1976d2;

    background:
        #f1f8ff;

}


.file-upload-box input[type="file"] {

    width: 100%;

    height: auto;

    border: none;

    padding: 5px;

    background: transparent;

    cursor: pointer;

}


.file-upload-title {

    color: #1565c0;

    font-size: 15px;

    font-weight: bold;

    margin-bottom: 8px;

}


.file-upload-help {

    color: #78909c;

    font-size: 12px;

    line-height: 1.7;

    margin-top: 8px;

}


.help {

    font-size: 12px;

    color: #90a4ae;

    margin-top: 5px;

}


/* =========================
   Buttons
========================= */

.form-actions {

    display: flex;

    justify-content: flex-end;

    gap: 10px;

    margin-top: 30px;

    padding-top: 20px;

    border-top:
        1px solid
        #eeeeee;

}


.btn {

    border: none;

    border-radius: 9px;

    padding: 12px 24px;

    font-size: 14px;

    font-weight: bold;

    cursor: pointer;

    text-decoration: none;

}


.btn-save {

    color: white;

    background:
        linear-gradient(
            135deg,
            #1565c0,
            #1e88e5
        );

}


.btn-save:hover {

    background: #0d47a1;

}


.btn-cancel {

    color: #455a64;

    background: #eceff1;

}


/* =========================
   Responsive
========================= */

@media (max-width: 800px) {

    .sidebar {

        position: relative;

        width: 100%;

        height: auto;

    }


    .main {

        margin-left: 0;

    }


    .form-grid {

        grid-template-columns: 1fr;

    }


    .form-group.full {

        grid-column: auto;

    }


    .topbar {

        height: auto;

        padding: 18px;

    }


    .content {

        padding: 18px;

    }


    .form-card {

        padding: 20px;

    }

}

</style>

</head>


<body>


<!-- =========================================================
     Sidebar
========================================================= -->

<div class="sidebar">


    <div class="logo-area">


        <img
            src="oo.image/S__29155335.jpg"
            alt="โลโก้เทศบาล"

            style="
                width:95px;
                height:95px;
                border-radius:50%;
                object-fit:cover;
                display:block;
                margin:0 auto 15px;
                border:4px solid #fff;
                box-shadow:
                    0 4px 15px
                    rgba(0,0,0,.15);
            "
        >


        <h2>
            ระบบติดตามเอกสาร
        </h2>


        <p>
            Document Tracking System
        </p>


    </div>


    <div class="menu">


        <a href="dashboard.php">
            🏠 หน้าหลัก
        </a>


        <a href="search.php">
            🔎 ค้นหางาน
        </a>


        <a
            href="add_document.php"
            class="active"
        >
            ➕ เพิ่มเอกสาร
        </a>


        <a href="documents.php">
            📋 เอกสารทั้งหมด
        </a>


        <?php if ($_SESSION["role"] === "admin"): ?>

            <a href="users.php">
                👥 จัดการผู้ใช้งาน
            </a>

        <?php endif; ?>


        <a
            href="logout.php"
            class="logout"
        >
            🚪 ออกจากระบบ
        </a>


    </div>


</div>


<!-- =========================================================
     Main
========================================================= -->

<div class="main">


    <!-- =====================================================
         Topbar
    ====================================================== -->

    <div class="topbar">


        <h1>
            ➕ เพิ่มเอกสาร
        </h1>


        <div class="user-info">


            <div class="user-name">

                <?= htmlspecialchars(
                    $_SESSION["full_name"]
                ) ?>

            </div>


            <div class="user-department">

                <?= htmlspecialchars(
                    $_SESSION["department"]
                ) ?>

            </div>


        </div>


    </div>


    <!-- =====================================================
         Content
    ====================================================== -->

    <div class="content">


        <div class="form-card">


            <h2 class="form-title">

                📝 บันทึกข้อมูลเอกสารใหม่

            </h2>


            <!-- =================================================
                 สำคัญ:
                 enctype ต้องมีเพื่อให้อัปโหลดไฟล์ได้
            ================================================== -->

            <form
                action="save_document.php"
                method="POST"
                enctype="multipart/form-data"
            >


                <!-- =================================================
                     ข้อมูลหนังสือ
                ================================================== -->

                <div class="form-section-title">

                    📄 ข้อมูลหนังสือ

                </div>


                <div class="form-grid">


                    <!-- เลขที่หนังสือ -->

                    <div class="form-group">


                        <label>

                            เลขที่หนังสือ

                            <span class="required">
                                *
                            </span>

                        </label>


                        <input
                            type="text"
                            name="document_no"
                            placeholder="เช่น ลป 123/2569"
                            required
                        >


                    </div>


                    <!-- วันที่หนังสือ -->

                    <div class="form-group">


                        <label>

                            วันที่หนังสือ

                        </label>


                        <input
                            type="date"
                            name="document_date"
                        >


                    </div>


                    <!-- เรื่อง -->

                    <div class="form-group full">


                        <label>

                            เรื่อง

                            <span class="required">
                                *
                            </span>

                        </label>


                        <input
                            type="text"
                            name="subject"
                            placeholder="กรอกชื่อเรื่อง"
                            required
                        >


                    </div>


                    <!-- จาก / ผู้ส่ง -->

                    <div class="form-group">


                        <label>

                            จาก / ผู้ส่ง

                        </label>


                        <input
                            type="text"
                            name="sender"
                            placeholder="หน่วยงานหรือบุคคลผู้ส่ง"
                        >


                    </div>


                    <!-- ถึง / ผู้รับ -->

                    <div class="form-group">


                        <label>

                            ถึง / ผู้รับ

                        </label>


                        <input
                            type="text"
                            name="receiver"
                            placeholder="หน่วยงานหรือบุคคลผู้รับ"
                        >


                    </div>


                </div>


                <!-- =================================================
                     การดำเนินงาน
                ================================================== -->

                <div class="form-section-title">

                    👤 ข้อมูลการดำเนินงาน

                </div>


                <div class="form-grid">


                    <!-- หน่วยงาน -->

                    <div class="form-group">


                        <label>

                            หน่วยงาน

                        </label>


                        <input
                            type="text"
                            name="department"
                            placeholder="เช่น สำนักปลัด / กองคลัง / กองช่าง"
                        >


                    </div>


                    <!-- ผู้รับผิดชอบ -->

                    <div class="form-group">


                        <label>

                            ผู้รับผิดชอบ

                        </label>


                        <input
                            type="text"
                            name="responsible_person"
                            placeholder="ชื่อผู้รับผิดชอบ"
                        >


                    </div>


                    <!-- วันที่รับเอกสาร -->

                    <div class="form-group">


                        <label>

                            วันที่รับเอกสาร

                        </label>


                        <input
                            type="datetime-local"
                            name="received_date"
                        >


                        <div class="help">

                            หากไม่ระบุ
                            ระบบจะใช้วันและเวลาปัจจุบัน

                        </div>


                    </div>


                    <!-- กำหนดเสร็จ -->

                    <div class="form-group">


                        <label>

                            กำหนดเสร็จ

                        </label>


                        <input
                            type="date"
                            name="due_date"
                        >


                    </div>


                    <!-- สถานะ -->

                    <div class="form-group">


                        <label>

                            สถานะเริ่มต้น

                        </label>


                        <select name="status">


                            <option value="ลงรับแล้ว">

                                ลงรับแล้ว

                            </option>


                            <option value="กำลังดำเนินการ">

                                กำลังดำเนินการ

                            </option>


                            <option value="เสนอหัวหน้าสำนักปลัด">

                                เสนอหัวหน้าสำนักปลัด

                            </option>


                            <option value="เสนอผู้บริหาร">

                                เสนอผู้บริหาร

                            </option>


                            <option value="ส่งให้ผู้ที่ได้รับมอบ">

                                ส่งให้ผู้ที่ได้รับมอบ

                            </option>


                            <option value="เสร็จสมบูรณ์">

                                เสร็จสมบูรณ์

                            </option>


                        </select>


                    </div>


                    <!-- ความเร่งด่วน -->

                    <div class="form-group">


                        <label>

                            ความเร่งด่วน

                        </label>


                        <select name="priority">


                            <option value="ปกติ">

                                ปกติ

                            </option>


                            <option value="ด่วน">

                                ด่วน

                            </option>


                            <option value="ด่วนมาก">

                                ด่วนมาก

                            </option>


                            <option value="ด่วนที่สุด">

                                ด่วนที่สุด

                            </option>


                        </select>


                    </div>


                </div>


                <!-- =================================================
                     รายละเอียด
                ================================================== -->

                <div class="form-section-title">

                    📋 รายละเอียดเพิ่มเติม

                </div>


                <div class="form-grid">


                    <!-- รายละเอียด -->

                    <div class="form-group full">


                        <label>

                            รายละเอียด / การดำเนินการ

                        </label>


                        <textarea
                            name="detail"
                            placeholder="บันทึกรายละเอียดของเอกสาร หรือรายละเอียดการดำเนินงาน"
                        ></textarea>


                    </div>


                    <!-- ผลการดำเนินงาน -->

                    <div class="form-group full">


                        <label>

                            ผลการดำเนินงาน

                        </label>


                        <textarea
                            name="result"
                            placeholder="บันทึกผลการดำเนินงาน (ถ้ามี)"
                        ></textarea>


                    </div>


                </div>


                <!-- =================================================
                     ⭐ เอกสารแนบ
                ================================================== -->

                <div class="form-section-title">

                    📎 เอกสารแนบ

                </div>


                <div class="form-grid">


                    <div class="form-group full">


                        <div class="file-upload-box">


                            <div class="file-upload-title">

                                📎 เลือกไฟล์เอกสารที่ต้องการแนบ

                            </div>


                            <input
                                type="file"
                                name="attachments[]"
                                multiple
                                accept="
                                    .pdf,
                                    .doc,
                                    .docx,
                                    .xls,
                                    .xlsx,
                                    .jpg,
                                    .jpeg,
                                    .png
                                "
                            >


                            <div class="file-upload-help">

                                สามารถเลือกได้หลายไฟล์พร้อมกัน

                                <br>

                                รองรับไฟล์:

                                PDF,
                                Word,
                                Excel,
                                JPG,
                                JPEG,
                                PNG

                                <br>

                                ขนาดไม่เกิน
                                <strong>10 MB ต่อไฟล์</strong>

                            </div>


                        </div>


                    </div>


                </div>


                <!-- =================================================
                     ปุ่ม
                ================================================== -->

                <div class="form-actions">


                    <a
                        href="dashboard.php"
                        class="btn btn-cancel"
                    >

                        ยกเลิก

                    </a>


                    <button
                        type="submit"
                        class="btn btn-save"
                    >

                        💾 บันทึกเอกสาร

                    </button>


                </div>


            </form>


        </div>


    </div>


</div>


</body>

</html>